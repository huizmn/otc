package com.uhc.pv;

import java.lang.String;
import java.lang.ClassLoader;
import java.lang.Double;
import java.lang.CharSequence;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import com.uhc.oracle.Claim;

public class PVUtil {
    public static HashMap<String,String> replacement_list = new HashMap<String,String>();
    public static int err;
    static {
	ClassLoader cl = PVUtil.class.getClassLoader();
	InputStream is = cl.getResourceAsStream("tables/usps_street_abbr.txt");
	InputStreamReader isr = new InputStreamReader(is);
	BufferedReader br = new BufferedReader(isr);
	String[] lst;
	try {
	    String line = br.readLine();
	    while (line!=null) {
		lst = line.split(",");
		replacement_list.put(lst[0],lst[1]);
		line = br.readLine();
	    }
	} catch (java.io.IOException e) {
	    err++;
	}
	replacement_list.put("APT", "");
	replacement_list.put("UNIT", "");
	replacement_list.put("WEST", "W");
	replacement_list.put("EAST", "E");
	replacement_list.put("NORTH", "N");
	replacement_list.put("SOUTH", "S");
	replacement_list.put("SO", "S");
	replacement_list.put("NO", "N");
	replacement_list.put("COUNTY RD", "CR");
	replacement_list.put("SECOND", "2ND");
	replacement_list.put("STATE", "ST");
	replacement_list.put("SUITE", "STE");
	replacement_list.put("BUILDING", "BDG");
	replacement_list.put("BLD", "BDG");
	replacement_list.put("BLDG", "BDG");
	replacement_list.put("BLG", "BDG");
    }

    public static String cleanAddress(String in_addr) {
	String out_addr = in_addr.replaceAll("(\\.|,|#|-)"," ");
	for (String rule : replacement_list.keySet()) {
	    out_addr = out_addr.replaceAll("(^|\\s)"+rule+"($|\\s)"," "+replacement_list.get(rule)+" ");
	}
	out_addr = out_addr.replaceAll("(?<=[0-9])TH($|\\s)"," ");
	out_addr = out_addr.replaceAll("[ ]+"," ");
	return out_addr.trim();
    }

    public static int levenshteinDistance(CharSequence lhs, CharSequence rhs) {                          
	int len0 = lhs.length() + 1;                                                     
	int len1 = rhs.length() + 1;                                                     
	
	// the array of distances                                                       
	int[] cost = new int[len0];                                                     
	int[] newcost = new int[len0];                                                  
	
	// initial cost of skipping prefix in String s0                                 
	for (int i = 0; i < len0; i++) cost[i] = i;                                     
	
	// dynamically computing the array of distances                                  
        
	// transformation cost for each letter in s1                                    
	for (int j = 1; j < len1; j++) {                                                
	    // initial cost of skipping prefix in String s1                             
	    newcost[0] = j;                                                             
	    
	    // transformation cost for each letter in s0                                
	    for(int i = 1; i < len0; i++) {                                             
		// matching current letters in both strings                             
		int match = (lhs.charAt(i - 1) == rhs.charAt(j - 1)) ? 0 : 1;             
		
		// computing cost for each transformation                               
		int cost_replace = cost[i - 1] + match;                                 
		int cost_insert  = cost[i] + 1;                                         
		int cost_delete  = newcost[i - 1] + 1;                                  
		
		// keep minimum cost                                                    
		newcost[i] = Math.min(Math.min(cost_insert, cost_delete), cost_replace);
	    }                                                                           
	    
	    // swap cost/newcost arrays                                                 
	    int[] swap = cost; cost = newcost; newcost = swap;                          
	}                                                                               
                                                                                    
	// the distance is the cost for transforming all letters in both strings        
	return cost[len0 - 1];                                                          
    }

    public static int matchAddresses(String street1,String state1,String zip1, String street2, String state2, String zip2) {
	if ((!state1.equals(state2))||(!zip1.equals(zip2))) {
	    return -1;
	}
	return levenshteinDistance(street1,street2);
    }

    public static int[] runAddressMatching(Claim claim, NPPESRecord nppes) {
	String claim_bill_street_address     = cleanAddress(claim.bill_prov_addr1 + " " + claim.bill_prov_addr2);
	String claim_facl_street_address     = cleanAddress(claim.facility_addr1 + " " + claim.facility_addr2);
	String nppes_mailing_street_address  = cleanAddress(nppes.Provider_First_Line_Business_Mailing_Address+" "+nppes.Provider_Second_Line_Business_Mailing_Address);
	String nppes_practice_street_address = cleanAddress(nppes.Provider_First_Line_Business_Practice_Location_Address+" "+nppes.Provider_Second_Line_Business_Practice_Location_Address);

	String claim_bill_zip = (claim.bill_prov_zip.length()>=5 ? claim.bill_prov_zip.substring(0,5) : "");
	String claim_facl_zip = (claim.facility_zip.length()>=5 ? claim.facility_zip.substring(0,5) : "");
	String nppes_mail_zip = (nppes.Provider_Business_Mailing_Address_Postal_Code.length()>=5 ? nppes.Provider_Business_Mailing_Address_Postal_Code.substring(0,5) : "");
	String nppes_prac_zip = (nppes.Provider_Business_Practice_Location_Address_Postal_Code.length()>=5 ? nppes.Provider_Business_Practice_Location_Address_Postal_Code.substring(0,5) : "");
	
	int claim_bill_to_nppes_mailing = matchAddresses(
							 claim_bill_street_address,
							 claim.bill_prov_state,
							 claim_bill_zip,
							 nppes_mailing_street_address,
							 nppes.Provider_Business_Mailing_Address_State_Name,
							 nppes_mail_zip
							 );
	int claim_bill_to_nppes_practice = matchAddresses(
							 claim_bill_street_address,
							 claim.bill_prov_state,
							 claim_bill_zip,
							 nppes_practice_street_address,
							 nppes.Provider_Business_Practice_Location_Address_State_Name,
							 nppes_prac_zip
							  );
	int claim_facl_to_nppes_mailing = matchAddresses(
							 claim_facl_street_address,
							 claim.facility_state,
							 claim_facl_zip,
							 nppes_mailing_street_address,
							 nppes.Provider_Business_Mailing_Address_State_Name,
							 nppes_mail_zip
							 );
	int claim_facl_to_nppes_practice = matchAddresses(
							 claim_facl_street_address,
							 claim.facility_state,
							 claim_facl_zip,
							 nppes_practice_street_address,
							 nppes.Provider_Business_Practice_Location_Address_State_Name,
							 nppes_prac_zip
							  );
	int min_distance = claim_bill_to_nppes_mailing;
        int score_type   = 1;

	if ((claim_bill_to_nppes_practice<min_distance) && (claim_bill_to_nppes_practice>=0)) {
	    min_distance=claim_bill_to_nppes_practice;
	    score_type=2;
	}

	if ((claim_facl_to_nppes_mailing<min_distance) && (claim_facl_to_nppes_mailing>=0)) {
	    min_distance=claim_facl_to_nppes_mailing;
	    score_type=3;
	}

	if ((claim_facl_to_nppes_practice<min_distance) && (claim_facl_to_nppes_practice>=0)) {
	    min_distance=claim_facl_to_nppes_practice;
	    score_type=4;
	}

	int[] out_array={min_distance,score_type};
	
	return out_array;
    }

    public static int[] runAddressMatching(Claim claim, String fraud_address) {
    	String claim_bill_street_address = cleanAddress(claim.bill_prov_addr1 + " " + claim.bill_prov_addr2);
    	String claim_facl_street_address = cleanAddress(claim.facility_addr1 + " " + claim.facility_addr2);
    	String fraud_street_address      = cleanAddress(fraud_address);
	
    	int claim_bill_to_fraud = levenshteinDistance(claim_bill_street_address,fraud_street_address);
    	int claim_facl_to_fraud = levenshteinDistance(claim_facl_street_address,fraud_street_address);
	    
    	int min_distance = claim_bill_to_fraud;
        int score_type   = 1;

    	if ((claim_facl_to_fraud<min_distance) && (claim_facl_to_fraud>=0)) {
    	    min_distance=claim_facl_to_fraud;
    	    score_type=2;
    	}

    	int[] out_array={min_distance,score_type};
	
    	return out_array;
    }

    public static int runNameMatching(Claim claim, NPPESRecord nppes) {
	String claim_name = (claim.rend_prov_f_nm + " " + claim.rend_prov_l_nm).trim();
	String nppes_name = (nppes.Provider_First_Name + " " + nppes.Provider_Last_Name).trim();
	String nppes_org  = nppes.Provider_Organization_Name;

	if (claim_name.length()==0) {
	    return -1;
	} else {
	    int claim_to_prov = levenshteinDistance(claim_name,nppes_name);
	    int claim_to_org  = levenshteinDistance(claim_name,nppes_org);
	    if (claim_to_prov<claim_to_org) {
		return claim_to_prov;
	    } else {
		return claim_to_org;
	    }
	}
    }

    public static int runTaxonomyMatching(Claim claim, NPPESRecord nppes) {
	String nppes_taxonomy = nppes.Healthcare_Provider_Taxonomy_Code_1;
	if (nppes_taxonomy.equals(claim.renderring_provider_taxonomy_code)) {
	    return 1;
	} else if (nppes_taxonomy.equals(claim.provider_taxonomy_code)) {
	    return 2;
	} else if (nppes_taxonomy.equals(claim.billing_provider_taxonomy_code)) {
	    return 3;
	}
	return 0;
    }

    /**
     * Split a line
     */
    public static String[] split(String buff, char sep) {
	ArrayList<String> values = new ArrayList<String>();
	int stat=0;
	char[] char_buff = buff.toCharArray();
	StringBuffer sb = new StringBuffer();
	for (char c : char_buff) {
	    if (stat==0) {
		stat=1;
		if (c==' ') {
		    stat=0;
		} else if (c=='"') {
		    stat=2;
		} else if (c==sep) {
		    values.add(sb.toString());
		    sb = new StringBuffer();
		    stat=0;
		} else {
		    sb.append(c);
		}
	    } else if (stat==1) {
		if (c==sep) {
		    values.add(sb.toString());
		    sb = new StringBuffer();
		    stat=0;
		} else {
		    sb.append(c);
		}
	    } else if (stat==2) {
		if (c=='"') {
		    stat=3;
		} else {
		    sb.append(c);
		}
	    } else if (stat==3) {
		if (c==sep) {
		    values.add(sb.toString());
		    sb = new StringBuffer();
		    stat=0;
		}
	    }
	}
	values.add(sb.toString());
	//
	String[] out_array = new String[values.size()];
	int i=0;
	for (String v : values) {
	    out_array[i]=v;
	    i++;
	}
	//
	return out_array;
    }
}
