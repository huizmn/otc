package com.uhc.pv;

public class DeathMasterRecord {
    public String entity_id;
    public String first_name;
    public String middle_name;
    public String last_name;
    public String birth_date;
    public String ssn;
    public String dod;
    public String matchcode;
    public String vp_code;
    public String D_SSN;
    public String D_FIRST_NAME;
    public String D_LAST_NAME;
    public String D_MIDDLE_NAME;
    public String D_DOB;
    public String D_ADD_DT;
    public String monthadd;

    /**
     * From file death master file
     */
    public DeathMasterRecord(String in_buff) {
	String[] arr=PVUtil.split(in_buff,'|');
	int i=0;
	//
	entity_id = arr[i++];
	first_name = arr[i++];
	middle_name = arr[i++];
	last_name = arr[i++];
	birth_date = arr[i++];
	ssn = arr[i++];
	dod = arr[i++];
	matchcode = arr[i++];
	vp_code = arr[i++];
	D_SSN = arr[i++];
	D_FIRST_NAME = arr[i++];
	D_LAST_NAME = arr[i++];
	D_MIDDLE_NAME = arr[i++];
	D_DOB = arr[i++];
	D_ADD_DT = arr[i++];
	monthadd = arr[i++];
    }
}    

