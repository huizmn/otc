package com.uhc.pv;

public class FraudAddress {
    public String address_id;
    public String address;

    /**
     * From file Fraud_addresses.txt
     */
    public FraudAddress(String in_buff) {
	String[] arr=PVUtil.split(in_buff,'|');
	int i=0;
	//
	address_id = arr[i++];
	address = arr[i++];
    }
}    

