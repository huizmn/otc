package com.uhc.pv;

public class PhantomAddress {
    public String npi;
    public String entity_code;
    public String address_type;
    public String address;
    public String city;
    public String state;
    public String zip;

    /**
     * From file phantom_address.txt
     */
    public PhantomAddress(String in_buff) {
	String[] arr=PVUtil.split(in_buff,'\t');
	int i=0;
	//
	npi= arr[i++];
	entity_code= arr[i++];
	address_type= arr[i++];
	address= arr[i++];
	city= arr[i++];
	state= arr[i++];
	zip= arr[i++];
    }
}    
