package com.uhc.pv;

public class PhantomRecord {
    public String mpin_match;
    public String tin_match;
    public String mpin;
    public String provider_tin;
    public String provider_bill_name;
    public String npi_mbr;
    public String npi_entity_code;
    public String npi_name;
    public String provider_bill_npi;
    public String npi_bill_entity_code;
    public String npi_bill_name;
    public String provider_svc_npi;
    public String npi_svc_entity_code;
    public String npi_svc_name;

    /**
     * From file: phantom_hard_deny_tins.txt
     * Index by:
     *          provider_tin
     *          npi_nbr
     *          provider_bill_npi
     *          provider_svc_npi
     */
    public PhantomRecord(String in_buff) {
	String[] arr=PVUtil.split(in_buff,'\t');
	int i=0;
	//
	mpin_match = arr[i++];
	tin_match = arr[i++];
	mpin = arr[i++];
	provider_tin = arr[i++];
	provider_bill_name = arr[i++];
	npi_mbr = arr[i++];
	npi_entity_code = arr[i++];
	npi_name = arr[i++];
	provider_bill_npi = arr[i++];
	npi_bill_entity_code = arr[i++];
	npi_bill_name = arr[i++];
	provider_svc_npi = arr[i++];
	npi_svc_entity_code = arr[i++];
	npi_svc_name = arr[i++];
    }
}

	
	
	
