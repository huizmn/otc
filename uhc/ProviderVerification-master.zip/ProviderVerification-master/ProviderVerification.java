package com.uhc.pv;

import java.lang.Math;
import java.lang.String;
import java.lang.StringBuffer;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
    
import com.uhc.oracle.Claim;
import com.uhc.oracle.ClaimVars;
import com.uhc.oracle.Aggregator;
import com.uhc.oracle.AggVarsTimeWindows;
    
public class ProviderVerification {
    static HashMap<String,Double> place_of_service_risk_tbl = new HashMap<String,Double>();
    static {
	place_of_service_risk_tbl.put("11",new Double(0.03255));
	place_of_service_risk_tbl.put("12",new Double(0.08216));
	place_of_service_risk_tbl.put("13",new Double(0.05030));
	place_of_service_risk_tbl.put("15",new Double(0.08529));
	place_of_service_risk_tbl.put("19",new Double(0.03991));
	place_of_service_risk_tbl.put("20",new Double(0.01478));
	place_of_service_risk_tbl.put("21",new Double(0.03398));
	place_of_service_risk_tbl.put("22",new Double(0.02883));
	place_of_service_risk_tbl.put("23",new Double(0.02305));
	place_of_service_risk_tbl.put("24",new Double(0.02455));
	place_of_service_risk_tbl.put("31",new Double(0.06462));
	place_of_service_risk_tbl.put("32",new Double(0.05103));
	place_of_service_risk_tbl.put("41",new Double(0.01933));
	place_of_service_risk_tbl.put("49",new Double(0.02698));
	place_of_service_risk_tbl.put("51",new Double(0.04337));
	place_of_service_risk_tbl.put("53",new Double(0.03991));
	place_of_service_risk_tbl.put("55",new Double(0.05642));
	place_of_service_risk_tbl.put("57",new Double(0.08174));
	place_of_service_risk_tbl.put("81",new Double(0.03550));
	place_of_service_risk_tbl.put("99",new Double(0.08219));
    }

    static HashMap<String,Double> taxo4_risk_tbl = new HashMap<String,Double>();
    static {
	taxo4_risk_tbl.put("101Y",new Double(0.04396));
	taxo4_risk_tbl.put("103T",new Double(0.02729));
	taxo4_risk_tbl.put("1041",new Double(0.04485));
	taxo4_risk_tbl.put("111N",new Double(0.02196));
	taxo4_risk_tbl.put("1223",new Double(0.06738));
	taxo4_risk_tbl.put("152W",new Double(0.02108));
	taxo4_risk_tbl.put("1711",new Double(0.10950));
	taxo4_risk_tbl.put("207L",new Double(0.01554));
	taxo4_risk_tbl.put("207P",new Double(0.02289));
	taxo4_risk_tbl.put("207Q",new Double(0.04783));
	taxo4_risk_tbl.put("207R",new Double(0.03235));
	taxo4_risk_tbl.put("207V",new Double(0.01448));
	taxo4_risk_tbl.put("207Z",new Double(0.01959));
	taxo4_risk_tbl.put("2080",new Double(0.03878));
	taxo4_risk_tbl.put("2084",new Double(0.06051));
	taxo4_risk_tbl.put("2085",new Double(0.03419));
	taxo4_risk_tbl.put("2086",new Double(0.07681));
	taxo4_risk_tbl.put("208D",new Double(0.02976));
	taxo4_risk_tbl.put("213E",new Double(0.05446));
	taxo4_risk_tbl.put("2251",new Double(0.07782));
	taxo4_risk_tbl.put("261Q",new Double(0.01717));
	taxo4_risk_tbl.put("291U",new Double(0.03140));
	taxo4_risk_tbl.put("332B",new Double(0.06065));
	taxo4_risk_tbl.put("3416",new Double(0.01932));
	taxo4_risk_tbl.put("363A",new Double(0.04598));
	taxo4_risk_tbl.put("363L",new Double(0.04172));
	taxo4_risk_tbl.put("3902",new Double(0.03281));
    }
    
    static HashMap<String,String> reason_desc = new HashMap<String,String>();
    static {
	reason_desc.put("address_match_type_risk"              ,"Authentication risk is high because there was no match between claim address (billing or facility) and NPPES addresses (mailing or practice) or the best match was on the billing address information between the claim and NPPESS addresses.");
	reason_desc.put("age_risk"                             ,"Authentication risk is high due to members age.");
	reason_desc.put("age_group_day_of_week_compare_risk"   ,"?");
	reason_desc.put("ave_mod_risk"                         ,"?");
	reason_desc.put("claim_minutes_risk"                   ,"The total minutes for procedures on claim is lower or higher than expected.");
	reason_desc.put("day_of_week_risk"                     ,"Authentication risk is high due to the day of the week on the claim.");
	reason_desc.put("diag_proc_measure_risk"               ,"Authentication risk is high due to the diagnosis-procedure combination on the claim.");
	reason_desc.put("diag_to_gender_compare_risk"          ,"Authentication risk is high due to the diagnosis-patient gender combination on the claim.");
	reason_desc.put("diag_to_pl_service_compare_risk"      ,"?");
	reason_desc.put("dist_bill_to_nppes_risk"              ,"Distance from billing address on claim to business mailing address on NPPES data is risky.");
	reason_desc.put("dist_ref_prov_to_subs_risk"           ,"Distance from referring provider, using the NPPES provider business mailing address,  to patient is risky.");
	reason_desc.put("facility_to_bill_risk"                ,"Distance from billing address to facility address is risky.");
	reason_desc.put("npi_av8_12w_ave_daily_minutes_risk"   ,"Authentication risk is high due to the large average number of procedure minutes per day in the last 12 weeks.");
	reason_desc.put("npi_av4w_ave_bill_amt_per_day_risk"   ,"Authentication risk is high due to large average total bill amount per day in the last 4 weeks.");
	reason_desc.put("num_diag_codes_risk"                  ,"Authentication risk is high due to only one diagnosis code on the claim.");
	reason_desc.put("number_of_lines_risk"                 ,"Authentication risk is high due to large (>3) number of procedures on the claim.");
	reason_desc.put("number_of_modifiers_risk"             ,"Authentication risk is high due to number of modifiers on the claim.");
	reason_desc.put("pat_av12w_number_of_lines_risk"       ,"Authentication risk is high due to unusual number of procedures observed for this patient in the last 12 weeks.");
	reason_desc.put("pat_av4w_ave_diag_proc_compare_risk"  ,"?");
	reason_desc.put("pat_av4w_ave_proc_group_risk"         ,"Over the last 4 weeks,  the member had procedures associated with high fraud risk.");
	reason_desc.put("pl_service_day_of_week_compare_risk"  ,"?");
	reason_desc.put("place_of_service_code_risk"           ,"Authentication risk is high for this place of service.");
	reason_desc.put("proc_day_of_week_compare_risk"        ,"?");
	reason_desc.put("proc_to_age_compare_ave_risk"         ,"?");
	reason_desc.put("proc_to_place_of_service_compare_risk","?");
	reason_desc.put("provider_taxo4_risk"                  ,"Authentication risk is high for this provider specialty.");
	reason_desc.put("taxo4_day_of_week_compare_risk"       ,"?");
	reason_desc.put("taxo4_to_dist_to_home_compare_risk"   ,"Authentication risk is high given the distance traveled by patient for that particular provider specialty.");
	reason_desc.put("taxo4_to_pl_service_compare_risk"     ,"?");
	reason_desc.put("taxo4_to_proc_compare_risk"           ,"Authentication risk is high due to provider specialty-procedure combination on the claim.");
	reason_desc.put("total_claim_charge_risk"              ,"Authentication risk is high due to large total bill amount on claim.");
    }

    public int score;
    public double sum;
    public Claim claim;
    public NPPESRecord rend_nppes;
    public NPPESRecord bill_nppes;
    public NPPESRecord refp_nppes;
    public AggVarsTimeWindows npi_aggs;
    public AggVarsTimeWindows pat_aggs;

    public int    subs_to_bill;
    public int    facility_to_bill;
    public int    facility_to_subs;
    public int    dist_bill_to_nppes;
    public int    dist_ref_prov_to_subs;
    public String rend_prov_name;
    public double total_claim_charge_risk;
    public double place_of_service_code_risk;
    public double day_of_week_risk;
    public double age_risk;
    public int    address_match_score;
    public int    address_match_type;
    public double address_match_score_risk;
    public double address_match_type_risk;
    public int    name_match_score;
    public double name_match_score_risk;
    public double ave_mod_risk;
    public double claim_minutes_risk;
    public double diag_proc_measure_risk;
    public double diag_to_gender_compare_risk;
    public double dist_bill_to_nppes_risk;
    public double dist_ref_prov_to_subs_risk;
    public double facility_to_bill_risk;
    public double facility_to_subs_risk;
    public double npi_av12w_ave_daily_minutes_risk;
    public double npi_av4w_ave_bill_amt_per_day_risk;
    public double npi_av8w_ave_diag_proc_compare_risk;
    public double npi_av8w_ave_daily_minutes_risk;
    public double npi_av8_12w_ave_daily_minutes_risk;
    public double num_diag_codes_risk;
    public double number_of_lines_risk;
    public double number_of_modifiers_risk;
    public double pat_av12w_ave_distance_from_home_risk;
    public double pat_av12w_number_of_lines_risk;
    public double pat_av4w_ave_diag_proc_compare_risk;
    public double pat_av4w_ave_proc_group_risk;
    public double pl_service_day_of_week_compare_risk;
    public double proc_to_age_compare_ave_risk;
    public double proc_to_place_of_service_compare_risk;
    public double provider_taxo4_risk;
    public double subs_to_bill_risk;
    public double taxo4_day_of_week_compare_risk;
    public double taxo4_to_diag_compare_risk;
    public double taxo4_to_dist_to_home_compare_risk;
    public double diag_to_pl_service_compare_risk;
    public double taxo4_to_proc_compare_risk;
    public double taxo4_to_pl_service_compare_risk;
    public double age_group_day_of_week_compare_risk;
    public double proc_day_of_week_compare_risk;
    public double sum_logreg;
    public int    pv_score;
    public String disposition;
    public Factor[] factors;
    public ArrayList<Factor> deltas;
    public int    n_npi_sanctions;
    public int    n_tin_sanctions;
    public String npi_sanc_types;
    public String tin_sanc_types;
    public int    fraud_address_match_score;
    public int    fraud_address_match_type;
    public String[] reasons;
    public String[] reasons_description;
    public int    low_threshold;
    public int    high_threshold;

    //--------------------------------------------------------//
    // A class to sort the score factors
    public static class Factor implements Comparable<Factor> {
	public String vname;
	public double value;
	public double coeff;
	public double meanv;
	public double delta;
	public int    index;
	//
	public Factor(String vname, double value, double coeff, double meanv, int index) {
	    this.vname=vname;
	    this.value=value;
	    this.coeff=coeff;
	    this.meanv=meanv;
	    this.index=index;
	    this.delta=coeff*(value-meanv);
	}
	//
	public Factor setDelta(double delta) {
	    this.delta=delta;
	    return this;
	}
	//
	public int compareTo(Factor lf) {
	    if (this.delta>lf.delta) {
		return -1;
	    } else if (this.delta<lf.delta) {
		return 1;
	    } else {
		return 0;
	    }
	}
    }

    public ProviderVerification(
				 Claim claim,
				 String bill_nppes_str,
				 String rend_nppes_str,
				 String refp_nppes_str,
				 String npi_aggs_str,
				 String patient_aggs_str,
				 String[] sanctions_matches,
				 String[] fraud_address_matches
				) {
	this(
	     claim,
	     bill_nppes_str,
	     rend_nppes_str,
	     refp_nppes_str,
	     npi_aggs_str,
	     patient_aggs_str,
	     sanctions_matches,
	     fraud_address_matches,
	     17,
	     44
	     );
    }

    public ProviderVerification(
				 Claim claim,
				 String bill_nppes_str,
				 String rend_nppes_str,
				 String refp_nppes_str,
				 String npi_aggs_str,
				 String patient_aggs_str,
				 String[] sanctions_matches,
				 String[] fraud_address_matches,
				 int low_threshold,
				 int high_threshold
				 ) {
	this.claim=claim;
	if (rend_nppes_str.trim().length()>0) {
	    this.rend_nppes = new NPPESRecord(rend_nppes_str);
	} else {
	    this.rend_nppes = null;
	}
	if (bill_nppes_str.trim().length()>0) {
	    this.bill_nppes = new NPPESRecord(bill_nppes_str);
	} else {
	    this.bill_nppes = null;
	}
	if (refp_nppes_str.trim().length()>0) {
	    this.refp_nppes = new NPPESRecord(refp_nppes_str);
	} else {
	    this.refp_nppes = null;
	}
	this.npi_aggs = AggVarsTimeWindows.fromString(npi_aggs_str);
	this.pat_aggs = AggVarsTimeWindows.fromString(patient_aggs_str);
	this.low_threshold  = low_threshold;
	this.high_threshold = high_threshold;
	//----------------------------------------------------//	
	// The address matching between the claim and the NPPES record from the NPI
	int[] add_match;
	// First we attempt to mach the rendering provider information
	if (this.rend_nppes!=null) {
	    add_match = PVUtil.runAddressMatching(claim, this.rend_nppes);
	} else {
	    add_match = new int[] {-1,0};
	}
	//
	int address_match_distance = add_match[0];
	this.address_match_type    = add_match[1];
	// Then we try the bill provider information
	if (this.bill_nppes!=null) {
	    add_match = PVUtil.runAddressMatching(claim, this.bill_nppes);
	} else {
	    add_match = new int[] {-1,0};
	}
	// We choose the closest match
	if ((add_match[0]>=0)&&((add_match[0]<address_match_distance)||(address_match_distance==-1))) {
	    address_match_distance   = add_match[0];
	    this.address_match_type  = 4+add_match[1];
	}
	// The final binning of the match.
	// The values returned from PVUtil.runAddressMatching are
	// the number of edits from one address to the other
	// hence a smaller number corresponds to a better match.
	// The output we will produce is
	//  0 : No match or missing data
	//  1 : poor match (string distance > 10)
	//  2 : fair match (string distance 3-10)
	//  3 : good match (string distance 1-2)
	//  4 : perfect match
	if ((address_match_distance==-1)||(address_match_distance>30)) {
	    this.address_match_score=0;
	    this.address_match_type=0;
	} else if (address_match_distance>10) {
	    this.address_match_score=1;
	} else if (address_match_distance>2) {
	    this.address_match_score=2;
	} else if (address_match_distance>0) {
	    this.address_match_score=3;
	} else {
	    this.address_match_score=4;
	}
	//----------------------------------------------------//	
	// The name matching between the claim and the NPPES record from the NPI
	int rend_name_match_score=-1;
	if (this.rend_nppes!=null) rend_name_match_score = PVUtil.runNameMatching(claim, this.rend_nppes);
	int bill_name_match_score=-1;
	if (this.bill_nppes!=null) bill_name_match_score = PVUtil.runNameMatching(claim, this.bill_nppes);
	// Keep the best matching
	if ((rend_name_match_score==-1)&&(bill_name_match_score==-1)) this.name_match_score=-1;
	else if (rend_name_match_score==-1)  	                      this.name_match_score=bill_name_match_score;
	else if (bill_name_match_score==-1) 	                      this.name_match_score=rend_name_match_score;
        else if (bill_name_match_score>rend_name_match_score)         this.name_match_score=rend_name_match_score;
	else                                                          this.name_match_score=bill_name_match_score;
	// Transforming from edit distance to score
	if ((this.name_match_score==-1)||(this.name_match_score>30)) {
	    this.name_match_score=0;
	} else if (this.name_match_score>10) {
	    this.name_match_score=1;
	} else if (this.name_match_score>2) {
	    this.name_match_score=2;
	} else if (this.name_match_score>0) {
	    this.name_match_score=3;
	} else {
	    this.name_match_score=4;
	}
	//----------------------------------------------------//	
	// Count sanctions
	HashSet<String> sanctions_ids = new HashSet<String>();
	//
	HashSet<String> npi_sanctions_types = new HashSet<String>();
	HashSet<String> tin_sanctions_types = new HashSet<String>();
	//
	this.n_npi_sanctions=0;
	this.n_tin_sanctions=0;
	//
	this.npi_sanc_types="";
	this.tin_sanc_types="";
	//
	for (String sanctions_match_buff : sanctions_matches) {
	    SanctionsRecord sr = new SanctionsRecord(sanctions_match_buff);
	    // Deduping
	    if (!sanctions_ids.contains(sr.sanc_id)) {
		if (claim.npi.equals(sr.sanc_npi)) {
		    this.n_npi_sanctions+=1;
		    npi_sanctions_types.add(sr.sanc_type);
		}
		if (claim.tin.equals(sr.sanc_tin)) {
		    this.n_tin_sanctions+=1;
		    tin_sanctions_types.add(sr.sanc_type);
		}
		sanctions_ids.add(sr.sanc_id);
	    }
	}
	// The NPI sanctions type
	for (String sanc_type : npi_sanctions_types) this.npi_sanc_types=this.npi_sanc_types+":"+sanc_type;
	if (this.npi_sanc_types.length()>0) this.npi_sanc_types=this.npi_sanc_types.substring(1);
	// The TIN sanctions type
	for (String sanc_type : tin_sanctions_types) this.tin_sanc_types=this.tin_sanc_types+":"+sanc_type;
	if (this.tin_sanc_types.length()>0) this.tin_sanc_types=this.tin_sanc_types.substring(1);
	//----------------------------------------------------//	
	// The fraud addresses matches
	HashSet<String> fraud_address_ids = new HashSet<String>();
	//
	this.fraud_address_match_score=-1;
	this.fraud_address_match_type=0;
	//
	for (String fraud_address_match : fraud_address_matches) {
	    // deduping
	    if (!fraud_address_ids.contains(fraud_address_match)) {
		add_match = PVUtil.runAddressMatching(claim,fraud_address_match);
		if ((this.fraud_address_match_score > add_match[0]) && (add_match[0]>=0)) {
		    this.fraud_address_match_score = add_match[0];
		    this.fraud_address_match_type = add_match[1];
		}
		fraud_address_ids.add(fraud_address_match);
	    }
	}
	// transform from edit distance to score
	if ((this.fraud_address_match_score==-1)||(this.fraud_address_match_score>30)) {
	    this.fraud_address_match_score=0;
	    this.fraud_address_match_type=0;
	} else if (this.fraud_address_match_score>10) {
	    this.fraud_address_match_score=1;
	} else if (this.fraud_address_match_score>2) {
	    this.fraud_address_match_score=2;
	} else if (this.fraud_address_match_score>0) {
	    this.fraud_address_match_score=3;
	} else {
	    this.fraud_address_match_score=4;
	}
	//----------------------------------------------------//	
	computeVars();
	//----------------------------------------------------//	
    }

    public void computeVars() {
	//--------------------------------------------------------------------//
	// Claim variables
	ClaimVars cv = new ClaimVars(claim);
	//--------------------------------------------------------------------//
	// Distance from subscriber to billing provider
	subs_to_bill = Aggregator.zip2zip(claim.subscriber_zip,claim.provider_zip)+1;
	//--------------------------------------------------------------------//
	// Distance facility to bill and facility to subscriber
	if (claim.facility_zip.trim().length()>0) {
	    facility_to_bill = Aggregator.zip2zip(claim.facility_zip,claim.bill_prov_zip)+1;
	    facility_to_subs = Aggregator.zip2zip(claim.facility_zip,claim.subscriber_zip)+1;
	} else {
	    facility_to_bill = 7;
	    facility_to_subs = 7;
	}
	//
	if      (facility_to_bill<=1) facility_to_bill_risk=0.02605;
	else if (facility_to_bill<=2) facility_to_bill_risk=0.02938;
	else if (facility_to_bill<=3) facility_to_bill_risk=0.04170;
	else if (facility_to_bill<=6) facility_to_bill_risk=0.05394;
	else                          facility_to_bill_risk=0.04307;
	//
	if      (facility_to_subs<=1) facility_to_subs_risk=0.05055;
	else if (facility_to_subs<=4) facility_to_subs_risk=0.03266;
	else                          facility_to_subs_risk=0.04266;
	//--------------------------------------------------------------------//
	// The rendering provider name
	if (claim.rend_prov_l_nm.trim().length()>0) {
	    rend_prov_name = "N"; // Not found
	} else {
	    if (claim.rend_prov_f_nm.trim().length()>0) {
		rend_prov_name = "H"; // Probably a human
	    } else { 
		rend_prov_name = "F"; // Probably a facility
	    }
	}
	//--------------------------------------------------------------------//
	// Place of service risk
	if (place_of_service_risk_tbl.containsKey(claim.place_of_service_code)) {
	    place_of_service_code_risk=place_of_service_risk_tbl.get(claim.place_of_service_code).doubleValue();
	} else {
	    place_of_service_code_risk=0.03630;
	}
	//--------------------------------------------------------------------//
	// Total claim charge binning
	if      (claim.total_claim_charge<= 240) total_claim_charge_risk=0.02750;
	else if (claim.total_claim_charge<=1200) total_claim_charge_risk=0.04572;
	else                             	 total_claim_charge_risk=0.06110;
	//--------------------------------------------------------------------//
	// Age
	if      (claim.age<=50) age_risk=0.03385;
	else if (claim.age<=88) age_risk=0.04284;
	else 	                age_risk=0.07687;
	//--------------------------------------------------------------------//
	// Day of week
	if      (claim.day_of_week<=3) day_of_week_risk=0.04268;
	else if (claim.day_of_week<=5) day_of_week_risk=0.03914;
	else if (claim.day_of_week==6) day_of_week_risk=0.02864;
	else  	                       day_of_week_risk=0.02040;
	//--------------------------------------------------------------------//
	// Address matching score
	if      (address_match_score==0) address_match_score_risk=0.05044;
        else if (address_match_score==1) address_match_score_risk=0.03110;
	else if (address_match_score==2) address_match_score_risk=0.04013;
	else if (address_match_score==3) address_match_score_risk=0.04124;
	else            	         address_match_score_risk=0.03925;
	//--------------------------------------------------------------------//
	// Address matching type
	if      (address_match_type==0) address_match_type_risk=0.05044;
        else if (address_match_type==1) address_match_type_risk=0.02165;
	else if (address_match_type==2) address_match_type_risk=0.03070;
	else if (address_match_type==3) address_match_type_risk=0.01118;
	else if (address_match_type==4) address_match_type_risk=0.01929;
	else if (address_match_type==5) address_match_type_risk=0.05360;
	else if (address_match_type==6) address_match_type_risk=0.04341;
	else if (address_match_type==7) address_match_type_risk=0.04554;
	else if (address_match_type==8) address_match_type_risk=0.02728;
	else           	                address_match_type_risk=0.03961;
	//--------------------------------------------------------------------//
	// Name matching
	if      (name_match_score==0) name_match_score_risk=0.04608;
	else if (name_match_score==1) name_match_score_risk=0.05182;
	else if (name_match_score==2) name_match_score_risk=0.03648;
	else if (name_match_score==3) name_match_score_risk=0.05568;
	else if (name_match_score==4) name_match_score_risk=0.03720;
	else                          name_match_score_risk=0.03961;
	//--------------------------------------------------------------------//
	// Age group vs. day of week comparison
	if      (cv.age_group_day_of_week_compare<=0.364) age_group_day_of_week_compare_risk=0.02485;
	else if (cv.age_group_day_of_week_compare<=0.477) age_group_day_of_week_compare_risk=0.04002;
	else                                              age_group_day_of_week_compare_risk=0.05624;
	//--------------------------------------------------------------------//
	// Risk associate to the procedure modifiers
	if      (cv.ave_mod_risk<=0.147) ave_mod_risk=0.10652;
	else if (cv.ave_mod_risk<=0.268) ave_mod_risk=0.04385;
	else                             ave_mod_risk=0.03453;
	//--------------------------------------------------------------------//
	// Claim minutes
	if      (cv.claim_minutes<=11) claim_minutes_risk=0.06614;
	else if (cv.claim_minutes<=39) claim_minutes_risk=0.01889;
	else if (cv.claim_minutes<=64) claim_minutes_risk=0.03292;
	else                           claim_minutes_risk=0.05009;
	//--------------------------------------------------------------------//
	// Comparison diagnosis - procedures
	if      (cv.diag_proc_measure<0.004) diag_proc_measure_risk=0.09819;
	else if (cv.diag_proc_measure<0.094) diag_proc_measure_risk=0.04495;
	else                                 diag_proc_measure_risk=0.03388;
	//--------------------------------------------------------------------//
	// Diagnosis to gender comparison
	if (cv.diag_to_gender_compare<=0.509) diag_to_gender_compare_risk=0.05866;
	else                                  diag_to_gender_compare_risk=0.03821;
	//--------------------------------------------------------------------//
	// Diagnosis to place of service comparison
	if      (cv.diag_to_pl_service_compare<=0.013) diag_to_pl_service_compare_risk=0.03592;
	else if (cv.diag_to_pl_service_compare<=0.088) diag_to_pl_service_compare_risk=0.07286;
	else                                           diag_to_pl_service_compare_risk=0.03409;
	//--------------------------------------------------------------------//
	// Distance from billing address to nppes
	if (bill_nppes!=null) {
	    dist_bill_to_nppes = Aggregator.zip2zip(claim.bill_prov_zip,bill_nppes.Provider_Business_Mailing_Address_Postal_Code)+1;
	} else {
	    dist_bill_to_nppes = 7;
	}
	//
	if      (dist_bill_to_nppes<=1) dist_bill_to_nppes_risk=0.03586;
	else if (dist_bill_to_nppes<=2) dist_bill_to_nppes_risk=0.03931;
	else if (dist_bill_to_nppes<=4) dist_bill_to_nppes_risk=0.04153;
	else if (dist_bill_to_nppes<=6) dist_bill_to_nppes_risk=0.04316;
	else                            dist_bill_to_nppes_risk=0.12228;
	//--------------------------------------------------------------------//
	// The refering provider
	if (refp_nppes!=null) {
	    dist_ref_prov_to_subs = Aggregator.zip2zip(refp_nppes.Provider_Business_Mailing_Address_Postal_Code,claim.subscriber_zip)+1;
	} else {
	    dist_ref_prov_to_subs=7;
	}
	//
	if      (dist_ref_prov_to_subs<=1) dist_ref_prov_to_subs_risk=0.01881;
	else if (dist_ref_prov_to_subs<=2) dist_ref_prov_to_subs_risk=0.02575;
	else if (dist_ref_prov_to_subs<=3) dist_ref_prov_to_subs_risk=0.02762;
	else if (dist_ref_prov_to_subs<=4) dist_ref_prov_to_subs_risk=0.04066;
	else                               dist_ref_prov_to_subs_risk=0.04487;
	//--------------------------------------------------------------------//
	if (npi_aggs.av12w.ave_daily_minutes<=90) npi_av12w_ave_daily_minutes_risk=0.03390;
        else                                      npi_av12w_ave_daily_minutes_risk=0.05606;
	//--------------------------------------------------------------------//
	if      (npi_aggs.av4w.ave_bill_amt_per_day<= 333) npi_av4w_ave_bill_amt_per_day_risk=0.03444;
	else if (npi_aggs.av4w.ave_bill_amt_per_day<=3164) npi_av4w_ave_bill_amt_per_day_risk=0.04014;
	else if (npi_aggs.av4w.ave_bill_amt_per_day<=8494) npi_av4w_ave_bill_amt_per_day_risk=0.06625;
	else                                               npi_av4w_ave_bill_amt_per_day_risk=0.18662;
	//--------------------------------------------------------------------//
	if (npi_aggs.av8w.ave_diag_proc_compare<=0.1) npi_av8w_ave_diag_proc_compare_risk=0.05429;
	else                                          npi_av8w_ave_diag_proc_compare_risk=0.03471;
	//--------------------------------------------------------------------//
	if (npi_aggs.av8w.ave_daily_minutes<=100) npi_av8w_ave_daily_minutes_risk=0.03434;
	else                                      npi_av8w_ave_daily_minutes_risk=0.05955;
	//--------------------------------------------------------------------//
	npi_av8_12w_ave_daily_minutes_risk =
	    + (10.674162965519) * npi_av12w_ave_daily_minutes_risk
	    + ( 4.731041263027) * npi_av8w_ave_daily_minutes_risk
	;
	//--------------------------------------------------------------------//
	if      (cv.num_diag_codes==1) num_diag_codes_risk=0.04749;
	else if (cv.num_diag_codes<=3) num_diag_codes_risk=0.03044;
	else                           num_diag_codes_risk=0.03905;
	//--------------------------------------------------------------------//
	if      (cv.number_of_lines<=3) number_of_lines_risk=0.03508;
	else if (cv.number_of_lines<=4) number_of_lines_risk=0.04887;
	else if (cv.number_of_lines<=5) number_of_lines_risk=0.06489;
	else                            number_of_lines_risk=0.07812;
	//--------------------------------------------------------------------//
	if      (cv.number_of_modifiers<=0) number_of_modifiers_risk=0.03278;
	else if (cv.number_of_modifiers<=1) number_of_modifiers_risk=0.05023;
	else if (cv.number_of_modifiers<=2) number_of_modifiers_risk=0.02267;
	else if (cv.number_of_modifiers<=3) number_of_modifiers_risk=0.04152;
	else if (cv.number_of_modifiers<=7) number_of_modifiers_risk=0.08588;
	else                                number_of_modifiers_risk=0.11285;
	//--------------------------------------------------------------------//
	if (pat_aggs.av12w.ave_distance_from_home<=2) pat_av12w_ave_distance_from_home_risk=0.03489;
	else                                          pat_av12w_ave_distance_from_home_risk=0.04383;
	//--------------------------------------------------------------------//
	if (pat_aggs.av12w.number_of_lines<=39) pat_av12w_number_of_lines_risk=0.03699;
	else                                    pat_av12w_number_of_lines_risk=0.06264;
	//--------------------------------------------------------------------//
	if (pat_aggs.av4w.ave_diag_proc_compare<=0.196) pat_av4w_ave_diag_proc_compare_risk=0.05878;
	else                                            pat_av4w_ave_diag_proc_compare_risk=0.03228;
	//--------------------------------------------------------------------//
	if (pat_aggs.av4w.ave_proc_group_risk<=0.153) pat_av4w_ave_proc_group_risk=0.03063;
	else                                          pat_av4w_ave_proc_group_risk=0.05054;
	//--------------------------------------------------------------------//
	if (cv.pl_service_day_of_week_compare<=0.387) pl_service_day_of_week_compare_risk=0.02403;
	else                                          pl_service_day_of_week_compare_risk=0.04410;
	//--------------------------------------------------------------------//
	if (cv.proc_day_of_week_compare<=0.463) proc_day_of_week_compare_risk=0.03607;
	else                                    proc_day_of_week_compare_risk=0.04838;
	//--------------------------------------------------------------------//
	if (cv.proc_to_age_compare<0.59) proc_to_age_compare_ave_risk=0.03074;
	else                             proc_to_age_compare_ave_risk=0.05056;
	//--------------------------------------------------------------------//
	if      (cv.proc_to_place_of_service_compare<=0.820) proc_to_place_of_service_compare_risk=0.03839;
	else if (cv.proc_to_place_of_service_compare<=0.988) proc_to_place_of_service_compare_risk=0.07268;
	else                                                 proc_to_place_of_service_compare_risk=0.03149;
	//--------------------------------------------------------------------//
	if (taxo4_risk_tbl.containsKey(claim.provider_taxo4)) {
	    provider_taxo4_risk=taxo4_risk_tbl.get(claim.provider_taxo4).doubleValue();
	} else {
	    provider_taxo4_risk=0.04908;
	}
	//--------------------------------------------------------------------//
	if      (subs_to_bill<=0) subs_to_bill_risk=0.03916;
	else if (subs_to_bill<=1) subs_to_bill_risk=0.07809;
	else if (subs_to_bill<=2) subs_to_bill_risk=0.02933;
	else if (subs_to_bill<=3) subs_to_bill_risk=0.03253;
	else if (subs_to_bill<=4) subs_to_bill_risk=0.04000;
	else if (subs_to_bill<=5) subs_to_bill_risk=0.05204;
	else if (subs_to_bill<=6) subs_to_bill_risk=0.07321;
	else                      subs_to_bill_risk=0.03961;
	//--------------------------------------------------------------------//
	if (cv.taxo4_day_of_week_compare<=0.468) taxo4_day_of_week_compare_risk=0.03608;
	else                                     taxo4_day_of_week_compare_risk=0.04922;
	//--------------------------------------------------------------------//
	if (cv.taxo4_to_diag_compare<=0.297) taxo4_to_diag_compare_risk=0.04367;
	else                                 taxo4_to_diag_compare_risk=0.03425;
	//--------------------------------------------------------------------//
	if (cv.taxo4_to_dist_to_home_compare<=0.584) taxo4_to_dist_to_home_compare_risk=0.04597;
	else                                         taxo4_to_dist_to_home_compare_risk=0.03154;
	//--------------------------------------------------------------------//
	if      (cv.diag_to_pl_service_compare<=0.013) diag_to_pl_service_compare_risk=0.03592;
	else if (cv.diag_to_pl_service_compare<=0.088) diag_to_pl_service_compare_risk=0.07286;
	else                                           diag_to_pl_service_compare_risk=0.03409;
	//--------------------------------------------------------------------//
	if      (cv.taxo4_to_proc_compare<=0.008) taxo4_to_proc_compare_risk=0.09036;
	else if (cv.taxo4_to_proc_compare<= 0.28) taxo4_to_proc_compare_risk=0.04711;
	else                                      taxo4_to_proc_compare_risk=0.03161;
	//--------------------------------------------------------------------//
	if      (cv.taxo4_to_pl_service_compare<=0.002) taxo4_to_pl_service_compare_risk=0.02981;
	else if (cv.taxo4_to_pl_service_compare<=0.019) taxo4_to_pl_service_compare_risk=0.12816;
	else                                            taxo4_to_pl_service_compare_risk=0.03382;
	//--------------------------------------------------------------------//
	sum = -11.964713
	    + (17.609351093793) * address_match_type_risk
	    + ( 5.331421612335) * age_risk
	    + ( 2.886536265778) * age_group_day_of_week_compare_risk
	    + ( 1.097367392732) * ave_mod_risk
	    + ( 4.091951971702) * claim_minutes_risk
	    + ( 0.049608810107) * day_of_week_risk
	    + ( 4.806094945803) * diag_proc_measure_risk
	    + ( 7.960180756761) * diag_to_gender_compare_risk
	    + ( 0.951884441405) * diag_to_pl_service_compare_risk
	    + (12.683829148023) * dist_bill_to_nppes_risk
	    + (18.602192163195) * dist_ref_prov_to_subs_risk
	    + ( 6.047017122953) * facility_to_bill_risk
	    /*
	    + ( 4.731041263027) * npi_av8w_ave_daily_minutes_risk
	    + (10.674162965519) * npi_av12w_ave_daily_minutes_risk
	    */
	    + ( 1.000000000000) * npi_av8_12w_ave_daily_minutes_risk
	    + ( 4.645215775215) * npi_av4w_ave_bill_amt_per_day_risk
	    + (11.376036093109) * num_diag_codes_risk
	    + ( 4.373560069484) * number_of_lines_risk
	    + ( 7.539079655195) * number_of_modifiers_risk
	    + (11.388585363028) * pat_av12w_number_of_lines_risk
	    + ( 4.594709368968) * pat_av4w_ave_diag_proc_compare_risk
	    + ( 6.609798168616) * pat_av4w_ave_proc_group_risk
	    + ( 9.378430975519) * pl_service_day_of_week_compare_risk
	    + ( 6.043840467475) * place_of_service_code_risk
	    + ( 0.779967582363) * proc_day_of_week_compare_risk
	    + ( 0.803348413626) * proc_to_age_compare_ave_risk
	    + ( 2.600419549250) * proc_to_place_of_service_compare_risk
	    + (15.968518582724) * provider_taxo4_risk
	    + (11.056193798066) * taxo4_day_of_week_compare_risk
	    + ( 6.918049571882) * taxo4_to_dist_to_home_compare_risk
	    + ( 8.707615179789) * taxo4_to_pl_service_compare_risk
	    + ( 3.008211196456) * taxo4_to_proc_compare_risk
	    + ( 3.128180461315) * total_claim_charge_risk
	;
	double e_sum=Math.exp(sum);
	double score=e_sum/(1+e_sum);
	sum_logreg=sum;
	pv_score = (int) Math.max(1,Math.min(999,1000*score));
	// The disposition of the case
	if      (pv_score<low_threshold)  disposition="A";
	else if (pv_score<high_threshold) disposition="W";
	else                              disposition="N";
	//--------------------------------------------------------------------//
	factors =new Factor[] {
	    new Factor("address_match_type_risk"               ,address_match_type_risk 	       ,17.609351093793,0.039610, 1),
	    new Factor("age_risk"                              ,age_risk            	               , 5.331421612335,0.039535, 2),
	    new Factor("age_group_day_of_week_compare_risk"    ,age_group_day_of_week_compare_risk     , 2.886536265778,0.039604,-1),
	    new Factor("ave_mod_risk"                          ,ave_mod_risk                           , 1.097367392732,0.039467,-1),
	    new Factor("claim_minutes_risk"                    ,claim_minutes_risk		       , 4.091951971702,0.041453, 3),
	    new Factor("day_of_week_risk"                      ,day_of_week_risk                       , 0.049608810107,0.039668, 4),
	    new Factor("diag_proc_measure_risk"                ,diag_proc_measure_risk                 , 4.806094945803,0.039484, 5),
	    new Factor("diag_to_gender_compare_risk"           ,diag_to_gender_compare_risk	       , 7.960180756761,0.039568, 6),
	    new Factor("diag_to_pl_service_compare_risk"       ,diag_to_pl_service_compare_risk	       , 0.951884441405,0.039524,-1),
	    new Factor("dist_bill_to_nppes_risk"               ,dist_bill_to_nppes_risk		       ,12.683829148023,0.039428, 7),
	    new Factor("dist_ref_prov_to_subs_risk"            ,dist_ref_prov_to_subs_risk	       ,18.602192163195,0.040991, 8),
	    new Factor("facility_to_bill_risk"                 ,facility_to_bill_risk		       , 6.047017122953,0.038076, 9),
	    /*new Factor("npi_av8w_ave_daily_minutes_risk"       ,npi_av8w_ave_daily_minutes_risk	 , 4.731041263027,0.039915,15),*/
	    /*new Factor("npi_av12w_ave_daily_minutes_risk"      ,npi_av12w_ave_daily_minutes_risk       ,10.674162965519,0.039917,13),*/
	    new Factor("npi_av8_12w_ave_daily_minutes_risk"    ,npi_av8_12w_ave_daily_minutes_risk     , 1.000000000000,0.614920,10),
	    new Factor("npi_av4w_ave_bill_amt_per_day_risk"    ,npi_av4w_ave_bill_amt_per_day_risk     , 4.645215775215,0.039587,11),
	    new Factor("num_diag_codes_risk"                   ,num_diag_codes_risk		       ,11.376036093109,0.039610,12),
	    new Factor("number_of_lines_risk"                  ,number_of_lines_risk		       , 4.373560069484,0.039461,13),
	    new Factor("number_of_modifiers_risk"              ,number_of_modifiers_risk	       , 7.539079655195,0.039376,14),
	    new Factor("pat_av12w_number_of_lines_risk"        ,pat_av12w_number_of_lines_risk	       ,11.388585363028,0.039565,15),
	    new Factor("pat_av4w_ave_diag_proc_compare_risk"   ,pat_av4w_ave_diag_proc_compare_risk    , 4.594709368968,0.041311,-1),
	    new Factor("pat_av4w_ave_proc_group_risk"          ,pat_av4w_ave_proc_group_risk           , 6.609798168616,0.039606,16),
	    new Factor("pl_service_day_of_week_compare_risk"   ,pl_service_day_of_week_compare_risk    , 9.378430975519,0.039632,-1),
	    new Factor("place_of_service_code_risk"            ,place_of_service_code_risk	       , 6.043840467475,0.036657,17),
	    new Factor("proc_day_of_week_compare_risk"         ,proc_day_of_week_compare_risk	       , 0.779967582363,0.039598,-1),
	    new Factor("proc_to_age_compare_ave_risk"          ,proc_to_age_compare_ave_risk	       , 0.803348413626,0.039606,-1),
	    new Factor("proc_to_place_of_service_compare_risk" ,proc_to_place_of_service_compare_risk  , 2.600419549250,0.039559,-1),
	    new Factor("provider_taxo4_risk"                   ,provider_taxo4_risk		       ,15.968518582724,0.039678,18),
	    new Factor("taxo4_day_of_week_compare_risk"        ,taxo4_day_of_week_compare_risk	       ,11.056193798066,0.039594,-1),
	    new Factor("taxo4_to_dist_to_home_compare_risk"    ,taxo4_to_dist_to_home_compare_risk     , 6.918049571882,0.039612,19),
	    new Factor("taxo4_to_pl_service_compare_risk"      ,taxo4_to_pl_service_compare_risk       , 8.707615179789,0.039452,-1),
	    new Factor("taxo4_to_proc_compare_risk"            ,taxo4_to_proc_compare_risk	       , 3.008211196456,0.039502,20),
	    new Factor("total_claim_charge_risk"               ,total_claim_charge_risk                , 3.128180461315,0.039578,21)
	};
	deltas = new ArrayList<Factor>();
	for (Factor f : factors) deltas.add(f);
	Collections.sort(deltas);
	// The reason codes;
	reasons             = new String[]{"00","00","00","00"};
	reasons_description = new String[]{"","","",""};
	int reasons_so_far=0;
	for (int i=0;((reasons_so_far<4)&&(i<deltas.size()));i++) {
	    Factor f=deltas.get(i);
	    String reason_descr = reason_desc.get(f.vname);
	    // Skip the reason if (or):
	    //      - The delta is negative.
	    //      - The reason description is "?"
	    //      - There is no provider taxonomy code and the reason is related to the taxonomy code
	    boolean skip_reason = false;
	    skip_reason = skip_reason || (f.delta<0);
	    skip_reason = skip_reason || reason_descr.equals("?");
	    skip_reason = skip_reason || ((f.index==18)||(f.index==19)||(f.index==20))&&(claim.provider_taxo4.equals("")||claim.provider_taxo4.equals("null"));
	    // Only consider the reason if the delta is positive and this is not a reasons the we want to skip.
	    if (!skip_reason) {
		reasons[reasons_so_far]=String.format("%02d",f.index);
		reasons_description[reasons_so_far]=reason_descr;
		reasons_so_far++;
	    }
	}
	// Only quote four reasons if score is high
	if (disposition.equals("A")) {
	    reasons = new String[] {"00","00","00","00"};
	    reasons_description = new String[]{"","","",""};
	} else if (disposition.equals("W")) {
	    reasons[2]="00";
	    reasons[3]="00";
	    reasons_description[2]="";
	    reasons_description[3]="";
	}
	//--------------------------------------------------------------------//
    }

    public static String getHeader() {
	String header ="";
	//
	header = header + "claim_id";
	header = header + ",tin";
	header = header + ",disposition";
	header = header + ",score";
	header = header + ",reason1";
	header = header + ",reason2";
	header = header + ",reason3";
	header = header + ",reason4";
	header = header + ",address_match_score";
	header = header + ",address_match_type";
	header = header + ",name_match_score";
	header = header + ",n_npi_sanctions";
	header = header + ",npi_sanc_types";
	header = header + ",n_tin_sanctions";
	header = header + ",tin_sanc_types";
	header = header + ",fraud_address_match_score";
	header = header + ",fraud_address_match_type";
	//
	return header;
    }

    public String toString() {
	StringBuffer sb = new StringBuffer();
	Formatter fmt = new Formatter(sb);
	//
	fmt.format("%s",claim.claim_id);
	fmt.format(",%s",claim.tin);
	fmt.format(",%s",disposition);
	fmt.format(",%d",pv_score);
	fmt.format(",%s",reasons[0]);
	fmt.format(",%s",reasons[1]);
	fmt.format(",%s",reasons[2]);
	fmt.format(",%s",reasons[3]);
	fmt.format(",%d",address_match_score);
	fmt.format(",%d",address_match_type);
	fmt.format(",%d",name_match_score);
	fmt.format(",%d",n_npi_sanctions);
	fmt.format(",%s",npi_sanc_types);
	fmt.format(",%d",n_tin_sanctions);
	fmt.format(",%s",tin_sanc_types);
	fmt.format(",%d",fraud_address_match_score);
	fmt.format(",%d",fraud_address_match_type);
	//
	return sb.toString();
    }

    public int getScore() {
	return pv_score;
    }

    public String getDisposition() {
	return disposition;
    }

    public String getReason1() {
	return reasons[0];
    }

    public String getReason2() {
	return reasons[1];
    }

    public String getReason3() {
	return reasons[2];
    }

    public String getReason4() {
	return reasons[3];
    }

    public int getAddressMatchScore() {
	return address_match_score;
    }

    public String getAddressMatchRate() {
	if      (address_match_score==0) return "no match or not populated";
	else if (address_match_score==1) return "poor match";
	else if (address_match_score==2) return "fair match";
	else if (address_match_score==3) return "good match";
	else if (address_match_score==4) return "exact match";
	return "";
    }

    public int getAddressMatchType() {
	return address_match_type;
    }

    public int getNameMatchScore() {
	return name_match_score;
    }

    public String getNameMatchRate() {
	if      (name_match_score==0) return "no match or not populated";
	else if (name_match_score==1) return "poor match";
	else if (name_match_score==2) return "fair match";
	else if (name_match_score==3) return "good match";
	else if (name_match_score==4) return "exact match";
	return "";
    }

    public int getNumberNPISanctions() {
	return n_npi_sanctions;
    }

    public String getNPISanctionTypes() {
	return npi_sanc_types;
    }

    public int getNumberTINSanctions() {
	return n_tin_sanctions;
    }

    public String getTINSanctionTypes() {
	return tin_sanc_types;
    }

    public int getFraudAddressMatchScore() {
	return fraud_address_match_score;
    }

    public String getFraudAddressMatchRate() {
	if      (fraud_address_match_score==0) return "no match or not populated";
	else if (fraud_address_match_score==1) return "poor match";
	else if (fraud_address_match_score==2) return "fair match";
	else if (fraud_address_match_score==3) return "good match";
	else if (fraud_address_match_score==4) return "exact match";
	return "";
    }

    /**
     * 1: claim billing address match to fraud address
     * 2: claim facility address match to fraud address
     */
    public int getFraudAddressMatchType() {
	return fraud_address_match_type;
    }
}
