import pyspark
import pyspark.sql.functions as F
from pyspark.sql.functions import udf
from pyspark.sql import types as T
import datetime
import sys
import pyspark
from pyspark.sql import SparkSession
from datetime import datetime
from datetime import date, timedelta

import requests
from pyspark.sql import SQLContext
from dateutil.relativedelta import relativedelta
import re


#Database
prod_db = "pi_prod"
prod_tmp_db = "pi_usrs"

#input table
history_data = "ps_history"

#output table
npi_agg_json = "ps_npi_score"
npi_month_table = "ps_npi_month_table"

col_list =  ['billed_amt_sum',
             'clm_ln_cnt',
             'clm_unit_billed',
             'proc_code_unusual',
             'pos_unsual',
             'em_proc_ind',
             'mod91_ind',
             'modTC_ind',
             'mod59_ind',
             'high_cst_proc_ind',
             'emgncy_ind']


reason_desc = {'billed_amt_sum'    : 'Billed Amount is higher than expected.',
               'clm_ln_cnt'        : 'No. of claim lines is higher than expected.',
               'clm_unit_billed'   : 'Total units billed is higher than expected.',
               'em_proc_ind'       : 'Use of E&M code(s)',
               'emgncy_ind'        : "Service without an Emergency Indicator was performed at 'Emergency' place of service",
               'high_cst_proc_ind' : 'Use of high cost JCode procedure',
               'mod59_ind'         : 'Use of Modifier 59',
               'mod91_ind'         : 'Use of Modifier 91',
               'modTC_ind'         : 'Use of Modifier TC',
               'pos_unsual'        : 'Unusual place of service observed',
               'proc_code_unusual' : 'Unusual procedure code observed.'}
    

@udf(returnType=T.FloatType())
def calc_cont(d,x,i):
    return float(d)*x[i]

@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct( ):
    a = { }
    return a

@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct1(b, x, i):
    x[i] = b
    return x

@udf(T.ArrayType(T.StringType()))
def rsn_selection(x):
    sorted_dict = sorted(x.items(), key=lambda x: x[1], reverse=True)
    arr = []
    count=0
    for i in sorted_dict:
        count=count+1
        if i[1] > 0:
            arr.append(i[0])    
        if count> 4:
            break
    return arr

@udf(T.StringType())
def func_reason(arr, col_index):  
    if col_index in range(len(arr)):
        feature = arr[col_index]
        return reason_desc[feature]
    else:
        return 'NA'

#getting minimum and maximum batch ids
minimum = 20210301001   #will be updated by API
maximum = 20210315099   #will be updated by API

start_dt = int(str(minimum)[0:6]+'01')
start_month = int(str(start_dt)[0:6])
end_month = int(str(maximum)[0:6])

today = date.today()
current_date = today.strftime("%Y%m%d")

query = """select servicing_npi, claim_number, fln_nbr, batch_run_dt, md, dict, ps_Reason1, ps_Reason2, ps_Reason3, ps_Reason4, ps_Reason5, ps_Reason6, ps_Reason7, ps_Reason8, ps_Reason9, ps_Reason10, ps_Reason11
 from """+prod_db+"""."""+history_data+""" where batch_run_dt < '"""+str(current_date)+"""' and batch_run_dt >= '"""+str(start_dt)+"""'
 and batchid <= '"""+str(maximum)+"""' """

base_data = spark.sql(query)

base_data = base_data.withColumn("batch_month",F.from_unixtime(F.unix_timestamp(F.col("batch_run_dt"),'yyyyMMdd'),'yyyyMM'))

grouping_level= ['servicing_npi', 'batch_month']
claim_col = ['claim_number', 'fln_nbr','batch_run_dt', 'md', 'ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11']

base_data = base_data.withColumn('claim_data',F.struct([base_data[x] for x in claim_col]))

#Aggregation on NPI level

#Total Claims and claims_data
agg_data = base_data.groupby(grouping_level).agg(F.count('*').alias("total_claims"), F.to_json(F.collect_list(F.col('claim_data'))).alias("claim_data"))


#Flagged Claims & Severity & scaled dict & reason gens
flagged_data = base_data.where(F.size("dict")>0)
for i in  col_list:
    flagged_data = flagged_data.withColumn(i+"_cont" ,calc_cont( F.col('md'), F.col("dict"), F.lit(i) ) )

#Calculating the overall contributions of each feature in md in aggregated data
flagged_agg = flagged_data.groupby(grouping_level).agg(*[F.sum(f+"_cont") for f in col_list] + [F.count('*').alias("flagged_claims"),F.expr('percentile_approx(md, 0.5)').alias('severity')])
flagged_agg = flagged_agg.withColumn("scaled_dict" , create_struct( ) )

for i in col_list:
    flagged_agg = flagged_agg.withColumn("scaled_dict" ,create_struct1( F.col("sum({}_cont)".format(i)), F.col("scaled_dict"), F.lit(i) ) )

flagged_agg = flagged_agg.withColumn("sorted_dict", rsn_selection(F.col("scaled_dict")))

for i in range(0, 5):
    flagged_agg = flagged_agg.withColumn("reason"+ str(i+1) , func_reason(F.col("sorted_dict") , F.lit(i)))

col_to_drop = [i for i in flagged_agg.columns if 'sum(' in i] + ['sorted_dict'] 
flagged_agg = flagged_agg.drop(*col_to_drop)

agg_data = agg_data.join(flagged_agg, on= grouping_level, how='left')
agg_data = agg_data.fillna({'flagged_claims':0, 'severity':0})
agg_data = agg_data.fillna('NA')

#Flagged_Freq
agg_data = agg_data.withColumn('flagged_freq',F.col('flagged_claims')/F.col('total_claims'))

#Score and batch_month
agg_data = agg_data.withColumn('score',F.col('flagged_freq')*F.col('severity'))

sql("ALTER TABLE {}.{} DROP IF EXISTS PARTITION (batch_month = '{}'), PARTITION (batch_month = '{}')".format(prod_tmp_db, npi_month_table, start_month, end_month))

agg_data.write.partitionBy("batch_month").mode("append").saveAsTable("{}.{}".format(prod_tmp_db, npi_month_table))


#################################################################################################
#coverting columns of npi_month_table to json string


data_dur = 12

start_month = int((datetime.strptime(str(end_dt), '%Y%m%d') - relativedelta(months = (data_dur-1))).strftime('%Y%m'))

agg_data = sql("select * from {}.{} where batch_month >= {}".format(prod_tmp_db, npi_month_table, start_month))
agg_data = agg_data.withColumn('batch_month', F.from_unixtime(F.unix_timestamp(F.col('batch_month'),'yyyyMM'),'MMM-yyyy'))

#overall aggregation
agg_data = agg_data.withColumn('num',F.col('flagged_claims')*F.col('severity'))
comp_data = agg_data.groupby('servicing_npi').agg(*[F.sum('scaled_dict.' + i).alias('comp_'+i) for i in col_list]+[(F.sum('total_claims')).alias('total_claims'),(F.sum('flagged_claims')).alias('flagged_claims'), (F.sum('flagged_claims')/F.sum('total_claims')).alias('flagged_freq'), (F.sum('num')).alias('num_sum'), (F.sum('num')/F.sum('total_claims')).alias('score')])

#filtering flagged NPIs only
comp_flagged = comp_data.where(F.col('flagged_claims') > 0)
comp_flagged = comp_flagged.withColumn("severity", F.col('num_sum')/F.col('flagged_claims'))

comp_flagged = comp_flagged.withColumn("comp_dict" , create_struct())
for i in col_list:
    comp_flagged = comp_flagged.withColumn("comp_dict" ,create_struct1( F.col("comp_{}".format(i)), F.col("comp_dict"), F.lit(i) ) )

comp_flagged = comp_flagged.withColumn("comp_dict_sorted", rsn_selection(F.col("comp_dict")))

for i in range(0, 5):
    comp_flagged = comp_flagged.withColumn("reason"+ str(i+1) , func_reason(F.col("comp_dict_sorted") , F.lit(i)))

comp_flagged = comp_flagged.select('servicing_npi', 'total_claims', 'flagged_claims', 'flagged_freq', 'severity', 'score', 'reason1', 'reason2', 'reason3', 'reason4', 'reason5')
comp_flagged = comp_flagged.fillna('NA')

comp_flagged = comp_flagged.withColumn('ps_overall_dist',F.to_json(F.struct(F.col('total_claims'), F.col('flagged_claims'), F.col('flagged_freq'), F.col('severity') ,F.col('score'), F.col('reason1'), F.col('reason2'), F.col('reason3'), F.col('reason4'), F.col('reason5'))))
comp_flagged = comp_flagged.select('servicing_npi','ps_overall_dist')

#formating
agg_data = agg_data.withColumn('claim_data', F.concat(F.lit('{"claim_data": '), 'claim_data', F.lit('}')))
json_schema = spark.read.json(agg_data.rdd.map(lambda x: x['claim_data'])).schema
agg_data = agg_data.withColumn('claim_data', F.from_json(F.col('claim_data'), json_schema))
agg_data = agg_data.withColumn('scaled_dict',F.array('scaled_dict'))


out_col = ['servicing_npi', 'num', 'claim_data']


value_col = [c for c in agg_data.columns if c not in out_col]

final_data = agg_data.groupby('servicing_npi').agg(F.to_json(F.collect_list(F.struct([agg_data[x] for x in value_col]+[agg_data['claim_data.claim_data']]))).alias("ps_month_dist"))

final_data = final_data.join(comp_flagged, on = 'servicing_npi', how = 'inner')

final_data = final_data.withColumn('ps_flag', F.lit(1))


# this table will be merged with pi_prod.Sherlock_npi_encyclopedia
final_data.write.mode("overwrite").saveAsTable("{}.{}".format(prod_tmp_db, npi_agg_json))
