

data = get_raw_data_batch_s(batch_id)
data.cache()
data.count()

##garbage_clm_tb = "pi_usrs.sr_ps_test"


preprocessed_data = data_preprocessing_s(data)
data.unpersist()


features = generate_signal_s(preprocessed_data, ['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt'], em_proc_code_list, high_cost_jcode_list)


# Reading input tables
m_data  = "{}.{}".format(prod_tmp_db, mean_data)                      # Change to prod_db
mean_data = spark.table(m_data)
i_data  = "{}.{}".format(prod_tmp_db, icov_data)
icov_data = spark.table(i_data)                                       # Change to prod_db
 

imputed_data =  data_imputation_scoring(features, mean_data, icov_data)
imputed_data[0].cache()
imputed_data[0].count()


flagged_data = clm_scoring(imputed_data[0])
a = [col for col in flagged_data[0].columns if col.startswith("covar")]
flg_data= flagged_data[0].drop(*a)
flg_data.cache()
flg_data.count()

	
data_rsn = reason_gen(flg_data)
data_rsn = data_rsn.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md', 'dict', 'ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11'] + col_list)
data_complete = data_rsn.union(flagged_data[1])

data_history = data_complete.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md', 'dict'] + col_list).union(imputed_data[1])
data_history.write.mode("append").saveAsTable(prod_tmp_db + "." + history_data)

data_score = data_complete.select(['servicing_npi', 'claim_number', 'md', 'ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11'])
w = Window.partitionBy("claim_number").orderBy(F.desc("md"))
data_score = data_score.withColumn("rank", F.row_number().over(w)).filter(F.col("rank") == 1)
data_score = data_score.withColumnRenamed("md", "ps_score").drop("rank", "servicing_npi")
data_score = data_score.withColumn("ps_discrepancy_flag", F.lit("NA"))
data_score.createOrReplaceTempView("data_score")

# insert into claim DTO Hbase table
sql("insert into {}.{} select * from data_score".format(prod_tmp_db, ps_clm_output))









        