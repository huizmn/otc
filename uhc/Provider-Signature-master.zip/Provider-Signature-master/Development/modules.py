
batch_id = 20200630074   # Has to be changed to latest batch id dynamically

prod_db = "pi_prod"
prod_tmp_db = "pi_usrs"
claimdto_table = "claimdto"
service_table = "servicelinedto"
preprocessed_table = "processed_claims"
em_proc_code_list = ['99204', '99205', '99214', '99215', '99222', '99223', '99232', '99233']
high_cost_jcode_list = ['J9355', 'J1459', 'J0885', 'J0135', 'J0570', 'J0584', 'J1602', 'J9999']
proc_cd_lb_table = "psm_lk_bck_s_cl_proc_cd"
pos_lb_table = "psm_lk_bck_s_cl_place_of_srcv"
mean_data = "psm_mean_data"
icov_data = "psm_icov_data"
history_data = "ps_history"
ps_clm_output = "ps_claims_score"

col_list =  ['billed_amt_sum',
             'clm_ln_cnt',
             'clm_unit_billed',
             'proc_code_unusual',
             'pos_unsual',
             'em_proc_ind',
             'mod91_ind',
             'modTC_ind',
             'mod59_ind',
             'high_cst_proc_ind',
             'emgncy_ind']

threshold = 30


reason_desc = {'billed_amt_sum'    : 'Billed Amount is higher than expected. Average Value = {avg}',
               'clm_ln_cnt'        : 'No. of claim lines is higher than expected. Average Value = {avg}',
               'clm_unit_billed'   : 'Total units billed is higher than expected. Average Value = {avg}',
               'em_proc_ind'       : 'Use of E&M code(s)',
               'emgncy_ind'        : "Service without an Emergency Indicator was performed at 'Emergency' place of service",
               'high_cst_proc_ind' : 'Use of high cost JCode procedure',
               'mod59_ind'         : 'Use of Modifier 59',
               'mod91_ind'         : 'Use of Modifier 91',
               'modTC_ind'         : 'Use of Modifier TC',
               'pos_unsual'        : 'Unusual place of service observed. Used {avg}% only in past 3 months',
               'proc_code_unusual' : 'Unusual procedure code observed. Used {avg}% only in past 3 months'}
    







import pyspark.sql.functions as F
from pyspark.sql.types import DoubleType, StringType, ArrayType
from pyspark.sql.functions import udf, regexp_replace
from scipy import stats
from pyspark.sql import types as T


def get_raw_data_batch_s(batch_id):
    """
    Extract the Data for latest Batch from Claim and Service DTO
    
    Parameter:
        batch_id (str):  Input batchid.
        
    """
    key_start = str(batch_id) + '000000000000000'
    key_end = str(batch_id+1) + '000000000000000'
    line_key_start = key_start + '000'
    line_key_end = key_end + '000'
    try:
        claim_data = sql(""" SELECT key as claim_number , clm_bill_prov_npi, fln_nbr, clm_bill_prov_tin, clm_bill_prov_ssn FROM  {prod_db}.{claimdto_table} 
                          where key >= '{key_start}' and key  < '{key_end}' """.format(prod_db = prod_db , claimdto_table = claimdto_table, key_start = key_start , key_end = key_end))
        service_data = sql(""" SELECT distinct substring(srk_clm_id,0,26) as clm_nbr,  cl_rend_prov_npi, batch_run_dt, batchid, cl_proc_cd, cl_proc_mod1, cl_proc_mod2, cl_proc_mod3,
                      cl_proc_mod4, cl_line_item_chrg_amt, cl_place_of_srcv, cl_emergency_ind, cl_units_billed from {prod_db}.{service_table}
                      WHERE key >= '{line_key_start}' and key < '{line_key_end}' """.format(prod_db = prod_db , service_table = service_table, line_key_start = line_key_start , line_key_end = line_key_end))
        data = claim_data.join(service_data, claim_data.claim_number == service_data.clm_nbr, how = "left"). drop("clm_nbr")
        return data
    except Exception as e:
        print(e)




def data_preprocessing_s(raw_table):
    """
    Preprocessing includes,
        ? Data Wrangling  
        ? Data Cleaning
        ? Data Splitting
    Returns:
        Output table
        
    """
    try:
        raw_data_col = raw_table.columns
        wrangle_data = data_wrangling(data = raw_table, col_to_trim = raw_data_col)
        # Data Cleaning
        preprocessed_tb = "{}.{}".format(prod_tmp_db, preprocessed_table)
        clean_data = data_cleaning(data = wrangle_data)
        clean_data.write.mode("overwrite").saveAsTable(preprocessed_tb)
        preprocessed_data = spark.table(preprocessed_tb)
        return preprocessed_data
    except Exception as e:
        print(e)



def data_wrangling(data, col_to_trim):
    """
    This function includes, 
        ? Trimming of all the columns present in the data
        ? Casting of cl_line_item_chrg_amt & cl_unit_billed from StringType to DoubleType (Float).
        ? Creation of servicing_npi, rule -> When cl_rend_prov_npi is null or empty populate clm_bill_prov_npi otherwise populate cl_rend_prov_npi.
        ? Creation of cl_emergency_ind, rule -> When cl_emergency_ind =  "Y" populate 1 otherwise 0.
    Parameters:
        data (Pyspark Dataframe).
        col_to_trim (list):  List of columns      
    Returns:
        DataFrame (pySpark)
    """
    try:
        for col_ in col_to_trim:
            data = data.withColumn(col_, F.trim(data[col_]))
        data = data.withColumn("cl_line_item_chrg_amt", F.col("cl_line_item_chrg_amt").cast(DoubleType()))
        data = data.withColumn("cl_units_billed", F.col("cl_units_billed").cast(DoubleType()))
        data = data.withColumn("servicing_npi", 
                                       F.when(((F.col("cl_rend_prov_npi")=="") | F.col("cl_rend_prov_npi").isNull()),
                                              F.col("clm_bill_prov_npi")).otherwise(F.col("cl_rend_prov_npi")))
        data = data.withColumn("cl_emergency_ind", F.when(F.col("cl_emergency_ind") == "Y", 
                                                                  F.lit(1)).otherwise(F.lit(0)))
        return data
    except Exception as e:
        print(e)




def data_cleaning(data):
    """
    Data Cleaning is to identify and remove errors & duplicate data, in order to create a reliable dataset. This improves the quality of the data for analytics. Process includes,
    ? Dropping Claims having "NaN" and negative entry for 
        - cl_line_item_chrg_amt 
        - cl_unit_billed
    ? Dropping Claims having "Null" or "Blank" entries for 
        - servicing_npi
        - cl_proc_cd
        - Place of service
    ? Remove claims containing Place of service other than 01 to 99. 
    ? Remove claims containing NPI where the length is not equal to 10 digit or starting digit is not 1 nor 2.
    ? Remove claims containing modifiers which don�t have length  equal to 2.
    
    Parameters:
        data (Pyspark Dataframe) : Input Pyspark DataFrame
    """
    #Dropping claims having nan,  null or negative entry for cl_line_item_chrg_amt
    c = "cl_line_item_chrg_amt"
    print("Dropping claims having nan, null or negative entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter((F.isnan(c) | F.col(c).isNull() | (F.col(c) < 0)))
    garbage_clms = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms = garbage_clms.withColumn("Flag", F.lit(c))
    
    
    # Dropping claims having nan,  null or negative entry for cl_unit_billed
    c = "cl_units_billed"
    print("Dropping claims having nan, null or negative entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter((F.isnan(c) | F.col(c).isNull() | (F.col(c) < 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    #Dropping claims having null or blank or where the length is not equal to 10 or starting digit is not 1 nor 2 for servicing_npi
    c = "servicing_npi"
    print("Dropping claims having null, blank or where length is not equal to 10 or starting digit is not 1 nor 2 for {}".format(c))
    # Running validation check for NPI
    data = data.withColumn("valid_npi", npi_validator(c)) 
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "") | (data[c].isNull()) | (data["valid_npi"] == 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims having "null" or "blank" & value other than 01 to 99 for cl_place_of_srvc
    c = "cl_place_of_srcv"
    # Creating the place of service lookup list having elements ranging from 01 to 99.
    global pls_lookup_list
    pls_lookup_list = ["0" + str(i) for i in range(1, 10)] + [str(i) for i in range(1,100)]
    print("Dropping claims having null or blank or value other than 01 to 99 for {}".format(c))
    # Running validation check for place of service
    data = data.withColumn("valid_pls", place_of_srcv_validator(c)) 
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "") | (data[c].isNull()) | (data["valid_pls"] == 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims where proc_mod_cd length is not equal to 2 
    # Generating the list of modifier columns
    mod_col_list = [col_ for col_ in data.columns if "proc_mod" in col_]
    for c in mod_col_list:
        print("Dropping claims where length of {} is not equal to 2". format(c))
        dump_data = data.filter((data[c] != "") & (~data[c].isNull()) & (F.length(F.col(c)) !=2))
        garbage_clms1 = dump_data.select("claim_number")
        # Adding flag for identification
        garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
        garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims having null or blank entry for proc_cd
    c = "cl_proc_cd"
    print("Dropping claims having Null, blank entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "")|(data[c].isNull())))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    ## Filtering out good claims
    garbage_claims = garbage_clms.groupBy("claim_number").agg(F.collect_set("Flag").alias("ps_discrepancy_flag"))
    garbage_claims.createOrReplaceTempView("garbage_claims")
    #### Insert garbage_claims into claim DTO
    sql("insert into {}.{} select claim_number, 'NA' as ps_score, 'NA' as ps_Reason1, 'NA' as ps_Reason2, 'NA' as ps_Reason3, 'NA' as ps_Reason4, 'NA' as ps_Reason5, 'NA' as ps_Reason6, 'NA' as ps_Reason7, 'NA' as ps_Reason8, 'NA' as ps_Reason9, 'NA' as ps_Reason10, 'NA' as ps_Reason11, ps_discrepancy_flag from garbage_claims".format(prod_tmp_db, ps_clm_output))
          
    clean_data = data.join(garbage_claims, on="claim_number", how ="left")
    clean_data = clean_data.filter(F.col("ps_discrepancy_flag").isNull())
    clean_data = clean_data.withColumn("cl_place_of_srcv", F.lpad(clean_data["cl_place_of_srcv"], 2, '0'))
    
    return clean_data           
       

        
@udf("int")
def npi_validator(npi):
    """
    Valid NPI Checker, Rule for valid NPI: length of npi == 10, and starting digit should be 1 or 2.
    
    Parameter:
        npi (str).
        
    Returns:
        1 if the NPI is valid else False 0.
    """
    try:
        if (len(npi) == 10) & ((npi[0] == "2") | (npi[0] == "1")):
            return 1
        else:
            return 0
    except:
        return 0


@udf("int")
def place_of_srcv_validator(pls):
    """
    Check for valid place of service (01 to 99)
    
    Parameters:
        pls (string)
    
    Returns:
        1 if the place of service is valid else 0.
    """
    try:
        if (pls in pls_lookup_list):
            return 1
        else:
            return 0
    except:
        return 0        




def generate_signal_s(base_data, group_level, em_proc_code_list, high_cost_jcode_list):
    """
    Generate the following signal at claim level (Signals -> Definition -> Signal Type):
     - billed_amt_sum -> Billed Amount -> Continuous 
     - clm_ln_cnt -> Number of Claim Lines -> Continuous
     - clm_unit_billed -> Sum of billed units -> Continuous
     - em_proc_ind -> Indicator present 1, else 0 -> Discrete; Binary
     - high_cst_proc_ind -> Indicator present 1, else 0 -> Discrete; Binary
     - emgncy_ind -> If pos = 23 & em_ind = "No" then 1, else 0 -> Discrete; Binary
     - mod59_ind -> Indicator present 1, else 0 -> Discrete; Binary
     - mod91_ind -> Indicator present 1, else 0 -> Discrete; Binary
     - modTC_ind -> Indicator present 1, else 0 -> Discrete; Binary
     - proc_code_unusual -> If a new / unlikely proc code billed -> Continuous
     - pos_unusual -> If a new / unlikely place of service observed -> Continuous
    
    Parameters,
        base_table (str): Input hive table
        group_level :  Level of aggregation
    """
    try:
        ## Generating Signal at group level
        
        # 1. Billed Amount
        c = "billed_amt_sum"
        print("Generating {}".format(c))
        output_df = base_data.groupby(group_level).agg(F.sum("cl_line_item_chrg_amt").alias(c))
        
        # 2. Number of claim lines
        c = "clm_ln_cnt"
        print("Generating {}".format(c))
        clm_ln_cnt_data = base_data.groupby(group_level).agg(F.count("*").alias(c))
        output_df = output_df.join(clm_ln_cnt_data, on = group_level, how ="left")
        
        # 3. Sum of Unit Billed
        c = "clm_unit_billed"
        print("Generating {}".format(c))
        clm_unit_billed_data = base_data.groupby(group_level).agg(F.sum("cl_units_billed").alias(c))
        output_df = output_df.join(clm_unit_billed_data, on = group_level, how ="left")
        
        # 4. EM proc indicator 
        c = "em_proc_ind"
        print("Generating {}".format(c))
        em_proc_code_list = [i.strip() for i in em_proc_code_list]
        em_proc_code = spark.createDataFrame(em_proc_code_list, StringType()).withColumnRenamed("value", "cl_proc_cd")
        em_proc_code = em_proc_code.withColumn(c, F.lit(1))
        em_proc_ind_data = base_data.join(em_proc_code, on ="cl_proc_cd", how="left")
        em_proc_ind_data = em_proc_ind_data.fillna(0, subset = [c])
        em_proc_ind_clm_data = em_proc_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(em_proc_ind_clm_data, on = group_level, how ="left")
        
        # 5.  high cost proc indicator 
        c = "high_cst_proc_ind"
        print("Generating {}".format(c))
        high_cost_jcode_list = [i.strip() for i in high_cost_jcode_list]
        high_cost_jcode = spark.createDataFrame(high_cost_jcode_list, StringType()).withColumnRenamed("value", "cl_proc_cd")
        high_cost_jcode = high_cost_jcode.withColumn(c, F.lit(1))
        high_cst_proc_ind_data = base_data.join(high_cost_jcode, on ="cl_proc_cd", how="left")
        high_cst_proc_ind_data = high_cst_proc_ind_data.fillna(0, subset=[c])
        high_cost_proc_ind_clm_data = high_cst_proc_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(high_cost_proc_ind_clm_data, on = group_level, how ="left")
        
        # 6. Emergency indicator 
        c = "emgncy_ind"
        print("Generating {}".format(c))
        emrgncy_ind_data = base_data.withColumn(c, F.when(((F.col("cl_place_of_srcv")=="23")&(F.col("cl_emergency_ind")==0)),
                                                                 F.lit(1)).otherwise(F.lit(0)))
        emrgncy_ind_clm_data = emrgncy_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(emrgncy_ind_clm_data, on = group_level, how ="left")
        
        # Preparing data for Modifier signal
        mod_col = [c[0] for c in base_data.dtypes if "mod" in c[0]]
        data_mod = get_mod_data(base_data, group_level, mod_col)
        
        # 7. Modifier 59 indicator 
        c = "mod59_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="59", F.lit(1)).otherwise(F.lit(0)))
        mod59_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(mod59_ind_clm_data, on = group_level, how ="left")
        
        # 8. Modifier 91 indicator
        c = "mod91_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="91", F.lit(1)).otherwise(F.lit(0)))
        mod91_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(mod91_ind_clm_data, on = group_level, how ="left")
        
        # 9. Modifier TC indicator - TW
        c = "modTC_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="TC", F.lit(1)).otherwise(F.lit(0)))
        modTC_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(modTC_ind_clm_data, on = group_level, how ="left")
        
        # LookBack Features
        # 10. Unusal procedure code
        c = "proc_code_unusual"
        print("Generating {}".format(c))
        lb_group_level = ["servicing_npi", "cl_proc_cd"]
        # Reading Lookback lookup table
        lk_bck_s_tb_r  = "{}.{}".format(prod_tmp_db, proc_cd_lb_table)       #Change to prod_db
        proc_code_lb_data = spark.table(lk_bck_s_tb_r)
        # Merging the data	
        base_data_lb = base_data.select(group_level + ["cl_proc_cd"])
        proc_code_unusual_data = base_data_lb.join(proc_code_lb_data, on = lb_group_level, how = "left")
        # Aggregating the result at claim level
        proc_code_unusual_data = proc_code_unusual_data.fillna({"freq_dist":0})
        proc_code_unusual_data = proc_code_unusual_data.groupby(group_level).agg(F.min("freq_dist").alias(c))
        output_df = output_df.join(proc_code_unusual_data, on = group_level, how ="left")
        
        # 11. Unusal place of service
        c = "pos_unsual"
        print("Generating {}".format(c))
        lb_group_level = ["servicing_npi", "cl_place_of_srcv"]
        # Reading Lookback lookup table
        lk_bck_s_tb_r  = "{}.{}".format(prod_tmp_db, pos_lb_table)      # Change to prod_db
        pos_lb_data = spark.table(lk_bck_s_tb_r)
        # Merging the data
        base_data_lb = base_data.select(group_level + ["cl_place_of_srcv"])
        pos_unusual_data = base_data_lb.join(pos_lb_data, on = lb_group_level, how = "left")
        # Aggregating the result at claim level
        pos_unusual_data = pos_unusual_data.fillna({"freq_dist":0})
        pos_unusual_data = pos_unusual_data.groupby(group_level).agg(F.min("freq_dist").alias(c))
        output_df = output_df.join(pos_unusual_data, on = group_level, how ="left")
        
        return output_df
    except Exception as e:
            print(e)



def get_mod_data(data, level, mod_col):
    """
    Aggregate the modifier data at claim line level; covert the column oriented modifier data to row oriented
    
    Parameters:
        data (Pyspark DataFrame)
        level (list): aggregation level
        mod_col (list): List of modifier columns
    
    Returns:
        data_mod (Pyspark DataFrame)
    """
    try:
        data_mod = data.select(level + mod_col)
        data_mod = data_mod.withColumn("cl_proc_mod_list", F.array(mod_col)).select(level + ["cl_proc_mod_list"])
        data_mod =  data_mod.withColumn("cl_proc_mod", F.explode("cl_proc_mod_list")).select(level + ["cl_proc_mod"])
        return data_mod
    except Exception as e:
        print(e)



def data_imputation_scoring(data, mean_data, icov_data):
    """
    Impute the data lesser or equal to mean with mean for 'billed_amt_sum', 'clm_ln_cnt', 'clm_unit_billed' &
    Impute the data greter or equal to mean with mean for 'proc_code_unusual', 'pos_unsual' at servicing_npi level
    
    Paramaters:
        data (Pyspark DataFrame): Input scoring dataframe
        mean_data (Pyspark DataFrame)
        icov_data (Pyspark DataFrame)    
    Returns:
        ms_sprk (Pyspark DataFrame): Output Imputed scoring dataframe with inverse covariance elements and (u-v) 
    
    """
    try:
        imp_data = data.join(mean_data, on = "servicing_npi", how = "left")
        
        unscored_data = imp_data.filter(F.col('avg_billed_amt_sum').isNull())
        unscored_data = unscored_data.withColumn("dict" , create_struct( ) )
        unscored_data = unscored_data.withColumn("md" , F.lit("NA"))
        unscored_data = unscored_data.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md', 'dict'] + col_list)
         
        imputed_data = imp_data.filter(F.col('avg_billed_amt_sum').isNotNull())
        # Imputing the values lesser or equal to mean with mean
        for s in ['billed_amt_sum', 'clm_ln_cnt', 'clm_unit_billed', 'em_proc_ind', 'mod91_ind', 'modTC_ind', 'mod59_ind', 'high_cst_proc_ind', 'emgncy_ind']:
            s_avg = "avg_" + s
            s_i = "imp" + s
            imputed_data = imputed_data.withColumn(s_i, F.when((F.col(s) <= F.col(s_avg)), F.col(s_avg)).otherwise(F.col(s)))
        
        # Imputing the values greater or equal to mean with mean
        for s in ['proc_code_unusual', 'pos_unsual']:
            s_avg = "avg_" + s
            s_i = "imp" + s
            imputed_data = imputed_data.withColumn(s_i, F.when((F.col(s) >= F.col(s_avg)), F.col(s_avg)).otherwise(F.col(s)))
        
        ms_sprk = imputed_data.join(icov_data, how ="inner", on ="servicing_npi")
        
        ###### u - v ######
        for s in col_list:
            s_diff = s + "_diff"
            s_avg = "avg_{}".format(s)   
            ms_sprk = ms_sprk.withColumn(s_diff, F.col("imp"+s) - F.col(s_avg))
   
        return ms_sprk, unscored_data
    except Exception as e:
        print(e)



def clm_scoring(data):
    """`	`
    Flagged Anomalous claims and generate reason code
    
    Parameters:
        data (str) : Input Hive table 
    """
    try:
        
        ## Generating Claim Score -  Sq. Mahalanobis Distance
        scored_data = md_spark_df(data, col_list, "md")
        
        # Flagging the Anomalous claims
        flg_data = scored_data.filter(F.col("md") >= threshold)
        
        unflagged_data = scored_data.filter(F.col("md") < threshold)
        unflagged_data = unflagged_data.withColumn("dict" , create_struct( ) )
        unflagged_data.createOrReplaceTempView("unflagged_data")
        unflagged_data = sql("select servicing_npi, claim_number, fln_nbr, batch_run_dt, md, dict, 'NA' as ps_Reason1, 'NA' as ps_Reason2, 'NA' as ps_Reason3, 'NA'as ps_Reason4, 'NA' as ps_Reason5, 'NA' as ps_Reason6, 'NA' as ps_Reason7, 'NA' as ps_Reason8, 'NA' as ps_Reason9, 'NA' as ps_Reason10, 'NA' as ps_Reason11" + "," + ",".join(col_list) + " from unflagged_data")
        
        # Calculating Signal Effect on claim's M
        for i in col_list:
           flg_data = md_spark_df1(flg_data, col_list, i+"_md", i)
        
    
        return flg_data, unflagged_data
    except Exception as e:
        print(e) 



def md_spark_df(data, col_list, col_name):
    """
    Compute the Mahalanobis distance on Pyspark Dataframe. 
    
    Parameters:
        data (Pyspark Dataframe)
        col_list (list) : Signal list
        col_name : Name of column containing MD
    Returns:
        data (Pyspark Dataframe)
        
    """
    try:
        data = data.withColumn(col_name, F.lit(0))         
        
        for s in col_list:
            for s2 in col_list:
                s_covar = "covar_samp_{}_{}".format(s, s2)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(s+"_diff")*F.col(s2+"_diff")*F.col(s_covar)) )
            
        return data
    except Exception as e:
        print(e) 




def md_spark_df1(data, col_list, col_name, i):
    """
    Removes the effect of one element from Mahalanobis distance 
    
    Parameters:
        data (Pyspark Dataframe)
        col_list (list) : Signal list
        col_name : Name of column containing MD
    Returns:
        data (Pyspark Dataframe)
        
    """
    try:  
        data = data.withColumn(col_name, F.lit(0)) 
                 
        for s2 in col_list:
                s_covar = "covar_samp_{}_{}".format(i, s2)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(i+"_diff")*F.col(s2+"_diff")*F.col(s_covar)) )
        for s in col_list:
                s_covar = "covar_samp_{}_{}".format(s, i)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(s+"_diff")*F.col(i+"_diff")*F.col(s_covar)) )
        s_covar = "covar_samp_{}_{}".format(i, i)
        data = data.withColumn(col_name, F.col("md") - F.col(col_name) + (F.col(i+"_diff")*F.col(i+"_diff")*F.col(s_covar)) )
        
        return data
    except Exception as e:
        print(e) 




def reason_gen(data):
    """`	`
    Flagged Anomalous claims and generate reason code
    
    Parameters:
        s_table (str) : Input Hive table
        sg_level (float) : significance level for chi-square ppf test
        flg_table (str)  : Output hive table 
        clm_score_table (str) : Output hive table 
    
    """
    try:
        
        data = data.withColumn("dict" , create_struct( ) )
        data = data.withColumn("dict_avg" , create_struct( ) )
        
        for i in  col_list:
            data = data.withColumn("dict" ,create_struct1( (F.col("md") - F.col(i+"_md"))/(F.col("md")), F.col("dict"), F.lit(i) ) )  
        for i in  col_list:
            if i in ['proc_code_unusual', 'pos_unsual'] :
                 data = data.withColumn("dict_avg" ,create_struct1( F.col(i)*100, F.col("dict_avg"), F.lit(i) ) )     
            else :
                 data = data.withColumn("dict_avg" ,create_struct1( F.col("avg_"+i), F.col("dict_avg"), F.lit(i) ) )
        
        data = data.withColumn("dict" ,create_struct1( (F.col("md") - F.col("billed_amt_sum_md"))/ F.col("md"), F.col("dict"), F.lit("billed_amt_sum") ) )       
        data = data.withColumn("dict1", rsn_selection(F.col("dict")))
        
        
        for i in range(0, len(col_list)):
            data = data.withColumn("ps_Reason"+ str(i+1) , func_reason(F.col("dict1") , F.lit(i), F.col("dict_avg")))
        
        return data
        
    except Exception as e:
        print(e)



@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct( ):
    a = { }
    return a


@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct1(b, x, i):
    x[i] = b
    return x


@udf(ArrayType(StringType()))
def rsn_selection(x):
    sorted_dict = sorted(x.items(), key=lambda x: x[1], reverse=True)
    arr = []
    for i in sorted_dict:
        if i[1] < 0.1:
            break
        arr.append(i[0])
    return arr


@udf(StringType())
def func_reason(arr, col_index, dict_of_avg):  
    if col_index in range(len(arr)):
        feature = arr[col_index]
        val_of_avg = round(dict_of_avg[feature],2)
        return reason_desc[feature].format(avg = val_of_avg)
    else:
        return 'NA'

