import os
import pyspark
import datetime
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.types import DoubleType, StringType, ArrayType
from pyspark.sql.functions import udf, regexp_replace
from scipy import stats
from pyspark.sql import types as T
from pyspark.sql import Window
from pyspark import SparkFiles
from pyspark.sql import DataFrame
from pyspark.sql import catalog
import ConfigParser
from pyspark import SparkConf, SQLContext
from pyspark.sql import SparkSession
from datetime import datetime
import sys
import requests

start = datetime.now().replace(microsecond=0)
print(start)


mid = ['516']
module_id=""
module_name="empty"
status = ['Start','End','Error']

#paths
parent_path = sys.argv[10]
mapr_parent_path = sys.argv[11]
config_path = sys.argv[12]
tracking_url = sys.argv[14]+'UpdateModuleTrackingInfo'

#tracking_url = sys.argv[4]+'UpdateBatchModuleTrackingInfo'
#source_tracking_url = sys.argv[4]+'UpdateSourceTrackingInfo'
#getbatchid_url = sys.argv[14]+'GetBatchIDForBatchApp'
#updatebatchid_url = sys.argv[14]+'UpdateBatchStatus'
pid = sys.argv[16]
aid = sys.argv[17]
#sid = sys.argv[18]
uid = sys.argv[19]
py_libs = sys.argv[13]
memoryOverhead = sys.argv[20]
appname = sys.argv[1]
env = sys.argv[21]

portfolio_config_url = sys.argv[15] + 'GetPortfolioConfig'
source_config_url = sys.argv[15] + 'GetSourceConfig' 
app_config_url = sys.argv[15] + 'GetApplicationConfig'

spark = SparkSession \
    .builder \
    .appName("PS_Streaming").enableHiveSupport() \
    .getOrCreate()

spark.conf.set("spark.sql.shuffle.partitions",1)

sys.path.insert(0, py_libs)

#import portfolio config
portfolio_r = requests.post(portfolio_config_url,json={"PortfolioID":pid })
source_r = requests.post(source_config_url,json={"SourceID":aid })
app_r = requests.post(app_config_url,json={"ApplicationID":aid })
config_data = portfolio_r.json()
config_data_1 = source_r.json()
config_data_2 = app_r.json()

#application_name = sys.argv[12]
is_mock_run = filter(lambda x : x['Key'] == 'Is_Mock_Run', config_data_2)[0]['Value'].encode("utf-8")
database_name = filter(lambda x : x['Key'] == env+'_Hive_Database', config_data)[0]['Value'].encode("utf-8")
database_name_temp = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")
maprdb_path = filter(lambda x : x['Key'] == env+'_MapRDB_Path', config_data)[0]['Value'].encode("utf-8")
hdfs_parent_path = filter(lambda x : x['Key'] == env+'_HDFS_Parent_Path', config_data)[0]['Value'].encode("utf-8")

#hbase_claimDTO_table = (hdfs_parent_path+maprdb_path+"/"+claimDTO_table)
#hbase_servicelineDTO_table = (hdfs_parent_path+maprdb_path+"/"+servicelineDTO_table)


if is_mock_run == "":
 database_name = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")

############################## getting the configuration data from config.py file ######################################################################
print("portfolio-- ",portfolio_r)
print("source -- ",source_r)
print("config data-- ",config_data_1)
print("mock run-- ",is_mock_run)
print("Db name -- ",database_name)
print("Hdfs parent name -- ",hdfs_parent_path)
print("Maprdb name -- ",maprdb_path)
print("Db name temp -- ",database_name_temp)
print("environment-- ", env) 



def parameters(a,b,c):
	params = {
	"PortfolioID" : pid,
	"ApplicationID" : aid,
	"ModuleID" : a,
	"UserID" : uid,
	"Status" : b,
	"ErrorCode" : c
	}
	return params


def src_parameters(a,b):
    params = {
    "PortfolioID" : pid,
    "ApplicationID" : aid,
    "UserID" : uid,
    "Status" : a,
    "ErrorCode" : b
    }
    return params


print("############################################# Sherlock platform configurations #####################################################")
###arguments passed from java code

sc = spark.sparkContext
sqlc = SQLContext(sc)

data_source_format = "org.apache.hadoop.hbase.spark"

#start = datetime.now().replace(microsecond=0)

em_proc_code_list = ['99204', '99205', '99214', '99215', '99222', '99223', '99232', '99233']
high_cost_jcode_list = ['J9355', 'J1459', 'J0885', 'J0135', 'J0570', 'J0584', 'J1602', 'J9999']

col_list =  ['billed_amt_sum',
             'clm_ln_cnt',
             'clm_unit_billed',
             'proc_code_unusual',
             'pos_unsual',
             'em_proc_ind',
             'mod91_ind',
             'modTC_ind',
             'mod59_ind',
             'high_cst_proc_ind',
             'emgncy_ind']

threshold = 30


reason_desc = {'billed_amt_sum'    : 'Billed Amount is higher than expected. Average Value = {avg}',
               'clm_ln_cnt'        : 'No. of claim lines is higher than expected. Average Value = {avg}',
               'clm_unit_billed'   : 'Total units billed is higher than expected. Average Value = {avg}',
               'em_proc_ind'       : 'Use of E&M code(s)',
               'emgncy_ind'        : "Service without an Emergency Indicator was performed at 'Emergency' place of service",
               'high_cst_proc_ind' : 'Use of high cost JCode procedure',
               'mod59_ind'         : 'Use of Modifier 59',
               'mod91_ind'         : 'Use of Modifier 91',
               'modTC_ind'         : 'Use of Modifier TC',
               'pos_unsual'        : 'Unusual place of service observed. Used {avg}% only in past 3 months',
               'proc_code_unusual' : 'Unusual procedure code observed. Used {avg}% only in past 3 months'}




print("######################################### Function Starts ##############################")

def get_raw_data_batch_s(batch_id):
  
    key_start = str(batch_id) + '000000000000000'
    key_end = str(batch_id+1) + '000000000000000'
    line_key_start = key_start + '000'
    line_key_end = key_end + '000'
    try:
		claim_data = spark.sql("SELECT key as claim_number , clm_bill_prov_npi, fln_nbr, clm_bill_prov_tin, clm_bill_prov_ssn FROM base_claim_dto where key >= '{key_start}' and key  < '{key_end}' ".format( key_start = key_start , key_end = key_end))
		service_data = spark.sql("SELECT distinct substring(srk_clm_id,0,26) as clm_nbr,  cl_rend_prov_npi, batch_run_dt, batchid, cl_proc_cd, cl_proc_mod1, cl_proc_mod2, cl_proc_mod3,cl_proc_mod4, cl_line_item_chrg_amt, cl_place_of_srcv, cl_emergency_ind, cl_units_billed from  base_claim_dto1 WHERE key >= '{line_key_start}' and key < '{line_key_end}' ".format(line_key_start = line_key_start , line_key_end = line_key_end))
		data = claim_data.join(service_data, claim_data.claim_number == service_data.clm_nbr, how = "left").drop("clm_nbr")
		return data
    except Exception as e:
        print(e)


def data_preprocessing_s(raw_table):
  
    try:
        raw_data_col = raw_table.columns
        wrangle_data = data_wrangling(data = raw_table, col_to_trim = raw_data_col)
        # Data Cleaning
        preprocessed_tb = "{}.{}".format(database_name_temp, preprocessed_table)
        clean_data = data_cleaning(data = wrangle_data)
        clean_data.write.mode("overwrite").saveAsTable(preprocessed_tb)
        preprocessed_data = spark.read.table(preprocessed_tb)
        return preprocessed_data
    except Exception as e:
        print(e)



def data_wrangling(data, col_to_trim):
   
    try:
        for col_ in col_to_trim:
            data = data.withColumn(col_, F.trim(data[col_]))
        data = data.withColumn("cl_line_item_chrg_amt", F.col("cl_line_item_chrg_amt").cast(DoubleType()))
        data = data.withColumn("cl_units_billed", F.col("cl_units_billed").cast(DoubleType()))
        data = data.withColumn("servicing_npi", 
                                       F.when(((F.col("cl_rend_prov_npi")=="") | F.col("cl_rend_prov_npi").isNull()),
                                              F.col("clm_bill_prov_npi")).otherwise(F.col("cl_rend_prov_npi")))
        data = data.withColumn("cl_emergency_ind", F.when(F.col("cl_emergency_ind") == "Y", 
                                                                  F.lit(1)).otherwise(F.lit(0)))
        return data
    except Exception as e:
        print(e)




def data_cleaning(data):
   
    #Dropping claims having nan,  null or negative entry for cl_line_item_chrg_amt
    c = "cl_line_item_chrg_amt"
    print("Dropping claims having nan, null or negative entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter((F.isnan(c) | F.col(c).isNull() | (F.col(c) < 0)))
    garbage_clms = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms = garbage_clms.withColumn("Flag", F.lit(c))
    
    
    # Dropping claims having nan,  null or negative entry for cl_unit_billed
    c = "cl_units_billed"
    print("Dropping claims having nan, null or negative entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter((F.isnan(c) | F.col(c).isNull() | (F.col(c) < 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    #Dropping claims having null or blank or where the length is not equal to 10 or starting digit is not 1 nor 2 for servicing_npi
    c = "servicing_npi"
    print("Dropping claims having null, blank or where length is not equal to 10 or starting digit is not 1 nor 2 for {}".format(c))
    # Running validation check for NPI
    data = data.withColumn("valid_npi", npi_validator(c)) 
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "") | (data[c].isNull()) | (data["valid_npi"] == 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims having "null" or "blank" & value other than 01 to 99 for cl_place_of_srvc
    c = "cl_place_of_srcv"
    # Creating the place of service lookup list having elements ranging from 01 to 99.
    global pls_lookup_list
    pls_lookup_list = ["0" + str(i) for i in range(1, 10)] + [str(i) for i in range(1,100)]
    print("Dropping claims having null or blank or value other than 01 to 99 for {}".format(c))
    # Running validation check for place of service
    data = data.withColumn("valid_pls", place_of_srcv_validator(c)) 
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "") | (data[c].isNull()) | (data["valid_pls"] == 0)))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims where proc_mod_cd length is not equal to 2 
    # Generating the list of modifier columns
    mod_col_list = [col_ for col_ in data.columns if "proc_mod" in col_]
    for c in mod_col_list:
        print("Dropping claims where length of {} is not equal to 2". format(c))
        dump_data = data.filter((data[c] != "") & (~data[c].isNull()) & (F.length(F.col(c)) !=2))
        garbage_clms1 = dump_data.select("claim_number")
        # Adding flag for identification
        garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
        garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    # Dropping claims having null or blank entry for proc_cd
    c = "cl_proc_cd"
    print("Dropping claims having Null, blank entry for {}".format(c))
    # Filtering out garbage claims
    dump_data = data.filter(((data[c] == "")|(data[c].isNull())))
    garbage_clms1 = dump_data.select("claim_number")
    # Adding flag for identification
    garbage_clms1 = garbage_clms1.withColumn("Flag", F.lit(c))
    garbage_clms = garbage_clms.union(garbage_clms1)
    
    
    ## Filtering out good claims
    garbage_claims = garbage_clms.groupBy("claim_number").agg(F.collect_set("Flag").alias("ps_discrepancy_flag"))
    garbage_claims.createOrReplaceTempView("garbage_claims")
    #garbage_claims.write.mode("Overwrite").parquet("/datalake/uhc/ei/pi_ara/sherlock/staging/apps/provider_signature/scripts/garbage_claims_op1/")
    spark.sql("insert into {}.{} select claim_number, -999999.00 as ps_score, 'NA' as ps_Reason1, 'NA' as ps_Reason2, 'NA' as ps_Reason3, 'NA' as ps_Reason4, 'NA' as ps_Reason5, 'NA' as ps_Reason6, 'NA' as ps_Reason7, 'NA' as ps_Reason8, 'NA' as ps_Reason9, 'NA' as ps_Reason10, 'NA' as ps_Reason11, ps_discrepancy_flag from garbage_claims".format(database_name, ps_clm_output))
    print("garbage claims completed")
    #### Insert garbage_claims into claim DTO
          
    clean_data = data.join(garbage_claims, on="claim_number", how ="left")
    clean_data = clean_data.filter(F.col("ps_discrepancy_flag").isNull())
    clean_data = clean_data.withColumn("cl_place_of_srcv", F.lpad(clean_data["cl_place_of_srcv"], 2, '0'))
    
    return clean_data           
       

        
@udf("int")
def npi_validator(npi):
    try:
        if (len(npi) == 10) & ((npi[0] == "2") | (npi[0] == "1")):
            return 1
        else:
            return 0
    except:
        return 0


@udf("int")
def place_of_srcv_validator(pls):
    try:
        if (pls in pls_lookup_list):
            return 1
        else:
            return 0
    except:
        return 0        




def generate_signal_s(base_data, group_level, em_proc_code_list, high_cost_jcode_list):
    try:
        ## Generating Signal at group level
        
        # 1. Billed Amount
        c = "billed_amt_sum"
        print("Generating {}".format(c))
        output_df = base_data.groupby(group_level).agg(F.sum("cl_line_item_chrg_amt").alias(c))
        
        # 2. Number of claim lines
        c = "clm_ln_cnt"
        print("Generating {}".format(c))
        clm_ln_cnt_data = base_data.groupby(group_level).agg(F.count("*").alias(c))
        output_df = output_df.join(clm_ln_cnt_data, on = group_level, how ="left")
        
        # 3. Sum of Unit Billed
        c = "clm_unit_billed"
        print("Generating {}".format(c))
        clm_unit_billed_data = base_data.groupby(group_level).agg(F.sum("cl_units_billed").alias(c))
        output_df = output_df.join(clm_unit_billed_data, on = group_level, how ="left")
        
        # 4. EM proc indicator 
        c = "em_proc_ind"
        print("Generating {}".format(c))
        em_proc_code_list = [i.strip() for i in em_proc_code_list]
        em_proc_code = spark.createDataFrame(em_proc_code_list, StringType()).withColumnRenamed("value", "cl_proc_cd")
        em_proc_code = em_proc_code.withColumn(c, F.lit(1))
        em_proc_ind_data = base_data.join(em_proc_code, on ="cl_proc_cd", how="left")
        em_proc_ind_data = em_proc_ind_data.fillna(0, subset = [c])
        em_proc_ind_clm_data = em_proc_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(em_proc_ind_clm_data, on = group_level, how ="left")
        
        # 5.  high cost proc indicator 
        c = "high_cst_proc_ind"
        print("Generating {}".format(c))
        high_cost_jcode_list = [i.strip() for i in high_cost_jcode_list]
        high_cost_jcode = spark.createDataFrame(high_cost_jcode_list, StringType()).withColumnRenamed("value", "cl_proc_cd")
        high_cost_jcode = high_cost_jcode.withColumn(c, F.lit(1))
        high_cst_proc_ind_data = base_data.join(high_cost_jcode, on ="cl_proc_cd", how="left")
        high_cst_proc_ind_data = high_cst_proc_ind_data.fillna(0, subset=[c])
        high_cost_proc_ind_clm_data = high_cst_proc_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(high_cost_proc_ind_clm_data, on = group_level, how ="left")
        
        # 6. Emergency indicator 
        c = "emgncy_ind"
        print("Generating {}".format(c))
        emrgncy_ind_data = base_data.withColumn(c, F.when(((F.col("cl_place_of_srcv")=="23")&(F.col("cl_emergency_ind")==0)),
                                                                 F.lit(1)).otherwise(F.lit(0)))
        emrgncy_ind_clm_data = emrgncy_ind_data.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(emrgncy_ind_clm_data, on = group_level, how ="left")
        
        # Preparing data for Modifier signal
        mod_col = [c[0] for c in base_data.dtypes if "mod" in c[0]]
        data_mod = get_mod_data(base_data, group_level, mod_col)
        
        # 7. Modifier 59 indicator 
        c = "mod59_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="59", F.lit(1)).otherwise(F.lit(0)))
        mod59_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(mod59_ind_clm_data, on = group_level, how ="left")
        
        # 8. Modifier 91 indicator
        c = "mod91_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="91", F.lit(1)).otherwise(F.lit(0)))
        mod91_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(mod91_ind_clm_data, on = group_level, how ="left")
        
        # 9. Modifier TC indicator - TW
        c = "modTC_ind"
        print("Generating {}".format(c))
        data_mod_dummy = data_mod.select(group_level + ["cl_proc_mod"])
        data_mod_dummy = data_mod_dummy.withColumn(c, F.when(F.col("cl_proc_mod")=="TC", F.lit(1)).otherwise(F.lit(0)))
        modTC_ind_clm_data = data_mod_dummy.groupby(group_level).agg(F.max(c).alias(c))
        output_df = output_df.join(modTC_ind_clm_data, on = group_level, how ="left")
        
        # LookBack Features
        # 10. Unusal procedure code
        c = "proc_code_unusual"
        print("Generating {}".format(c))
        lb_group_level = ["servicing_npi", "cl_proc_cd"]
        # Reading Lookback lookup table
        lk_bck_s_tb_r  = "{}.{}".format(database_name, proc_cd_lb_table)       #Change to prod_db
        proc_code_lb_data = spark.read.table(lk_bck_s_tb_r)
        # Merging the data	
        base_data_lb = base_data.select(group_level + ["cl_proc_cd"])
        proc_code_unusual_data = base_data_lb.join(proc_code_lb_data, on = lb_group_level, how = "left")
        # Aggregating the result at claim level
        proc_code_unusual_data = proc_code_unusual_data.fillna({"freq_dist":0})
        proc_code_unusual_data = proc_code_unusual_data.groupby(group_level).agg(F.min("freq_dist").alias(c))
        output_df = output_df.join(proc_code_unusual_data, on = group_level, how ="left")
        
        # 11. Unusal place of service
        c = "pos_unsual"
        print("Generating {}".format(c))
        lb_group_level = ["servicing_npi", "cl_place_of_srcv"]
        # Reading Lookback lookup table
        lk_bck_s_tb_r  = "{}.{}".format(database_name, pos_lb_table)      # Change to prod_db
        pos_lb_data = spark.read.table(lk_bck_s_tb_r)
        # Merging the data
        base_data_lb = base_data.select(group_level + ["cl_place_of_srcv"])
        pos_unusual_data = base_data_lb.join(pos_lb_data, on = lb_group_level, how = "left")
        # Aggregating the result at claim level
        pos_unusual_data = pos_unusual_data.fillna({"freq_dist":0})
        pos_unusual_data = pos_unusual_data.groupby(group_level).agg(F.min("freq_dist").alias(c))
        output_df = output_df.join(pos_unusual_data, on = group_level, how ="left")
        
        return output_df
    except Exception as e:
            print(e)



def get_mod_data(data, level, mod_col):
   
    try:
        data_mod = data.select(level + mod_col)
        data_mod = data_mod.withColumn("cl_proc_mod_list", F.array(mod_col)).select(level + ["cl_proc_mod_list"])
        data_mod = data_mod.withColumn("cl_proc_mod", F.explode("cl_proc_mod_list")).select(level + ["cl_proc_mod"])
        return data_mod
    except Exception as e:
        print(e)



def data_imputation_scoring(data, mean_data, icov_data):
    
    try:
        imp_data = data.join(mean_data, on = "servicing_npi", how = "left")
        
        unscored_data = imp_data.filter(F.col('avg_billed_amt_sum').isNull())
        unscored_data = unscored_data.withColumn("dict" , create_struct( ) )
        unscored_data = unscored_data.withColumn("md" , F.lit(-999999.00))
	unscored_data.createOrReplaceTempView('unscored_data')
        unscored_data = spark.sql("select servicing_npi, claim_number, fln_nbr, batch_run_dt, md, dict " + "," + ",".join(col_list) + "," + " 'NA' as ps_Reason1, 'NA' as ps_Reason2, 'NA' as ps_Reason3, 'NA'as ps_Reason4, 'NA' as ps_Reason5, 'NA' as ps_Reason6, 'NA' as ps_Reason7, 'NA' as ps_Reason8, 'NA' as ps_Reason9, 'NA' as ps_Reason10, 'NA' as ps_Reason11  from unscored_data")
        #unscored_data = unscored_data.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md', 'dict'] + col_list)
         
        imputed_data = imp_data.filter(F.col('avg_billed_amt_sum').isNotNull())
        # Imputing the values lesser or equal to mean with mean
        for s in ['billed_amt_sum', 'clm_ln_cnt', 'clm_unit_billed', 'em_proc_ind', 'mod91_ind', 'modTC_ind', 'mod59_ind', 'high_cst_proc_ind', 'emgncy_ind']:
            s_avg = "avg_" + s
            s_i = "imp" + s
            imputed_data = imputed_data.withColumn(s_i, F.when((F.col(s) <= F.col(s_avg)), F.col(s_avg)).otherwise(F.col(s)))
        
        # Imputing the values greater or equal to mean with mean
        for s in ['proc_code_unusual', 'pos_unsual']:
            s_avg = "avg_" + s
            s_i = "imp" + s
            imputed_data = imputed_data.withColumn(s_i, F.when((F.col(s) >= F.col(s_avg)), F.col(s_avg)).otherwise(F.col(s)))
        
        ms_sprk = imputed_data.join(icov_data, how ="inner", on ="servicing_npi")
        
        ###### u - v ######
        for s in col_list:
            s_diff = s + "_diff"
            s_avg = "avg_{}".format(s)   
            ms_sprk = ms_sprk.withColumn(s_diff, F.col("imp"+s) - F.col(s_avg))
   
        return ms_sprk, unscored_data
    except Exception as e:
        print(e)


def clm_scoring(data):
   
    try:
        
        ## Generating Claim Score -  Sq. Mahalanobis Distance
        scored_data = md_spark_df(data, col_list, "md")
        
        # Flagging the Anomalous claims
        flg_data = scored_data.filter(F.col("md") >= threshold)
        
        unflagged_data = scored_data.filter(F.col("md") < threshold)
        unflagged_data = unflagged_data.withColumn("dict" , create_struct() )
        unflagged_data.createOrReplaceTempView("unflagged_data")
        unflagged_data = spark.sql("select servicing_npi, claim_number, fln_nbr, batch_run_dt, md, dict, 'NA' as ps_Reason1, 'NA' as ps_Reason2, 'NA' as ps_Reason3, 'NA'as ps_Reason4, 'NA' as ps_Reason5, 'NA' as ps_Reason6, 'NA' as ps_Reason7, 'NA' as ps_Reason8, 'NA' as ps_Reason9, 'NA' as ps_Reason10, 'NA' as ps_Reason11" + "," + ",".join(col_list) + " from unflagged_data")
        
        # Calculating Signal Effect on claim's M
        for i in col_list:
           flg_data = md_spark_df1(flg_data, col_list, i+"_md", i)
        
        flg_data = flg_data.withColumn("total", sum(flg_data[c] for c in flg_data.columns if "_md" in c))
    
        return flg_data, unflagged_data
    except Exception as e:
        print(e) 



def md_spark_df(data, col_list, col_name):
 
    try:
        data = data.withColumn(col_name, F.lit(0))         
        
        for s in col_list:
            for s2 in col_list:
                s_covar = "covar_samp_{}_{}".format(s, s2)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(s+"_diff")*F.col(s2+"_diff")*F.col(s_covar)) )
            
        return data
    except Exception as e:
        print(e) 




def md_spark_df1(data, col_list, col_name, i):
    try:  
        data = data.withColumn(col_name, F.lit(0)) 
                 
        for s2 in col_list:
                s_covar = "covar_samp_{}_{}".format(i, s2)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(i+"_diff")*F.col(s2+"_diff")*F.col(s_covar)) )
        
	for s in col_list:
                s_covar = "covar_samp_{}_{}".format(s, i)
                data = data.withColumn(col_name, F.col(col_name) + (F.col(s+"_diff")*F.col(i+"_diff")*F.col(s_covar)) )
        
	s_covar = "covar_samp_{}_{}".format(i, i)
        data = data.withColumn(col_name, F.col("md") - F.col(col_name) + (F.col(i+"_diff")*F.col(i+"_diff")*F.col(s_covar)) )
        
        return data
    except Exception as e:
        print(e) 




def reason_gen(data):
    try:
        
        data = data.withColumn("dict" , create_struct())
        data = data.withColumn("dict_avg" , create_struct())
        
        for i in  col_list:
            data = data.withColumn("dict" ,create_struct1( F.col(i+"_md")/ F.col("total"), F.col("dict"), F.lit(i)))  
        for i in  col_list:
            if i in ['proc_code_unusual', 'pos_unsual'] :
                 data = data.withColumn("dict_avg" ,create_struct1( F.col(i)*100, F.col("dict_avg"), F.lit(i)))     
            else :
                 data = data.withColumn("dict_avg" ,create_struct1( F.col("avg_"+i), F.col("dict_avg"), F.lit(i)))
        
        data = data.withColumn("dict" ,create_struct1( F.col("billed_amt_sum_md")/ F.col("total"), F.col("dict"), F.lit("billed_amt_sum") ) )       
        data = data.withColumn("dict1", rsn_selection(F.col("dict")))
        
        
        for i in range(0, len(col_list)):
            data = data.withColumn("ps_Reason"+ str(i+1) , func_reason(F.col("dict1") , F.lit(i), F.col("dict_avg")))
        
        return data
        
    except Exception as e:
        print(e)



@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct():
    a = { }
    return a


@udf(T.MapType(T.StringType(), T.FloatType()))
def create_struct1(b, x, i):
    x[i] = b
    return x


@udf(ArrayType(StringType()))
def rsn_selection(x):
    sorted_dict = sorted(x.items(), key=lambda x: x[1])
    arr = []
    for i in sorted_dict:
        arr.append(i[0])
        if i[1] >= 0.09:
            break
    return arr


@udf(StringType())
def func_reason(arr, col_index, dict_of_avg):  
    if col_index in range(len(arr)):
        feature = arr[col_index]
        val_of_avg = round(dict_of_avg[feature],2)
        return reason_desc[feature].format(avg = val_of_avg)
    else:
        return 'NA'
		

print("######################################### Function ends ##############################")

###Set configs####
config = ConfigParser.ConfigParser()
config.read(config_path)
preprocessed_table = config.get('section1', 'preprocessed_table')
proc_cd_lb_table = config.get('section1', 'proc_cd_lb_table')
pos_lb_table = config.get('section1', 'pos_lb_table')
mean_data = config.get('section1', 'mean_data')
icov_data = config.get('section1', 'icov_data')
history_data = config.get('section1', 'history_data')
ps_clm_output = config.get('section1', 'ps_clm_output')
claimDTO_table = config.get('section1', 'claimDTO_table')
servicelineDTO_table = config.get('section1', 'servicelineDTO_table')


print("######################################### Configuration ##############################")

import json

hbase_claimDTO_table = (hdfs_parent_path+maprdb_path+"/"+claimDTO_table)
hbase_servicelineDTO_table = (hdfs_parent_path+maprdb_path+"/"+servicelineDTO_table)


catalog = json.dumps(
{
"table":{"namespace":"default","name": hbase_claimDTO_table},
"rowkey":"key",
"columns":{
"key":{"cf":"rowkey", "col":"key", "type":"string"},
"batch_run_dt":{"cf":"c", "col":"batch_run_dt", "type":"string"},
"batchid":{"cf":"c", "col":"batchid", "type":"string"},
"clm_adj_repriced_clm_num":{"cf":"c", "col":"clm_adj_repriced_clm_num", "type":"string"},
"clm_admit_dt":{"cf":"c", "col":"clm_admit_dt", "type":"string"},
"clm_admit_src":{"cf":"c", "col":"clm_admit_src", "type":"string"},
"clm_admit_type":{"cf":"c", "col":"clm_admit_type", "type":"string"},
"clm_amb_cond_ind1":{"cf":"c", "col":"clm_amb_cond_ind1", "type":"string"},
"clm_amb_cond_ind2":{"cf":"c", "col":"clm_amb_cond_ind2", "type":"string"},
"clm_amb_cond_ind3":{"cf":"c", "col":"clm_amb_cond_ind3", "type":"string"},
"clm_amb_condition_cd11":{"cf":"c", "col":"clm_amb_condition_cd11", "type":"string"},
"clm_amb_condition_cd12":{"cf":"c", "col":"clm_amb_condition_cd12", "type":"string"},
"clm_amb_condition_cd13":{"cf":"c", "col":"clm_amb_condition_cd13", "type":"string"},
"clm_amb_condition_cd14":{"cf":"c", "col":"clm_amb_condition_cd14", "type":"string"},
"clm_amb_condition_cd15":{"cf":"c", "col":"clm_amb_condition_cd15", "type":"string"},
"clm_amb_condition_cd21":{"cf":"c", "col":"clm_amb_condition_cd21", "type":"string"},
"clm_amb_condition_cd22":{"cf":"c", "col":"clm_amb_condition_cd22", "type":"string"},
"clm_amb_condition_cd23":{"cf":"c", "col":"clm_amb_condition_cd23", "type":"string"},
"clm_amb_condition_cd24":{"cf":"c", "col":"clm_amb_condition_cd24", "type":"string"},
"clm_amb_condition_cd25":{"cf":"c", "col":"clm_amb_condition_cd25", "type":"string"},
"clm_amb_condition_cd31":{"cf":"c", "col":"clm_amb_condition_cd31", "type":"string"},
"clm_amb_condition_cd32":{"cf":"c", "col":"clm_amb_condition_cd32", "type":"string"},
"clm_amb_condition_cd33":{"cf":"c", "col":"clm_amb_condition_cd33", "type":"string"},
"clm_amb_condition_cd34":{"cf":"c", "col":"clm_amb_condition_cd34", "type":"string"},
"clm_amb_condition_cd35":{"cf":"c", "col":"clm_amb_condition_cd35", "type":"string"},
"clm_amb_trans_rsn_cd":{"cf":"c", "col":"clm_amb_trans_rsn_cd", "type":"string"},
"clm_anesth_proc":{"cf":"c", "col":"clm_anesth_proc", "type":"string"},
"clm_attch_control_num1":{"cf":"c", "col":"clm_attch_control_num1", "type":"string"},
"clm_attch_control_num10":{"cf":"c", "col":"clm_attch_control_num10", "type":"string"},
"clm_attch_control_num2":{"cf":"c", "col":"clm_attch_control_num2", "type":"string"},
"clm_attch_control_num3":{"cf":"c", "col":"clm_attch_control_num3", "type":"string"},
"clm_attch_control_num4":{"cf":"c", "col":"clm_attch_control_num4", "type":"string"},
"clm_attch_control_num5":{"cf":"c", "col":"clm_attch_control_num5", "type":"string"},
"clm_attch_control_num6":{"cf":"c", "col":"clm_attch_control_num6", "type":"string"},
"clm_attch_control_num7":{"cf":"c", "col":"clm_attch_control_num7", "type":"string"},
"clm_attch_control_num8":{"cf":"c", "col":"clm_attch_control_num8", "type":"string"},
"clm_attch_control_num9":{"cf":"c", "col":"clm_attch_control_num9", "type":"string"},
"clm_attch_trans_cd1":{"cf":"c", "col":"clm_attch_trans_cd1", "type":"string"},
"clm_attch_trans_cd10":{"cf":"c", "col":"clm_attch_trans_cd10", "type":"string"},
"clm_attch_trans_cd2":{"cf":"c", "col":"clm_attch_trans_cd2", "type":"string"},
"clm_attch_trans_cd3":{"cf":"c", "col":"clm_attch_trans_cd3", "type":"string"},
"clm_attch_trans_cd4":{"cf":"c", "col":"clm_attch_trans_cd4", "type":"string"},
"clm_attch_trans_cd5":{"cf":"c", "col":"clm_attch_trans_cd5", "type":"string"},
"clm_attch_trans_cd6":{"cf":"c", "col":"clm_attch_trans_cd6", "type":"string"},
"clm_attch_trans_cd7":{"cf":"c", "col":"clm_attch_trans_cd7", "type":"string"},
"clm_attch_trans_cd8":{"cf":"c", "col":"clm_attch_trans_cd8", "type":"string"},
"clm_attch_trans_cd9":{"cf":"c", "col":"clm_attch_trans_cd9", "type":"string"},
"clm_attch_type_cd1":{"cf":"c", "col":"clm_attch_type_cd1", "type":"string"},
"clm_attch_type_cd10":{"cf":"c", "col":"clm_attch_type_cd10", "type":"string"},
"clm_attch_type_cd2":{"cf":"c", "col":"clm_attch_type_cd2", "type":"string"},
"clm_attch_type_cd3":{"cf":"c", "col":"clm_attch_type_cd3", "type":"string"},
"clm_attch_type_cd4":{"cf":"c", "col":"clm_attch_type_cd4", "type":"string"},
"clm_attch_type_cd5":{"cf":"c", "col":"clm_attch_type_cd5", "type":"string"},
"clm_attch_type_cd6":{"cf":"c", "col":"clm_attch_type_cd6", "type":"string"},
"clm_attch_type_cd7":{"cf":"c", "col":"clm_attch_type_cd7", "type":"string"},
"clm_attch_type_cd8":{"cf":"c", "col":"clm_attch_type_cd8", "type":"string"},
"clm_attch_type_cd9":{"cf":"c", "col":"clm_attch_type_cd9", "type":"string"},
"clm_attnd_prov_comm_num":{"cf":"c", "col":"clm_attnd_prov_comm_num", "type":"string"},
"clm_attnd_prov_f_name":{"cf":"c", "col":"clm_attnd_prov_f_name", "type":"string"},
"clm_attnd_prov_l_name":{"cf":"c", "col":"clm_attnd_prov_l_name", "type":"string"},
"clm_attnd_prov_m_name":{"cf":"c", "col":"clm_attnd_prov_m_name", "type":"string"},
"clm_attnd_prov_npi":{"cf":"c", "col":"clm_attnd_prov_npi", "type":"string"},
"clm_attnd_prov_st_ln_num":{"cf":"c", "col":"clm_attnd_prov_st_ln_num", "type":"string"},
"clm_attnd_prov_taxonomy_cd":{"cf":"c", "col":"clm_attnd_prov_taxonomy_cd", "type":"string"},
"clm_attnd_prov_upin_num":{"cf":"c", "col":"clm_attnd_prov_upin_num", "type":"string"},
"clm_ben_assignment_cert_ind":{"cf":"c", "col":"clm_ben_assignment_cert_ind", "type":"string"},
"clm_bill_curr_cd":{"cf":"c", "col":"clm_bill_curr_cd", "type":"string"},
"clm_bill_exc_rt":{"cf":"c", "col":"clm_bill_exc_rt", "type":"string"},
"clm_bill_prov_addr":{"cf":"c", "col":"clm_bill_prov_addr", "type":"string"},
"clm_bill_prov_city":{"cf":"c", "col":"clm_bill_prov_city", "type":"string"},
"clm_bill_prov_cntry":{"cf":"c", "col":"clm_bill_prov_cntry", "type":"string"},
"clm_bill_prov_email1":{"cf":"c", "col":"clm_bill_prov_email1", "type":"string"},
"clm_bill_prov_email2":{"cf":"c", "col":"clm_bill_prov_email2", "type":"string"},
"clm_bill_prov_entity_type":{"cf":"c", "col":"clm_bill_prov_entity_type", "type":"string"},
"clm_bill_prov_f_nm":{"cf":"c", "col":"clm_bill_prov_f_nm", "type":"string"},
"clm_bill_prov_fax1":{"cf":"c", "col":"clm_bill_prov_fax1", "type":"string"},
"clm_bill_prov_fax2":{"cf":"c", "col":"clm_bill_prov_fax2", "type":"string"},
"clm_bill_prov_m_nm":{"cf":"c", "col":"clm_bill_prov_m_nm", "type":"string"},
"clm_bill_prov_npi":{"cf":"c", "col":"clm_bill_prov_npi", "type":"string"},
"clm_bill_prov_org_l_nm":{"cf":"c", "col":"clm_bill_prov_org_l_nm", "type":"string"},
"clm_bill_prov_phn_ext1":{"cf":"c", "col":"clm_bill_prov_phn_ext1", "type":"string"},
"clm_bill_prov_phn_ext2":{"cf":"c", "col":"clm_bill_prov_phn_ext2", "type":"string"},
"clm_bill_prov_phn1":{"cf":"c", "col":"clm_bill_prov_phn1", "type":"string"},
"clm_bill_prov_phn2":{"cf":"c", "col":"clm_bill_prov_phn2", "type":"string"},
"clm_bill_prov_sln":{"cf":"c", "col":"clm_bill_prov_sln", "type":"string"},
"clm_bill_prov_ssn":{"cf":"c", "col":"clm_bill_prov_ssn", "type":"string"},
"clm_bill_prov_state":{"cf":"c", "col":"clm_bill_prov_state", "type":"string"},
"clm_bill_prov_tax_cd":{"cf":"c", "col":"clm_bill_prov_tax_cd", "type":"string"},
"clm_bill_prov_tin":{"cf":"c", "col":"clm_bill_prov_tin", "type":"string"},
"clm_bill_prov_upin":{"cf":"c", "col":"clm_bill_prov_upin", "type":"string"},
"clm_bill_prov_zip":{"cf":"c", "col":"clm_bill_prov_zip", "type":"string"},
"clm_care_plan_oversight":{"cf":"c", "col":"clm_care_plan_oversight", "type":"string"},
"clm_clia_num":{"cf":"c", "col":"clm_clia_num", "type":"string"},
"clm_cob_subs1_city":{"cf":"c", "col":"clm_cob_subs1_city", "type":"string"},
"clm_cob_subs1_entity_type":{"cf":"c", "col":"clm_cob_subs1_entity_type", "type":"string"},
"clm_cob_subs1_f_name":{"cf":"c", "col":"clm_cob_subs1_f_name", "type":"string"},
"clm_cob_subs1_hipi":{"cf":"c", "col":"clm_cob_subs1_hipi", "type":"string"},
"clm_cob_subs1_id":{"cf":"c", "col":"clm_cob_subs1_id", "type":"string"},
"clm_cob_subs1_org_l_name":{"cf":"c", "col":"clm_cob_subs1_org_l_name", "type":"string"},
"clm_cob_subs1_payer_id":{"cf":"c", "col":"clm_cob_subs1_payer_id", "type":"string"},
"clm_cob_subs1_payer_nm":{"cf":"c", "col":"clm_cob_subs1_payer_nm", "type":"string"},
"clm_cob_subs1_plan_id":{"cf":"c", "col":"clm_cob_subs1_plan_id", "type":"string"},
"clm_cob_subs1_policy_nbr":{"cf":"c", "col":"clm_cob_subs1_policy_nbr", "type":"string"},
"clm_cob_subs1_rel_cd":{"cf":"c", "col":"clm_cob_subs1_rel_cd", "type":"string"},
"clm_cob_subs1_resp_seq":{"cf":"c", "col":"clm_cob_subs1_resp_seq", "type":"string"},
"clm_cob_subs1_ssn":{"cf":"c", "col":"clm_cob_subs1_ssn", "type":"string"},
"clm_cob_subs1_state":{"cf":"c", "col":"clm_cob_subs1_state", "type":"string"},
"clm_cob_subs1_zip":{"cf":"c", "col":"clm_cob_subs1_zip", "type":"string"},
"clm_cob_subs10_city":{"cf":"c", "col":"clm_cob_subs10_city", "type":"string"},
"clm_cob_subs10_entity_type":{"cf":"c", "col":"clm_cob_subs10_entity_type", "type":"string"},
"clm_cob_subs10_f_name":{"cf":"c", "col":"clm_cob_subs10_f_name", "type":"string"},
"clm_cob_subs10_hipi":{"cf":"c", "col":"clm_cob_subs10_hipi", "type":"string"},
"clm_cob_subs10_id":{"cf":"c", "col":"clm_cob_subs10_id", "type":"string"},
"clm_cob_subs10_org_l_name":{"cf":"c", "col":"clm_cob_subs10_org_l_name", "type":"string"},
"clm_cob_subs10_payer_id":{"cf":"c", "col":"clm_cob_subs10_payer_id", "type":"string"},
"clm_cob_subs10_payer_nm":{"cf":"c", "col":"clm_cob_subs10_payer_nm", "type":"string"},
"clm_cob_subs10_plan_id":{"cf":"c", "col":"clm_cob_subs10_plan_id", "type":"string"},
"clm_cob_subs10_policy_nbr":{"cf":"c", "col":"clm_cob_subs10_policy_nbr", "type":"string"},
"clm_cob_subs10_rel_cd":{"cf":"c", "col":"clm_cob_subs10_rel_cd", "type":"string"},
"clm_cob_subs10_resp_seq":{"cf":"c", "col":"clm_cob_subs10_resp_seq", "type":"string"},
"clm_cob_subs10_ssn":{"cf":"c", "col":"clm_cob_subs10_ssn", "type":"string"},
"clm_cob_subs10_state":{"cf":"c", "col":"clm_cob_subs10_state", "type":"string"},
"clm_cob_subs10_zip":{"cf":"c", "col":"clm_cob_subs10_zip", "type":"string"},
"clm_cob_subs2_city":{"cf":"c", "col":"clm_cob_subs2_city", "type":"string"},
"clm_cob_subs2_entity_type":{"cf":"c", "col":"clm_cob_subs2_entity_type", "type":"string"},
"clm_cob_subs2_f_name":{"cf":"c", "col":"clm_cob_subs2_f_name", "type":"string"},
"clm_cob_subs2_hipi":{"cf":"c", "col":"clm_cob_subs2_hipi", "type":"string"},
"clm_cob_subs2_id":{"cf":"c", "col":"clm_cob_subs2_id", "type":"string"},
"clm_cob_subs2_org_l_name":{"cf":"c", "col":"clm_cob_subs2_org_l_name", "type":"string"},
"clm_cob_subs2_payer_id":{"cf":"c", "col":"clm_cob_subs2_payer_id", "type":"string"},
"clm_cob_subs2_payer_nm":{"cf":"c", "col":"clm_cob_subs2_payer_nm", "type":"string"},
"clm_cob_subs2_plan_id":{"cf":"c", "col":"clm_cob_subs2_plan_id", "type":"string"},
"clm_cob_subs2_policy_nbr":{"cf":"c", "col":"clm_cob_subs2_policy_nbr", "type":"string"},
"clm_cob_subs2_rel_cd":{"cf":"c", "col":"clm_cob_subs2_rel_cd", "type":"string"},
"clm_cob_subs2_resp_seq":{"cf":"c", "col":"clm_cob_subs2_resp_seq", "type":"string"},
"clm_cob_subs2_ssn":{"cf":"c", "col":"clm_cob_subs2_ssn", "type":"string"},
"clm_cob_subs2_state":{"cf":"c", "col":"clm_cob_subs2_state", "type":"string"},
"clm_cob_subs2_zip":{"cf":"c", "col":"clm_cob_subs2_zip", "type":"string"},
"clm_cob_subs3_city":{"cf":"c", "col":"clm_cob_subs3_city", "type":"string"},
"clm_cob_subs3_entity_type":{"cf":"c", "col":"clm_cob_subs3_entity_type", "type":"string"},
"clm_cob_subs3_f_name":{"cf":"c", "col":"clm_cob_subs3_f_name", "type":"string"},
"clm_cob_subs3_hipi":{"cf":"c", "col":"clm_cob_subs3_hipi", "type":"string"},
"clm_cob_subs3_id":{"cf":"c", "col":"clm_cob_subs3_id", "type":"string"},
"clm_cob_subs3_org_l_name":{"cf":"c", "col":"clm_cob_subs3_org_l_name", "type":"string"},
"clm_cob_subs3_payer_id":{"cf":"c", "col":"clm_cob_subs3_payer_id", "type":"string"},
"clm_cob_subs3_payer_nm":{"cf":"c", "col":"clm_cob_subs3_payer_nm", "type":"string"},
"clm_cob_subs3_plan_id":{"cf":"c", "col":"clm_cob_subs3_plan_id", "type":"string"},
"clm_cob_subs3_policy_nbr":{"cf":"c", "col":"clm_cob_subs3_policy_nbr", "type":"string"},
"clm_cob_subs3_rel_cd":{"cf":"c", "col":"clm_cob_subs3_rel_cd", "type":"string"},
"clm_cob_subs3_resp_seq":{"cf":"c", "col":"clm_cob_subs3_resp_seq", "type":"string"},
"clm_cob_subs3_ssn":{"cf":"c", "col":"clm_cob_subs3_ssn", "type":"string"},
"clm_cob_subs3_state":{"cf":"c", "col":"clm_cob_subs3_state", "type":"string"},
"clm_cob_subs3_zip":{"cf":"c", "col":"clm_cob_subs3_zip", "type":"string"},
"clm_cob_subs4_city":{"cf":"c", "col":"clm_cob_subs4_city", "type":"string"},
"clm_cob_subs4_entity_type":{"cf":"c", "col":"clm_cob_subs4_entity_type", "type":"string"},
"clm_cob_subs4_f_name":{"cf":"c", "col":"clm_cob_subs4_f_name", "type":"string"},
"clm_cob_subs4_hipi":{"cf":"c", "col":"clm_cob_subs4_hipi", "type":"string"},
"clm_cob_subs4_id":{"cf":"c", "col":"clm_cob_subs4_id", "type":"string"},
"clm_cob_subs4_org_l_name":{"cf":"c", "col":"clm_cob_subs4_org_l_name", "type":"string"},
"clm_cob_subs4_payer_id":{"cf":"c", "col":"clm_cob_subs4_payer_id", "type":"string"},
"clm_cob_subs4_payer_nm":{"cf":"c", "col":"clm_cob_subs4_payer_nm", "type":"string"},
"clm_cob_subs4_plan_id":{"cf":"c", "col":"clm_cob_subs4_plan_id", "type":"string"},
"clm_cob_subs4_policy_nbr":{"cf":"c", "col":"clm_cob_subs4_policy_nbr", "type":"string"},
"clm_cob_subs4_rel_cd":{"cf":"c", "col":"clm_cob_subs4_rel_cd", "type":"string"},
"clm_cob_subs4_resp_seq":{"cf":"c", "col":"clm_cob_subs4_resp_seq", "type":"string"},
"clm_cob_subs4_ssn":{"cf":"c", "col":"clm_cob_subs4_ssn", "type":"string"},
"clm_cob_subs4_state":{"cf":"c", "col":"clm_cob_subs4_state", "type":"string"},
"clm_cob_subs4_zip":{"cf":"c", "col":"clm_cob_subs4_zip", "type":"string"},
"clm_cob_subs5_city":{"cf":"c", "col":"clm_cob_subs5_city", "type":"string"},
"clm_cob_subs5_entity_type":{"cf":"c", "col":"clm_cob_subs5_entity_type", "type":"string"},
"clm_cob_subs5_f_name":{"cf":"c", "col":"clm_cob_subs5_f_name", "type":"string"},
"clm_cob_subs5_hipi":{"cf":"c", "col":"clm_cob_subs5_hipi", "type":"string"},
"clm_cob_subs5_id":{"cf":"c", "col":"clm_cob_subs5_id", "type":"string"},
"clm_cob_subs5_org_l_name":{"cf":"c", "col":"clm_cob_subs5_org_l_name", "type":"string"},
"clm_cob_subs5_payer_id":{"cf":"c", "col":"clm_cob_subs5_payer_id", "type":"string"},
"clm_cob_subs5_payer_nm":{"cf":"c", "col":"clm_cob_subs5_payer_nm", "type":"string"},
"clm_cob_subs5_plan_id":{"cf":"c", "col":"clm_cob_subs5_plan_id", "type":"string"},
"clm_cob_subs5_policy_nbr":{"cf":"c", "col":"clm_cob_subs5_policy_nbr", "type":"string"},
"clm_cob_subs5_rel_cd":{"cf":"c", "col":"clm_cob_subs5_rel_cd", "type":"string"},
"clm_cob_subs5_resp_seq":{"cf":"c", "col":"clm_cob_subs5_resp_seq", "type":"string"},
"clm_cob_subs5_ssn":{"cf":"c", "col":"clm_cob_subs5_ssn", "type":"string"},
"clm_cob_subs5_state":{"cf":"c", "col":"clm_cob_subs5_state", "type":"string"},
"clm_cob_subs5_zip":{"cf":"c", "col":"clm_cob_subs5_zip", "type":"string"},
"clm_cob_subs6_city":{"cf":"c", "col":"clm_cob_subs6_city", "type":"string"},
"clm_cob_subs6_entity_type":{"cf":"c", "col":"clm_cob_subs6_entity_type", "type":"string"},
"clm_cob_subs6_f_name":{"cf":"c", "col":"clm_cob_subs6_f_name", "type":"string"},
"clm_cob_subs6_hipi":{"cf":"c", "col":"clm_cob_subs6_hipi", "type":"string"},
"clm_cob_subs6_id":{"cf":"c", "col":"clm_cob_subs6_id", "type":"string"},
"clm_cob_subs6_org_l_name":{"cf":"c", "col":"clm_cob_subs6_org_l_name", "type":"string"},
"clm_cob_subs6_payer_id":{"cf":"c", "col":"clm_cob_subs6_payer_id", "type":"string"},
"clm_cob_subs6_payer_nm":{"cf":"c", "col":"clm_cob_subs6_payer_nm", "type":"string"},
"clm_cob_subs6_plan_id":{"cf":"c", "col":"clm_cob_subs6_plan_id", "type":"string"},
"clm_cob_subs6_policy_nbr":{"cf":"c", "col":"clm_cob_subs6_policy_nbr", "type":"string"},
"clm_cob_subs6_rel_cd":{"cf":"c", "col":"clm_cob_subs6_rel_cd", "type":"string"},
"clm_cob_subs6_resp_seq":{"cf":"c", "col":"clm_cob_subs6_resp_seq", "type":"string"},
"clm_cob_subs6_ssn":{"cf":"c", "col":"clm_cob_subs6_ssn", "type":"string"},
"clm_cob_subs6_state":{"cf":"c", "col":"clm_cob_subs6_state", "type":"string"},
"clm_cob_subs6_zip":{"cf":"c", "col":"clm_cob_subs6_zip", "type":"string"},
"clm_cob_subs7_city":{"cf":"c", "col":"clm_cob_subs7_city", "type":"string"},
"clm_cob_subs7_entity_type":{"cf":"c", "col":"clm_cob_subs7_entity_type", "type":"string"},
"clm_cob_subs7_f_name":{"cf":"c", "col":"clm_cob_subs7_f_name", "type":"string"},
"clm_cob_subs7_hipi":{"cf":"c", "col":"clm_cob_subs7_hipi", "type":"string"},
"clm_cob_subs7_id":{"cf":"c", "col":"clm_cob_subs7_id", "type":"string"},
"clm_cob_subs7_org_l_name":{"cf":"c", "col":"clm_cob_subs7_org_l_name", "type":"string"},
"clm_cob_subs7_payer_id":{"cf":"c", "col":"clm_cob_subs7_payer_id", "type":"string"},
"clm_cob_subs7_payer_nm":{"cf":"c", "col":"clm_cob_subs7_payer_nm", "type":"string"},
"clm_cob_subs7_plan_id":{"cf":"c", "col":"clm_cob_subs7_plan_id", "type":"string"},
"clm_cob_subs7_policy_nbr":{"cf":"c", "col":"clm_cob_subs7_policy_nbr", "type":"string"},
"clm_cob_subs7_rel_cd":{"cf":"c", "col":"clm_cob_subs7_rel_cd", "type":"string"},
"clm_cob_subs7_resp_seq":{"cf":"c", "col":"clm_cob_subs7_resp_seq", "type":"string"},
"clm_cob_subs7_ssn":{"cf":"c", "col":"clm_cob_subs7_ssn", "type":"string"},
"clm_cob_subs7_state":{"cf":"c", "col":"clm_cob_subs7_state", "type":"string"},
"clm_cob_subs7_zip":{"cf":"c", "col":"clm_cob_subs7_zip", "type":"string"},
"clm_cob_subs8_city":{"cf":"c", "col":"clm_cob_subs8_city", "type":"string"},
"clm_cob_subs8_entity_type":{"cf":"c", "col":"clm_cob_subs8_entity_type", "type":"string"},
"clm_cob_subs8_f_name":{"cf":"c", "col":"clm_cob_subs8_f_name", "type":"string"},
"clm_cob_subs8_hipi":{"cf":"c", "col":"clm_cob_subs8_hipi", "type":"string"},
"clm_cob_subs8_id":{"cf":"c", "col":"clm_cob_subs8_id", "type":"string"},
"clm_cob_subs8_org_l_name":{"cf":"c", "col":"clm_cob_subs8_org_l_name", "type":"string"},
"clm_cob_subs8_payer_id":{"cf":"c", "col":"clm_cob_subs8_payer_id", "type":"string"},
"clm_cob_subs8_payer_nm":{"cf":"c", "col":"clm_cob_subs8_payer_nm", "type":"string"},
"clm_cob_subs8_plan_id":{"cf":"c", "col":"clm_cob_subs8_plan_id", "type":"string"},
"clm_cob_subs8_policy_nbr":{"cf":"c", "col":"clm_cob_subs8_policy_nbr", "type":"string"},
"clm_cob_subs8_rel_cd":{"cf":"c", "col":"clm_cob_subs8_rel_cd", "type":"string"},
"clm_cob_subs8_resp_seq":{"cf":"c", "col":"clm_cob_subs8_resp_seq", "type":"string"},
"clm_cob_subs8_ssn":{"cf":"c", "col":"clm_cob_subs8_ssn", "type":"string"},
"clm_cob_subs8_state":{"cf":"c", "col":"clm_cob_subs8_state", "type":"string"},
"clm_cob_subs8_zip":{"cf":"c", "col":"clm_cob_subs8_zip", "type":"string"},
"clm_cob_subs9_city":{"cf":"c", "col":"clm_cob_subs9_city", "type":"string"},
"clm_cob_subs9_entity_type":{"cf":"c", "col":"clm_cob_subs9_entity_type", "type":"string"},
"clm_cob_subs9_f_name":{"cf":"c", "col":"clm_cob_subs9_f_name", "type":"string"},
"clm_cob_subs9_hipi":{"cf":"c", "col":"clm_cob_subs9_hipi", "type":"string"},
"clm_cob_subs9_id":{"cf":"c", "col":"clm_cob_subs9_id", "type":"string"},
"clm_cob_subs9_org_l_name":{"cf":"c", "col":"clm_cob_subs9_org_l_name", "type":"string"},
"clm_cob_subs9_payer_id":{"cf":"c", "col":"clm_cob_subs9_payer_id", "type":"string"},
"clm_cob_subs9_payer_nm":{"cf":"c", "col":"clm_cob_subs9_payer_nm", "type":"string"},
"clm_cob_subs9_plan_id":{"cf":"c", "col":"clm_cob_subs9_plan_id", "type":"string"},
"clm_cob_subs9_policy_nbr":{"cf":"c", "col":"clm_cob_subs9_policy_nbr", "type":"string"},
"clm_cob_subs9_rel_cd":{"cf":"c", "col":"clm_cob_subs9_rel_cd", "type":"string"},
"clm_cob_subs9_resp_seq":{"cf":"c", "col":"clm_cob_subs9_resp_seq", "type":"string"},
"clm_cob_subs9_ssn":{"cf":"c", "col":"clm_cob_subs9_ssn", "type":"string"},
"clm_cob_subs9_state":{"cf":"c", "col":"clm_cob_subs9_state", "type":"string"},
"clm_cob_subs9_zip":{"cf":"c", "col":"clm_cob_subs9_zip", "type":"string"},
"clm_condition_cd101":{"cf":"c", "col":"clm_condition_cd101", "type":"string"},
"clm_condition_cd102":{"cf":"c", "col":"clm_condition_cd102", "type":"string"},
"clm_condition_cd103":{"cf":"c", "col":"clm_condition_cd103", "type":"string"},
"clm_condition_cd104":{"cf":"c", "col":"clm_condition_cd104", "type":"string"},
"clm_condition_cd105":{"cf":"c", "col":"clm_condition_cd105", "type":"string"},
"clm_condition_cd106":{"cf":"c", "col":"clm_condition_cd106", "type":"string"},
"clm_condition_cd107":{"cf":"c", "col":"clm_condition_cd107", "type":"string"},
"clm_condition_cd108":{"cf":"c", "col":"clm_condition_cd108", "type":"string"},
"clm_condition_cd109":{"cf":"c", "col":"clm_condition_cd109", "type":"string"},
"clm_condition_cd110":{"cf":"c", "col":"clm_condition_cd110", "type":"string"},
"clm_condition_cd111":{"cf":"c", "col":"clm_condition_cd111", "type":"string"},
"clm_condition_cd112":{"cf":"c", "col":"clm_condition_cd112", "type":"string"},
"clm_condition_cd201":{"cf":"c", "col":"clm_condition_cd201", "type":"string"},
"clm_condition_cd202":{"cf":"c", "col":"clm_condition_cd202", "type":"string"},
"clm_condition_cd203":{"cf":"c", "col":"clm_condition_cd203", "type":"string"},
"clm_condition_cd204":{"cf":"c", "col":"clm_condition_cd204", "type":"string"},
"clm_condition_cd205":{"cf":"c", "col":"clm_condition_cd205", "type":"string"},
"clm_condition_cd206":{"cf":"c", "col":"clm_condition_cd206", "type":"string"},
"clm_condition_cd207":{"cf":"c", "col":"clm_condition_cd207", "type":"string"},
"clm_condition_cd208":{"cf":"c", "col":"clm_condition_cd208", "type":"string"},
"clm_condition_cd209":{"cf":"c", "col":"clm_condition_cd209", "type":"string"},
"clm_condition_cd210":{"cf":"c", "col":"clm_condition_cd210", "type":"string"},
"clm_condition_cd211":{"cf":"c", "col":"clm_condition_cd211", "type":"string"},
"clm_condition_cd212":{"cf":"c", "col":"clm_condition_cd212", "type":"string"},
"clm_delay_rsn_cd":{"cf":"c", "col":"clm_delay_rsn_cd", "type":"string"},
"clm_epsdt_condition_cd1":{"cf":"c", "col":"clm_epsdt_condition_cd1", "type":"string"},
"clm_epsdt_condition_cd2":{"cf":"c", "col":"clm_epsdt_condition_cd2", "type":"string"},
"clm_epsdt_condition_cd3":{"cf":"c", "col":"clm_epsdt_condition_cd3", "type":"string"},
"clm_epsdt_ref_ind":{"cf":"c", "col":"clm_epsdt_ref_ind", "type":"string"},
"clm_epv_status":{"cf":"c", "col":"clm_epv_status", "type":"string"},
"clm_external_num":{"cf":"c", "col":"clm_external_num", "type":"string"},
"clm_facility_addr":{"cf":"c", "col":"clm_facility_addr", "type":"string"},
"clm_facility_city":{"cf":"c", "col":"clm_facility_city", "type":"string"},
"clm_facility_comm_num":{"cf":"c", "col":"clm_facility_comm_num", "type":"string"},
"clm_facility_loc_num":{"cf":"c", "col":"clm_facility_loc_num", "type":"string"},
"clm_facility_nm":{"cf":"c", "col":"clm_facility_nm", "type":"string"},
"clm_facility_npi":{"cf":"c", "col":"clm_facility_npi", "type":"string"},
"clm_facility_st_ln_num":{"cf":"c", "col":"clm_facility_st_ln_num", "type":"string"},
"clm_facility_state":{"cf":"c", "col":"clm_facility_state", "type":"string"},
"clm_facility_zip":{"cf":"c", "col":"clm_facility_zip", "type":"string"},
"clm_filing_ind_cd":{"cf":"c", "col":"clm_filing_ind_cd", "type":"string"},
"clm_freq_type_code":{"cf":"c", "col":"clm_freq_type_code", "type":"string"},
"clm_hb_condition_cd":{"cf":"c", "col":"clm_hb_condition_cd", "type":"string"},
"clm_hc_admit_diag_code":{"cf":"c", "col":"clm_hc_admit_diag_code", "type":"string"},
"clm_hc_admit_diag_type":{"cf":"c", "col":"clm_hc_admit_diag_type", "type":"string"},
"clm_hc_diag_code1":{"cf":"c", "col":"clm_hc_diag_code1", "type":"string"},
"clm_hc_diag_code10":{"cf":"c", "col":"clm_hc_diag_code10", "type":"string"},
"clm_hc_diag_code11":{"cf":"c", "col":"clm_hc_diag_code11", "type":"string"},
"clm_hc_diag_code12":{"cf":"c", "col":"clm_hc_diag_code12", "type":"string"},
"clm_hc_diag_code2":{"cf":"c", "col":"clm_hc_diag_code2", "type":"string"},
"clm_hc_diag_code3":{"cf":"c", "col":"clm_hc_diag_code3", "type":"string"},
"clm_hc_diag_code4":{"cf":"c", "col":"clm_hc_diag_code4", "type":"string"},
"clm_hc_diag_code5":{"cf":"c", "col":"clm_hc_diag_code5", "type":"string"},
"clm_hc_diag_code6":{"cf":"c", "col":"clm_hc_diag_code6", "type":"string"},
"clm_hc_diag_code7":{"cf":"c", "col":"clm_hc_diag_code7", "type":"string"},
"clm_hc_diag_code8":{"cf":"c", "col":"clm_hc_diag_code8", "type":"string"},
"clm_hc_diag_code9":{"cf":"c", "col":"clm_hc_diag_code9", "type":"string"},
"clm_hc_diag_type1":{"cf":"c", "col":"clm_hc_diag_type1", "type":"string"},
"clm_hc_diag_type10":{"cf":"c", "col":"clm_hc_diag_type10", "type":"string"},
"clm_hc_diag_type11":{"cf":"c", "col":"clm_hc_diag_type11", "type":"string"},
"clm_hc_diag_type12":{"cf":"c", "col":"clm_hc_diag_type12", "type":"string"},
"clm_hc_diag_type2":{"cf":"c", "col":"clm_hc_diag_type2", "type":"string"},
"clm_hc_diag_type3":{"cf":"c", "col":"clm_hc_diag_type3", "type":"string"},
"clm_hc_diag_type4":{"cf":"c", "col":"clm_hc_diag_type4", "type":"string"},
"clm_hc_diag_type5":{"cf":"c", "col":"clm_hc_diag_type5", "type":"string"},
"clm_hc_diag_type6":{"cf":"c", "col":"clm_hc_diag_type6", "type":"string"},
"clm_hc_diag_type7":{"cf":"c", "col":"clm_hc_diag_type7", "type":"string"},
"clm_hc_diag_type8":{"cf":"c", "col":"clm_hc_diag_type8", "type":"string"},
"clm_hc_diag_type9":{"cf":"c", "col":"clm_hc_diag_type9", "type":"string"},
"clm_hc_drg_code":{"cf":"c", "col":"clm_hc_drg_code", "type":"string"},
"clm_hc_othr_diag_code1":{"cf":"c", "col":"clm_hc_othr_diag_code1", "type":"string"},
"clm_hc_othr_diag_code10":{"cf":"c", "col":"clm_hc_othr_diag_code10", "type":"string"},
"clm_hc_othr_diag_code11":{"cf":"c", "col":"clm_hc_othr_diag_code11", "type":"string"},
"clm_hc_othr_diag_code12":{"cf":"c", "col":"clm_hc_othr_diag_code12", "type":"string"},
"clm_hc_othr_diag_code2":{"cf":"c", "col":"clm_hc_othr_diag_code2", "type":"string"},
"clm_hc_othr_diag_code3":{"cf":"c", "col":"clm_hc_othr_diag_code3", "type":"string"},
"clm_hc_othr_diag_code4":{"cf":"c", "col":"clm_hc_othr_diag_code4", "type":"string"},
"clm_hc_othr_diag_code5":{"cf":"c", "col":"clm_hc_othr_diag_code5", "type":"string"},
"clm_hc_othr_diag_code6":{"cf":"c", "col":"clm_hc_othr_diag_code6", "type":"string"},
"clm_hc_othr_diag_code7":{"cf":"c", "col":"clm_hc_othr_diag_code7", "type":"string"},
"clm_hc_othr_diag_code8":{"cf":"c", "col":"clm_hc_othr_diag_code8", "type":"string"},
"clm_hc_othr_diag_code9":{"cf":"c", "col":"clm_hc_othr_diag_code9", "type":"string"},
"clm_hc_othr_diag_type1":{"cf":"c", "col":"clm_hc_othr_diag_type1", "type":"string"},
"clm_hc_othr_diag_type10":{"cf":"c", "col":"clm_hc_othr_diag_type10", "type":"string"},
"clm_hc_othr_diag_type11":{"cf":"c", "col":"clm_hc_othr_diag_type11", "type":"string"},
"clm_hc_othr_diag_type12":{"cf":"c", "col":"clm_hc_othr_diag_type12", "type":"string"},
"clm_hc_othr_diag_type2":{"cf":"c", "col":"clm_hc_othr_diag_type2", "type":"string"},
"clm_hc_othr_diag_type3":{"cf":"c", "col":"clm_hc_othr_diag_type3", "type":"string"},
"clm_hc_othr_diag_type4":{"cf":"c", "col":"clm_hc_othr_diag_type4", "type":"string"},
"clm_hc_othr_diag_type5":{"cf":"c", "col":"clm_hc_othr_diag_type5", "type":"string"},
"clm_hc_othr_diag_type6":{"cf":"c", "col":"clm_hc_othr_diag_type6", "type":"string"},
"clm_hc_othr_diag_type7":{"cf":"c", "col":"clm_hc_othr_diag_type7", "type":"string"},
"clm_hc_othr_diag_type8":{"cf":"c", "col":"clm_hc_othr_diag_type8", "type":"string"},
"clm_hc_othr_diag_type9":{"cf":"c", "col":"clm_hc_othr_diag_type9", "type":"string"},
"clm_hc_pat_rsn_code1":{"cf":"c", "col":"clm_hc_pat_rsn_code1", "type":"string"},
"clm_hc_pat_rsn_code2":{"cf":"c", "col":"clm_hc_pat_rsn_code2", "type":"string"},
"clm_hc_pat_rsn_code3":{"cf":"c", "col":"clm_hc_pat_rsn_code3", "type":"string"},
"clm_hc_pat_rsn_type1":{"cf":"c", "col":"clm_hc_pat_rsn_type1", "type":"string"},
"clm_hc_pat_rsn_type2":{"cf":"c", "col":"clm_hc_pat_rsn_type2", "type":"string"},
"clm_hc_pat_rsn_type3":{"cf":"c", "col":"clm_hc_pat_rsn_type3", "type":"string"},
"clm_homebound_ind":{"cf":"c", "col":"clm_homebound_ind", "type":"string"},
"clm_inves_dvc_exemp_num":{"cf":"c", "col":"clm_inves_dvc_exemp_num", "type":"string"},
"clm_mammo_cert_num":{"cf":"c", "col":"clm_mammo_cert_num", "type":"string"},
"clm_measurement_unit":{"cf":"c", "col":"clm_measurement_unit", "type":"string"},
"clm_medical_rec_num":{"cf":"c", "col":"clm_medical_rec_num", "type":"string"},
"clm_medicare_crossover_ind":{"cf":"c", "col":"clm_medicare_crossover_ind", "type":"string"},
"clm_operating_prov_comm_num":{"cf":"c", "col":"clm_operating_prov_comm_num", "type":"string"},
"clm_operating_prov_f_name":{"cf":"c", "col":"clm_operating_prov_f_name", "type":"string"},
"clm_operating_prov_l_name":{"cf":"c", "col":"clm_operating_prov_l_name", "type":"string"},
"clm_operating_prov_m_name":{"cf":"c", "col":"clm_operating_prov_m_name", "type":"string"},
"clm_operating_prov_npi":{"cf":"c", "col":"clm_operating_prov_npi", "type":"string"},
"clm_operating_prov_st_ln_num":{"cf":"c", "col":"clm_operating_prov_st_ln_num", "type":"string"},
"clm_operating_prov_upin_num":{"cf":"c", "col":"clm_operating_prov_upin_num", "type":"string"},
"clm_other_proc_code1":{"cf":"c", "col":"clm_other_proc_code1", "type":"string"},
"clm_other_proc_code10":{"cf":"c", "col":"clm_other_proc_code10", "type":"string"},
"clm_other_proc_code11":{"cf":"c", "col":"clm_other_proc_code11", "type":"string"},
"clm_other_proc_code12":{"cf":"c", "col":"clm_other_proc_code12", "type":"string"},
"clm_other_proc_code2":{"cf":"c", "col":"clm_other_proc_code2", "type":"string"},
"clm_other_proc_code3":{"cf":"c", "col":"clm_other_proc_code3", "type":"string"},
"clm_other_proc_code4":{"cf":"c", "col":"clm_other_proc_code4", "type":"string"},
"clm_other_proc_code5":{"cf":"c", "col":"clm_other_proc_code5", "type":"string"},
"clm_other_proc_code6":{"cf":"c", "col":"clm_other_proc_code6", "type":"string"},
"clm_other_proc_code7":{"cf":"c", "col":"clm_other_proc_code7", "type":"string"},
"clm_other_proc_code8":{"cf":"c", "col":"clm_other_proc_code8", "type":"string"},
"clm_other_proc_code9":{"cf":"c", "col":"clm_other_proc_code9", "type":"string"},
"clm_other_proc_type1":{"cf":"c", "col":"clm_other_proc_type1", "type":"string"},
"clm_other_proc_type10":{"cf":"c", "col":"clm_other_proc_type10", "type":"string"},
"clm_other_proc_type11":{"cf":"c", "col":"clm_other_proc_type11", "type":"string"},
"clm_other_proc_type12":{"cf":"c", "col":"clm_other_proc_type12", "type":"string"},
"clm_other_proc_type2":{"cf":"c", "col":"clm_other_proc_type2", "type":"string"},
"clm_other_proc_type3":{"cf":"c", "col":"clm_other_proc_type3", "type":"string"},
"clm_other_proc_type4":{"cf":"c", "col":"clm_other_proc_type4", "type":"string"},
"clm_other_proc_type5":{"cf":"c", "col":"clm_other_proc_type5", "type":"string"},
"clm_other_proc_type6":{"cf":"c", "col":"clm_other_proc_type6", "type":"string"},
"clm_other_proc_type7":{"cf":"c", "col":"clm_other_proc_type7", "type":"string"},
"clm_other_proc_type8":{"cf":"c", "col":"clm_other_proc_type8", "type":"string"},
"clm_other_proc_type9":{"cf":"c", "col":"clm_other_proc_type9", "type":"string"},
"clm_pat_status_cd":{"cf":"c", "col":"clm_pat_status_cd", "type":"string"},
"clm_patient_addr":{"cf":"c", "col":"clm_patient_addr", "type":"string"},
"clm_patient_city":{"cf":"c", "col":"clm_patient_city", "type":"string"},
"clm_patient_cntry":{"cf":"c", "col":"clm_patient_cntry", "type":"string"},
"clm_patient_death_date":{"cf":"c", "col":"clm_patient_death_date", "type":"string"},
"clm_patient_dob":{"cf":"c", "col":"clm_patient_dob", "type":"string"},
"clm_patient_f_nm":{"cf":"c", "col":"clm_patient_f_nm", "type":"string"},
"clm_patient_gender":{"cf":"c", "col":"clm_patient_gender", "type":"string"},
"clm_patient_id":{"cf":"c", "col":"clm_patient_id", "type":"string"},
"clm_patient_ind_rel_cd":{"cf":"c", "col":"clm_patient_ind_rel_cd", "type":"string"},
"clm_patient_l_nm":{"cf":"c", "col":"clm_patient_l_nm", "type":"string"},
"clm_patient_m_nm":{"cf":"c", "col":"clm_patient_m_nm", "type":"string"},
"clm_patient_marital_status":{"cf":"c", "col":"clm_patient_marital_status", "type":"string"},
"clm_patient_preg_ind":{"cf":"c", "col":"clm_patient_preg_ind", "type":"string"},
"clm_patient_sign_src_cd":{"cf":"c", "col":"clm_patient_sign_src_cd", "type":"string"},
"clm_patient_state":{"cf":"c", "col":"clm_patient_state", "type":"string"},
"clm_patient_zip":{"cf":"c", "col":"clm_patient_zip", "type":"string"},
"clm_pay_to_addr":{"cf":"c", "col":"clm_pay_to_addr", "type":"string"},
"clm_pay_to_city":{"cf":"c", "col":"clm_pay_to_city", "type":"string"},
"clm_pay_to_cntry":{"cf":"c", "col":"clm_pay_to_cntry", "type":"string"},
"clm_pay_to_payor_id":{"cf":"c", "col":"clm_pay_to_payor_id", "type":"string"},
"clm_pay_to_plan":{"cf":"c", "col":"clm_pay_to_plan", "type":"string"},
"clm_pay_to_plan_addr":{"cf":"c", "col":"clm_pay_to_plan_addr", "type":"string"},
"clm_pay_to_plan_city":{"cf":"c", "col":"clm_pay_to_plan_city", "type":"string"},
"clm_pay_to_plan_cntry":{"cf":"c", "col":"clm_pay_to_plan_cntry", "type":"string"},
"clm_pay_to_plan_state":{"cf":"c", "col":"clm_pay_to_plan_state", "type":"string"},
"clm_pay_to_plan_zip":{"cf":"c", "col":"clm_pay_to_plan_zip", "type":"string"},
"clm_pay_to_state":{"cf":"c", "col":"clm_pay_to_state", "type":"string"},
"clm_pay_to_zip":{"cf":"c", "col":"clm_pay_to_zip", "type":"string"},
"clm_payer_addr":{"cf":"c", "col":"clm_payer_addr", "type":"string"},
"clm_payer_city":{"cf":"c", "col":"clm_payer_city", "type":"string"},
"clm_payer_ctrl_num":{"cf":"c", "col":"clm_payer_ctrl_num", "type":"string"},
"clm_payer_id":{"cf":"c", "col":"clm_payer_id", "type":"string"},
"clm_payer_nm":{"cf":"c", "col":"clm_payer_nm", "type":"string"},
"clm_payer_resp_seq_num":{"cf":"c", "col":"clm_payer_resp_seq_num", "type":"string"},
"clm_payer_state":{"cf":"c", "col":"clm_payer_state", "type":"string"},
"clm_payer_zip":{"cf":"c", "col":"clm_payer_zip", "type":"string"},
"clm_place_of_srcv":{"cf":"c", "col":"clm_place_of_srcv", "type":"string"},
"clm_plan_id":{"cf":"c", "col":"clm_plan_id", "type":"string"},
"clm_policy_nbr":{"cf":"c", "col":"clm_policy_nbr", "type":"string"},
"clm_prim_care_prov_comm_num":{"cf":"c", "col":"clm_prim_care_prov_comm_num", "type":"string"},
"clm_prim_care_prov_f_name":{"cf":"c", "col":"clm_prim_care_prov_f_name", "type":"string"},
"clm_prim_care_prov_l_name":{"cf":"c", "col":"clm_prim_care_prov_l_name", "type":"string"},
"clm_prim_care_prov_m_name":{"cf":"c", "col":"clm_prim_care_prov_m_name", "type":"string"},
"clm_prim_care_prov_npi":{"cf":"c", "col":"clm_prim_care_prov_npi", "type":"string"},
"clm_prim_care_prov_st_ln_num":{"cf":"c", "col":"clm_prim_care_prov_st_ln_num", "type":"string"},
"clm_prim_care_prov_upin_num":{"cf":"c", "col":"clm_prim_care_prov_upin_num", "type":"string"},
"clm_principal_proc_code":{"cf":"c", "col":"clm_principal_proc_code", "type":"string"},
"clm_principal_proc_type":{"cf":"c", "col":"clm_principal_proc_type", "type":"string"},
"clm_prior_auth_num":{"cf":"c", "col":"clm_prior_auth_num", "type":"string"},
"clm_prov_agreement_cd":{"cf":"c", "col":"clm_prov_agreement_cd", "type":"string"},
"clm_prov_prtcp_cd":{"cf":"c", "col":"clm_prov_prtcp_cd", "type":"string"},
"clm_prov_supp_sign_ind":{"cf":"c", "col":"clm_prov_supp_sign_ind", "type":"string"},
"clm_receiver_etin":{"cf":"c", "col":"clm_receiver_etin", "type":"string"},
"clm_receiver_f_nm":{"cf":"c", "col":"clm_receiver_f_nm", "type":"string"},
"clm_receiver_org_l_nm":{"cf":"c", "col":"clm_receiver_org_l_nm", "type":"string"},
"clm_ref_prov_comm_num":{"cf":"c", "col":"clm_ref_prov_comm_num", "type":"string"},
"clm_ref_prov_f_nm":{"cf":"c", "col":"clm_ref_prov_f_nm", "type":"string"},
"clm_ref_prov_l_nm":{"cf":"c", "col":"clm_ref_prov_l_nm", "type":"string"},
"clm_ref_prov_m_nm":{"cf":"c", "col":"clm_ref_prov_m_nm", "type":"string"},
"clm_ref_prov_npi":{"cf":"c", "col":"clm_ref_prov_npi", "type":"string"},
"clm_ref_prov_st_ln_num":{"cf":"c", "col":"clm_ref_prov_st_ln_num", "type":"string"},
"clm_ref_prov_upin_num":{"cf":"c", "col":"clm_ref_prov_upin_num", "type":"string"},
"clm_referral_num":{"cf":"c", "col":"clm_referral_num", "type":"string"},
"clm_related_cause_cd1":{"cf":"c", "col":"clm_related_cause_cd1", "type":"string"},
"clm_related_cause_cd2":{"cf":"c", "col":"clm_related_cause_cd2", "type":"string"},
"clm_related_cause_ind":{"cf":"c", "col":"clm_related_cause_ind", "type":"string"},
"clm_release_inf_cd":{"cf":"c", "col":"clm_release_inf_cd", "type":"string"},
"clm_rend_prov_comm_num":{"cf":"c", "col":"clm_rend_prov_comm_num", "type":"string"},
"clm_rend_prov_f_nm":{"cf":"c", "col":"clm_rend_prov_f_nm", "type":"string"},
"clm_rend_prov_l_nm":{"cf":"c", "col":"clm_rend_prov_l_nm", "type":"string"},
"clm_rend_prov_loc_num":{"cf":"c", "col":"clm_rend_prov_loc_num", "type":"string"},
"clm_rend_prov_m_nm":{"cf":"c", "col":"clm_rend_prov_m_nm", "type":"string"},
"clm_rend_prov_npi":{"cf":"c", "col":"clm_rend_prov_npi", "type":"string"},
"clm_rend_prov_st_ln_num":{"cf":"c", "col":"clm_rend_prov_st_ln_num", "type":"string"},
"clm_rend_prov_taxonomy_cd":{"cf":"c", "col":"clm_rend_prov_taxonomy_cd", "type":"string"},
"clm_rend_prov_upin_num":{"cf":"c", "col":"clm_rend_prov_upin_num", "type":"string"},
"clm_repriced_clm_num":{"cf":"c", "col":"clm_repriced_clm_num", "type":"string"},
"clm_spinal_condition_cd":{"cf":"c", "col":"clm_spinal_condition_cd", "type":"string"},
"clm_src_typ_cd":{"cf":"c", "col":"clm_src_typ_cd", "type":"string"},
"clm_srvc_auth_exception_cd":{"cf":"c", "col":"clm_srvc_auth_exception_cd", "type":"string"},
"clm_submitted_f_nm":{"cf":"c", "col":"clm_submitted_f_nm", "type":"string"},
"clm_submitter_contact_nm":{"cf":"c", "col":"clm_submitter_contact_nm", "type":"string"},
"clm_submitter_email":{"cf":"c", "col":"clm_submitter_email", "type":"string"},
"clm_submitter_entity_type":{"cf":"c", "col":"clm_submitter_entity_type", "type":"string"},
"clm_submitter_fax":{"cf":"c", "col":"clm_submitter_fax", "type":"string"},
"clm_submitter_id":{"cf":"c", "col":"clm_submitter_id", "type":"string"},
"clm_submitter_org_l_nm":{"cf":"c", "col":"clm_submitter_org_l_nm", "type":"string"},
"clm_submitter_phone_ext":{"cf":"c", "col":"clm_submitter_phone_ext", "type":"string"},
"clm_submitter_phone_num":{"cf":"c", "col":"clm_submitter_phone_num", "type":"string"},
"clm_subs_addr":{"cf":"c", "col":"clm_subs_addr", "type":"string"},
"clm_subs_city":{"cf":"c", "col":"clm_subs_city", "type":"string"},
"clm_subs_cntry":{"cf":"c", "col":"clm_subs_cntry", "type":"string"},
"clm_subs_dob":{"cf":"c", "col":"clm_subs_dob", "type":"string"},
"clm_subs_entity_type":{"cf":"c", "col":"clm_subs_entity_type", "type":"string"},
"clm_subs_f_name":{"cf":"c", "col":"clm_subs_f_name", "type":"string"},
"clm_subs_gender":{"cf":"c", "col":"clm_subs_gender", "type":"string"},
"clm_subs_hipi":{"cf":"c", "col":"clm_subs_hipi", "type":"string"},
"clm_subs_id":{"cf":"c", "col":"clm_subs_id", "type":"string"},
"clm_subs_m_name":{"cf":"c", "col":"clm_subs_m_name", "type":"string"},
"clm_subs_marital_status":{"cf":"c", "col":"clm_subs_marital_status", "type":"string"},
"clm_subs_org_l_name":{"cf":"c", "col":"clm_subs_org_l_name", "type":"string"},
"clm_subs_ssn":{"cf":"c", "col":"clm_subs_ssn", "type":"string"},
"clm_subs_state":{"cf":"c", "col":"clm_subs_state", "type":"string"},
"clm_subs_zip":{"cf":"c", "col":"clm_subs_zip", "type":"string"},
"clm_suprv_phys_comm_num":{"cf":"c", "col":"clm_suprv_phys_comm_num", "type":"string"},
"clm_suprv_phys_f_nm":{"cf":"c", "col":"clm_suprv_phys_f_nm", "type":"string"},
"clm_suprv_phys_l_nm":{"cf":"c", "col":"clm_suprv_phys_l_nm", "type":"string"},
"clm_suprv_phys_loc_num":{"cf":"c", "col":"clm_suprv_phys_loc_num", "type":"string"},
"clm_suprv_phys_m_nm":{"cf":"c", "col":"clm_suprv_phys_m_nm", "type":"string"},
"clm_suprv_phys_npi":{"cf":"c", "col":"clm_suprv_phys_npi", "type":"string"},
"clm_suprv_phys_st_ln_num":{"cf":"c", "col":"clm_suprv_phys_st_ln_num", "type":"string"},
"clm_suprv_phys_upin_num":{"cf":"c", "col":"clm_suprv_phys_upin_num", "type":"string"},
"clm_sys_id":{"cf":"c", "col":"clm_sys_id", "type":"string"},
"clm_total_charge":{"cf":"c", "col":"clm_total_charge", "type":"string"},
"clm_trans_creation_date":{"cf":"c", "col":"clm_trans_creation_date", "type":"string"},
"clm_trans_creation_time":{"cf":"c", "col":"clm_trans_creation_time", "type":"string"},
"clm_trans_ctrl_nbr":{"cf":"c", "col":"clm_trans_ctrl_nbr", "type":"string"},
"clm_trans_type_cd":{"cf":"c", "col":"clm_trans_type_cd", "type":"string"},
"clm_transport_dist":{"cf":"c", "col":"clm_transport_dist", "type":"string"},
"clm_typ_cd":{"cf":"c", "col":"clm_typ_cd", "type":"string"},
"clm_type":{"cf":"c", "col":"clm_type", "type":"string"},
"clm_vis_condition_cd11":{"cf":"c", "col":"clm_vis_condition_cd11", "type":"string"},
"clm_vis_condition_cd12":{"cf":"c", "col":"clm_vis_condition_cd12", "type":"string"},
"clm_vis_condition_cd13":{"cf":"c", "col":"clm_vis_condition_cd13", "type":"string"},
"clm_vis_condition_cd14":{"cf":"c", "col":"clm_vis_condition_cd14", "type":"string"},
"clm_vis_condition_cd15":{"cf":"c", "col":"clm_vis_condition_cd15", "type":"string"},
"clm_vis_condition_cd21":{"cf":"c", "col":"clm_vis_condition_cd21", "type":"string"},
"clm_vis_condition_cd22":{"cf":"c", "col":"clm_vis_condition_cd22", "type":"string"},
"clm_vis_condition_cd23":{"cf":"c", "col":"clm_vis_condition_cd23", "type":"string"},
"clm_vis_condition_cd24":{"cf":"c", "col":"clm_vis_condition_cd24", "type":"string"},
"clm_vis_condition_cd25":{"cf":"c", "col":"clm_vis_condition_cd25", "type":"string"},
"clm_vis_condition_cd31":{"cf":"c", "col":"clm_vis_condition_cd31", "type":"string"},
"clm_vis_condition_cd32":{"cf":"c", "col":"clm_vis_condition_cd32", "type":"string"},
"clm_vis_condition_cd33":{"cf":"c", "col":"clm_vis_condition_cd33", "type":"string"},
"clm_vis_condition_cd34":{"cf":"c", "col":"clm_vis_condition_cd34", "type":"string"},
"clm_vis_condition_cd35":{"cf":"c", "col":"clm_vis_condition_cd35", "type":"string"},
"clm_vision_cond_catgy1":{"cf":"c", "col":"clm_vision_cond_catgy1", "type":"string"},
"clm_vision_cond_catgy2":{"cf":"c", "col":"clm_vision_cond_catgy2", "type":"string"},
"clm_vision_cond_catgy3":{"cf":"c", "col":"clm_vision_cond_catgy3", "type":"string"},
"clm_vision_cond_ind1":{"cf":"c", "col":"clm_vision_cond_ind1", "type":"string"},
"clm_vision_cond_ind2":{"cf":"c", "col":"clm_vision_cond_ind2", "type":"string"},
"clm_vision_cond_ind3":{"cf":"c", "col":"clm_vision_cond_ind3", "type":"string"},
"ee_id":{"cf":"c", "col":"ee_id", "type":"string"},
"fln_nbr":{"cf":"c", "col":"fln_nbr", "type":"string"},
"invn_ctl_nbr":{"cf":"c", "col":"invn_ctl_nbr", "type":"string"},
"prov_mpin_id":{"cf":"c", "col":"prov_mpin_id", "type":"string"},
"srk_clm_id":{"cf":"c", "col":"srk_clm_id", "type":"string"}}})
	
base_claim_dto = sqlc.read\
    .options(catalog=catalog)\
    .format(data_source_format)\
    .load()




catalog1 = json.dumps(
{
"table":{"namespace":"default", "name":hbase_servicelineDTO_table},
"rowkey":"key",
"columns":{
"key":{"cf":"rowkey", "col":"key", "type":"string"},
"batch_run_dt":{"cf":"c", "col":"batch_run_dt", "type":"string"},
"batchid":{"cf":"c", "col":"batchid", "type":"string"},
"cl_amb_cond_ind1":{"cf":"c", "col":"cl_amb_cond_ind1", "type":"string"},
"cl_amb_cond_ind2":{"cf":"c", "col":"cl_amb_cond_ind2", "type":"string"},
"cl_amb_cond_ind3":{"cf":"c", "col":"cl_amb_cond_ind3", "type":"string"},
"cl_amb_condition_cd11":{"cf":"c", "col":"cl_amb_condition_cd11", "type":"string"},
"cl_amb_condition_cd12":{"cf":"c", "col":"cl_amb_condition_cd12", "type":"string"},
"cl_amb_condition_cd13":{"cf":"c", "col":"cl_amb_condition_cd13", "type":"string"},
"cl_amb_condition_cd14":{"cf":"c", "col":"cl_amb_condition_cd14", "type":"string"},
"cl_amb_condition_cd15":{"cf":"c", "col":"cl_amb_condition_cd15", "type":"string"},
"cl_amb_condition_cd21":{"cf":"c", "col":"cl_amb_condition_cd21", "type":"string"},
"cl_amb_condition_cd22":{"cf":"c", "col":"cl_amb_condition_cd22", "type":"string"},
"cl_amb_condition_cd23":{"cf":"c", "col":"cl_amb_condition_cd23", "type":"string"},
"cl_amb_condition_cd24":{"cf":"c", "col":"cl_amb_condition_cd24", "type":"string"},
"cl_amb_condition_cd25":{"cf":"c", "col":"cl_amb_condition_cd25", "type":"string"},
"cl_amb_condition_cd31":{"cf":"c", "col":"cl_amb_condition_cd31", "type":"string"},
"cl_amb_condition_cd32":{"cf":"c", "col":"cl_amb_condition_cd32", "type":"string"},
"cl_amb_condition_cd33":{"cf":"c", "col":"cl_amb_condition_cd33", "type":"string"},
"cl_amb_condition_cd34":{"cf":"c", "col":"cl_amb_condition_cd34", "type":"string"},
"cl_amb_condition_cd35":{"cf":"c", "col":"cl_amb_condition_cd35", "type":"string"},
"cl_amb_trans_rsn_cd":{"cf":"c", "col":"cl_amb_trans_rsn_cd", "type":"string"},
"cl_attch_control_num1":{"cf":"c", "col":"cl_attch_control_num1", "type":"string"},
"cl_attch_control_num10":{"cf":"c", "col":"cl_attch_control_num10", "type":"string"},
"cl_attch_control_num2":{"cf":"c", "col":"cl_attch_control_num2", "type":"string"},
"cl_attch_control_num3":{"cf":"c", "col":"cl_attch_control_num3", "type":"string"},
"cl_attch_control_num4":{"cf":"c", "col":"cl_attch_control_num4", "type":"string"},
"cl_attch_control_num5":{"cf":"c", "col":"cl_attch_control_num5", "type":"string"},
"cl_attch_control_num6":{"cf":"c", "col":"cl_attch_control_num6", "type":"string"},
"cl_attch_control_num7":{"cf":"c", "col":"cl_attch_control_num7", "type":"string"},
"cl_attch_control_num8":{"cf":"c", "col":"cl_attch_control_num8", "type":"string"},
"cl_attch_control_num9":{"cf":"c", "col":"cl_attch_control_num9", "type":"string"},
"cl_attch_trans_cd1":{"cf":"c", "col":"cl_attch_trans_cd1", "type":"string"},
"cl_attch_trans_cd10":{"cf":"c", "col":"cl_attch_trans_cd10", "type":"string"},
"cl_attch_trans_cd2":{"cf":"c", "col":"cl_attch_trans_cd2", "type":"string"},
"cl_attch_trans_cd3":{"cf":"c", "col":"cl_attch_trans_cd3", "type":"string"},
"cl_attch_trans_cd4":{"cf":"c", "col":"cl_attch_trans_cd4", "type":"string"},
"cl_attch_trans_cd5":{"cf":"c", "col":"cl_attch_trans_cd5", "type":"string"},
"cl_attch_trans_cd6":{"cf":"c", "col":"cl_attch_trans_cd6", "type":"string"},
"cl_attch_trans_cd7":{"cf":"c", "col":"cl_attch_trans_cd7", "type":"string"},
"cl_attch_trans_cd8":{"cf":"c", "col":"cl_attch_trans_cd8", "type":"string"},
"cl_attch_trans_cd9":{"cf":"c", "col":"cl_attch_trans_cd9", "type":"string"},
"cl_attch_type_cd1":{"cf":"c", "col":"cl_attch_type_cd1", "type":"string"},
"cl_attch_type_cd10":{"cf":"c", "col":"cl_attch_type_cd10", "type":"string"},
"cl_attch_type_cd2":{"cf":"c", "col":"cl_attch_type_cd2", "type":"string"},
"cl_attch_type_cd3":{"cf":"c", "col":"cl_attch_type_cd3", "type":"string"},
"cl_attch_type_cd4":{"cf":"c", "col":"cl_attch_type_cd4", "type":"string"},
"cl_attch_type_cd5":{"cf":"c", "col":"cl_attch_type_cd5", "type":"string"},
"cl_attch_type_cd6":{"cf":"c", "col":"cl_attch_type_cd6", "type":"string"},
"cl_attch_type_cd7":{"cf":"c", "col":"cl_attch_type_cd7", "type":"string"},
"cl_attch_type_cd8":{"cf":"c", "col":"cl_attch_type_cd8", "type":"string"},
"cl_attch_type_cd9":{"cf":"c", "col":"cl_attch_type_cd9", "type":"string"},
"cl_clia_num":{"cf":"c", "col":"cl_clia_num", "type":"string"},
"cl_co_pay_stat_cd":{"cf":"c", "col":"cl_co_pay_stat_cd", "type":"string"},
"cl_dme_condition_cd1":{"cf":"c", "col":"cl_dme_condition_cd1", "type":"string"},
"cl_dme_condition_cd2":{"cf":"c", "col":"cl_dme_condition_cd2", "type":"string"},
"cl_dme_ind":{"cf":"c", "col":"cl_dme_ind", "type":"string"},
"cl_dur_med_eq_proc":{"cf":"c", "col":"cl_dur_med_eq_proc", "type":"string"},
"cl_dur_med_eq_proc_mod1":{"cf":"c", "col":"cl_dur_med_eq_proc_mod1", "type":"string"},
"cl_dur_med_eq_proc_mod2":{"cf":"c", "col":"cl_dur_med_eq_proc_mod2", "type":"string"},
"cl_dur_med_eq_proc_mod3":{"cf":"c", "col":"cl_dur_med_eq_proc_mod3", "type":"string"},
"cl_dur_med_eq_proc_mod4":{"cf":"c", "col":"cl_dur_med_eq_proc_mod4", "type":"string"},
"cl_dur_med_eq_proc_type":{"cf":"c", "col":"cl_dur_med_eq_proc_type", "type":"string"},
"cl_emergency_ind":{"cf":"c", "col":"cl_emergency_ind", "type":"string"},
"cl_epsdt_ind":{"cf":"c", "col":"cl_epsdt_ind", "type":"string"},
"cl_facility_addr":{"cf":"c", "col":"cl_facility_addr", "type":"string"},
"cl_facility_city":{"cf":"c", "col":"cl_facility_city", "type":"string"},
"cl_facility_comm_num":{"cf":"c", "col":"cl_facility_comm_num", "type":"string"},
"cl_facility_loc_num":{"cf":"c", "col":"cl_facility_loc_num", "type":"string"},
"cl_facility_nm":{"cf":"c", "col":"cl_facility_nm", "type":"string"},
"cl_facility_npi":{"cf":"c", "col":"cl_facility_npi", "type":"string"},
"cl_facility_state":{"cf":"c", "col":"cl_facility_state", "type":"string"},
"cl_facility_zip":{"cf":"c", "col":"cl_facility_zip", "type":"string"},
"cl_fam_plan_ind":{"cf":"c", "col":"cl_fam_plan_ind", "type":"string"},
"cl_fst_serv_dt":{"cf":"c", "col":"cl_fst_serv_dt", "type":"string"},
"cl_hospice_condition_cd":{"cf":"c", "col":"cl_hospice_condition_cd", "type":"string"},
"cl_hospice_ind":{"cf":"c", "col":"cl_hospice_ind", "type":"string"},
"cl_immunization_batch_num":{"cf":"c", "col":"cl_immunization_batch_num", "type":"string"},
"cl_initial_treatment_dt":{"cf":"c", "col":"cl_initial_treatment_dt", "type":"string"},
"cl_line_item_chrg_amt":{"cf":"c", "col":"cl_line_item_chrg_amt", "type":"string"},
"cl_line_item_ctrl_num":{"cf":"c", "col":"cl_line_item_ctrl_num", "type":"string"},
"cl_lst_serv_dt":{"cf":"c", "col":"cl_lst_serv_dt", "type":"string"},
"cl_mammo_cert_num":{"cf":"c", "col":"cl_mammo_cert_num", "type":"string"},
"cl_measurement_code":{"cf":"c", "col":"cl_measurement_code", "type":"string"},
"cl_measurement_unit":{"cf":"c", "col":"cl_measurement_unit", "type":"string"},
"cl_ndc":{"cf":"c", "col":"cl_ndc", "type":"string"},
"cl_ndc_measurement_code":{"cf":"c", "col":"cl_ndc_measurement_code", "type":"string"},
"cl_ndc_unit_cnt":{"cf":"c", "col":"cl_ndc_unit_cnt", "type":"string"},
"cl_ndc_unit_price":{"cf":"c", "col":"cl_ndc_unit_price", "type":"string"},
"cl_order_pro_l_nm":{"cf":"c", "col":"cl_order_pro_l_nm", "type":"string"},
"cl_order_prov_addr":{"cf":"c", "col":"cl_order_prov_addr", "type":"string"},
"cl_order_prov_city":{"cf":"c", "col":"cl_order_prov_city", "type":"string"},
"cl_order_prov_comm_num":{"cf":"c", "col":"cl_order_prov_comm_num", "type":"string"},
"cl_order_prov_contact_nm":{"cf":"c", "col":"cl_order_prov_contact_nm", "type":"string"},
"cl_order_prov_email":{"cf":"c", "col":"cl_order_prov_email", "type":"string"},
"cl_order_prov_f_nm":{"cf":"c", "col":"cl_order_prov_f_nm", "type":"string"},
"cl_order_prov_fax":{"cf":"c", "col":"cl_order_prov_fax", "type":"string"},
"cl_order_prov_m_nm":{"cf":"c", "col":"cl_order_prov_m_nm", "type":"string"},
"cl_order_prov_npi":{"cf":"c", "col":"cl_order_prov_npi", "type":"string"},
"cl_order_prov_phone":{"cf":"c", "col":"cl_order_prov_phone", "type":"string"},
"cl_order_prov_phone_ext":{"cf":"c", "col":"cl_order_prov_phone_ext", "type":"string"},
"cl_order_prov_st":{"cf":"c", "col":"cl_order_prov_st", "type":"string"},
"cl_order_prov_st_ln_num":{"cf":"c", "col":"cl_order_prov_st_ln_num", "type":"string"},
"cl_order_prov_upin_num":{"cf":"c", "col":"cl_order_prov_upin_num", "type":"string"},
"cl_order_prov_zip":{"cf":"c", "col":"cl_order_prov_zip", "type":"string"},
"cl_place_of_srcv":{"cf":"c", "col":"cl_place_of_srcv", "type":"string"},
"cl_presc_dt":{"cf":"c", "col":"cl_presc_dt", "type":"string"},
"cl_prim_care_prov_comm_num":{"cf":"c", "col":"cl_prim_care_prov_comm_num", "type":"string"},
"cl_prim_care_prov_f_name":{"cf":"c", "col":"cl_prim_care_prov_f_name", "type":"string"},
"cl_prim_care_prov_l_name":{"cf":"c", "col":"cl_prim_care_prov_l_name", "type":"string"},
"cl_prim_care_prov_m_name":{"cf":"c", "col":"cl_prim_care_prov_m_name", "type":"string"},
"cl_prim_care_prov_npi":{"cf":"c", "col":"cl_prim_care_prov_npi", "type":"string"},
"cl_prim_care_prov_st_ln_num":{"cf":"c", "col":"cl_prim_care_prov_st_ln_num", "type":"string"},
"cl_prim_care_prov_upin_num":{"cf":"c", "col":"cl_prim_care_prov_upin_num", "type":"string"},
"cl_prior_auth_num1":{"cf":"c", "col":"cl_prior_auth_num1", "type":"string"},
"cl_prior_auth_num2":{"cf":"c", "col":"cl_prior_auth_num2", "type":"string"},
"cl_prior_auth_num3":{"cf":"c", "col":"cl_prior_auth_num3", "type":"string"},
"cl_prior_auth_num4":{"cf":"c", "col":"cl_prior_auth_num4", "type":"string"},
"cl_prior_auth_num5":{"cf":"c", "col":"cl_prior_auth_num5", "type":"string"},
"cl_proc_cd":{"cf":"c", "col":"cl_proc_cd", "type":"string"},
"cl_proc_cd_type":{"cf":"c", "col":"cl_proc_cd_type", "type":"string"},
"cl_proc_mod1":{"cf":"c", "col":"cl_proc_mod1", "type":"string"},
"cl_proc_mod2":{"cf":"c", "col":"cl_proc_mod2", "type":"string"},
"cl_proc_mod3":{"cf":"c", "col":"cl_proc_mod3", "type":"string"},
"cl_proc_mod4":{"cf":"c", "col":"cl_proc_mod4", "type":"string"},
"cl_purchase_price":{"cf":"c", "col":"cl_purchase_price", "type":"string"},
"cl_quantity_days":{"cf":"c", "col":"cl_quantity_days", "type":"string"},
"cl_ref_prov_comm_num":{"cf":"c", "col":"cl_ref_prov_comm_num", "type":"string"},
"cl_ref_prov_f_nm":{"cf":"c", "col":"cl_ref_prov_f_nm", "type":"string"},
"cl_ref_prov_l_nm":{"cf":"c", "col":"cl_ref_prov_l_nm", "type":"string"},
"cl_ref_prov_m_nm":{"cf":"c", "col":"cl_ref_prov_m_nm", "type":"string"},
"cl_ref_prov_npi":{"cf":"c", "col":"cl_ref_prov_npi", "type":"string"},
"cl_ref_prov_st_ln_num":{"cf":"c", "col":"cl_ref_prov_st_ln_num", "type":"string"},
"cl_ref_prov_upin_num":{"cf":"c", "col":"cl_ref_prov_upin_num", "type":"string"},
"cl_rend_prov_comm_num":{"cf":"c", "col":"cl_rend_prov_comm_num", "type":"string"},
"cl_rend_prov_f_nm":{"cf":"c", "col":"cl_rend_prov_f_nm", "type":"string"},
"cl_rend_prov_l_nm":{"cf":"c", "col":"cl_rend_prov_l_nm", "type":"string"},
"cl_rend_prov_loc_num":{"cf":"c", "col":"cl_rend_prov_loc_num", "type":"string"},
"cl_rend_prov_m_nm":{"cf":"c", "col":"cl_rend_prov_m_nm", "type":"string"},
"cl_rend_prov_npi":{"cf":"c", "col":"cl_rend_prov_npi", "type":"string"},
"cl_rend_prov_st_ln_num":{"cf":"c", "col":"cl_rend_prov_st_ln_num", "type":"string"},
"cl_rend_prov_taxonomy_cd":{"cf":"c", "col":"cl_rend_prov_taxonomy_cd", "type":"string"},
"cl_rend_prov_upin_num":{"cf":"c", "col":"cl_rend_prov_upin_num", "type":"string"},
"cl_rental_frequency":{"cf":"c", "col":"cl_rental_frequency", "type":"string"},
"cl_rental_price":{"cf":"c", "col":"cl_rental_price", "type":"string"},
"cl_service_line_num":{"cf":"c", "col":"cl_service_line_num", "type":"string"},
"cl_suprv_phys_comm_num":{"cf":"c", "col":"cl_suprv_phys_comm_num", "type":"string"},
"cl_suprv_phys_f_nm":{"cf":"c", "col":"cl_suprv_phys_f_nm", "type":"string"},
"cl_suprv_phys_l_nm":{"cf":"c", "col":"cl_suprv_phys_l_nm", "type":"string"},
"cl_suprv_phys_loc_num":{"cf":"c", "col":"cl_suprv_phys_loc_num", "type":"string"},
"cl_suprv_phys_m_nm":{"cf":"c", "col":"cl_suprv_phys_m_nm", "type":"string"},
"cl_suprv_phys_npi":{"cf":"c", "col":"cl_suprv_phys_npi", "type":"string"},
"cl_suprv_phys_st_ln_num":{"cf":"c", "col":"cl_suprv_phys_st_ln_num", "type":"string"},
"cl_suprv_phys_upin_num":{"cf":"c", "col":"cl_suprv_phys_upin_num", "type":"string"},
"cl_transport_dist":{"cf":"c", "col":"cl_transport_dist", "type":"string"},
"cl_units_billed":{"cf":"c", "col":"cl_units_billed", "type":"string"},
"clm_type":{"cf":"c", "col":"clm_type", "type":"string"},
"srk_clm_id":{"cf":"c", "col":"srk_clm_id", "type":"string"},
"cl_operating_prov_comm_num":{"cf":"c", "col":"cl_operating_prov_comm_num", "type":"string"},
"cl_operating_prov_f_nm":{"cf":"c", "col":"cl_operating_prov_f_nm", "type":"string"},
"cl_operating_prov_l_nm":{"cf":"c", "col":"cl_operating_prov_l_nm", "type":"string"},
"cl_operating_prov_loc_num":{"cf":"c", "col":"cl_operating_prov_loc_num", "type":"string"},
"cl_operating_prov_m_nm":{"cf":"c", "col":"cl_operating_prov_m_nm", "type":"string"},
"cl_operating_prov_npi":{"cf":"c", "col":"cl_operating_prov_npi", "type":"string"},
"cl_operating_prov_st_ln_num":{"cf":"c", "col":"cl_operating_prov_st_ln_num", "type":"string"},
"cl_operating_prov_upin_num":{"cf":"c", "col":"cl_operating_prov_upin_num", "type":"string"},
"cl_rvnu_cd":{"cf":"c", "col":"cl_rvnu_cd", "type":"string"}}})

base_claim_dto1 = sqlc.read\
    .options(catalog=catalog1)\
    .format(data_source_format)\
    .load()

base_claim_dto.createOrReplaceTempView('base_claim_dto')
base_claim_dto1.createOrReplaceTempView('base_claim_dto1')


print("batch Id : ",sys.argv[25])
batch_id =int(sys.argv[25])
print("fetched batchid")


try:
	module_name="Streaming process started"
	module_id=str(mid[0])
	#r = requests.post(tracking_url, json=parameters(module_id,status[0],""))
	#print(r.text)
	print("######################## Reading  #####################################################################")
	
	data = get_raw_data_batch_s(batch_id)
	data.cache()
	data_count = data.count()
	print("Total Records:")
	print(data_count)
	
	if(data_count > 0):
		print("Data is available")
	else:
		print("Data is not available")
		print("Do not run rest of the Steps")
		end = datetime.now().replace(microsecond=0)
		print(end-start)
		data.unpersist()
		sys.exit()
	
	print("data part completed")

	
	preprocessed_data = data_preprocessing_s(data)
	data.unpersist()


	features = generate_signal_s(preprocessed_data, ['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt'], em_proc_code_list, high_cost_jcode_list)

	print("Features data complete")

	# Reading input tables
	m_data  = "{}.{}".format(database_name, mean_data)                      # Change to prod_db
	mean_data = spark.table(m_data)
	i_data  = "{}.{}".format(database_name, icov_data)
	icov_data = spark.table(i_data)                                       # Change to prod_db
	 
	imputed_data =  data_imputation_scoring(features, mean_data, icov_data)

	print("imputed data complete")

	imputed_data[0].cache()
	print("imputed data[0] cache complete")

	imputed_data[0].count()
	print("imputed data[0] count complete")

	flagged_data = clm_scoring(imputed_data[0])
	print("Flagged data complete")


	a = [col for col in flagged_data[0].columns if col.startswith("covar")]
	flg_data= flagged_data[0].drop(*a)
	flg_data.cache()
	flg_data.count()

		
	data_rsn = reason_gen(flg_data)

	data_rsn = data_rsn.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md', 'dict', 'ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11'] + col_list)

	data_complete = data_rsn.union(flagged_data[1])

	print(" Complete data complete")

	#data_history = data_complete.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md','dict'] + col_list).union(imputed_data[1])
	#data_history.write.mode('append').partitionBy('batch_run_dt').saveAsTable(database_name + "." + history_data)

	data_history = data_complete.select(['servicing_npi', 'claim_number', 'fln_nbr', 'batch_run_dt', 'md','dict'] + col_list + ['ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11']).union(imputed_data[1])
	data_history.write.mode('append').partitionBy('batch_run_dt').saveAsTable(database_name + "." + history_data)
	cols_of_ps_history=len(data_history.columns)
	print("cols_of_ps_history")
	print(cols_of_ps_history)

	print("History data complete")
	data_score = data_complete.select(['servicing_npi', 'claim_number', 'md', 'ps_Reason1', 'ps_Reason2', 'ps_Reason3', 'ps_Reason4', 'ps_Reason5', 'ps_Reason6', 'ps_Reason7', 'ps_Reason8', 'ps_Reason9', 'ps_Reason10', 'ps_Reason11'])

	w = Window.partitionBy("claim_number").orderBy(F.desc("md"))

	data_score = data_score.withColumn("rank", F.row_number().over(w)).filter(F.col("rank") == 1)
	data_score = data_score.withColumnRenamed("md", "ps_score").drop("rank", "servicing_npi")
	data_score = data_score.withColumn("ps_discrepancy_flag", F.array(F.lit("NA")))
	print("Score data complete")
	data_score.createOrReplaceTempView("data_score")

	spark.sql("insert into {}.{} select * from data_score".format(database_name, ps_clm_output))
	print("############################### Inserting into HBase Tables ############################################################")
	data_score.show(2)
	print("Score data Inserted")

	flg_data.unpersist()
	imputed_data[0].unpersist()

	print("#######################  Total time taken  #######################")

	end = datetime.now().replace(microsecond=0)
	print(end-start)

	print("Streaming Process completed")
	
	#r = requests.post(tracking_url, json=parameters(module_id,status[1],""))
	#print(r.text)

except:
	error = sys.exc_info()[0]
	print(sys.exc_info()[0], 'occured.')
	#r = requests.post(tracking_url, json=parameters(module_id,status[2],str(error)))
	#print(r.text)
	#r = requests.post(source_tracking_url, json=src_parameters(status[2],str(error)))
	#print("Source tracking api return="+r.text)
	

exit()
