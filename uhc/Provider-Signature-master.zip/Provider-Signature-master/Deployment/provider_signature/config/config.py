[section1]
mean_data=psm_mean_data
icov_data=psm_icov_data
preprocessed_table=processed_claims
proc_cd_lb_table=ps_lb_cl_proc_cd
pos_lb_table=ps_lb_cl_place_of_srcv
history_data=ps_history
ps_clm_output=ps_claims_score
servicelineDTO_table=servicelineDTO
claimDTO_table=claimDTO

    


