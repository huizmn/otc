import time
import pyspark
import datetime
import numpy as np
import pandas as pd
from functools import reduce
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql import SparkSession

#Utility Function

def get_data(sessn, query):

    try:
        return sessn.sql(query)
    except Exception as e:
        print(e)


sessn = SparkSession.builder.appName("PS").enableHiveSupport().getOrCreate().newSession()
sessn

initial_time = time.time()

# Date Range
#lower_dt = "20190701"
#upper_dt = "20200930"

lower_dt = "20191001"
upper_dt = "20201231"

db = "pi_prod_tmp"
raw_table = "ps_837p_historical"
acquisition_table  = "{}.{}".format(db, raw_table)
batch_ = 6

start = datetime.datetime.strptime(lower_dt, "%Y%m%d")
end   = datetime.datetime.strptime(upper_dt, "%Y%m%d")
date_list = [(start + datetime.timedelta(days=x)).strftime("%Y%m%d") for x in range(0, (end-start).days+1)]
date_split = {}
date_batch = np.array_split(date_list, batch_)


for b in range(batch_):
    s = "batch_{}".format(b)
    l_dt = date_batch[b][0]
    u_dt = date_batch[b][-1]
    date_split[s] = {'l_dt' : l_dt,
                     'u_dt' : u_dt}

list(date_split)

# ['batch_2', 'batch_5', 'batch_1', 'batch_4', 'batch_3', 'batch_0']

##  Data pull from 837p

# Splting the time frame into # batches
start = datetime.datetime.strptime(lower_dt, "%Y%m%d")
end   = datetime.datetime.strptime(upper_dt, "%Y%m%d")
date_list = [(start + datetime.timedelta(days=x)).strftime("%Y%m%d") for x in range(0, (end-start).days+1)]
date_split = {}
date_batch = np.array_split(date_list, batch_)
for b in range(batch_):
    s = "batch_{}".format(b)
    l_dt = date_batch[b][0]
    u_dt = date_batch[b][-1]
    date_split[s] = {'l_dt' : l_dt,
                     'u_dt' : u_dt}
    
# Fetching the data from 837p claim analytic table for the batches    

for b in list(date_split):
    st1 = time.time()
    raw_table_op = "{}_{}_temp".format(acquisition_table, b)
    l_dt = date_split[b]['l_dt']
    u_dt = date_split[b]['u_dt']
    query = """
                SELECT 
                  DISTINCT 
                  srk_clm_id,  
                  clm_bill_prov_npi,
                  cl_rend_prov_npi, 
                  fln_nbr,
                  CASE WHEN trim(clm_bill_prov_tin) = '' OR trim(clm_bill_prov_tin) IS NULL THEN trim(clm_bill_prov_ssn) ELSE trim(clm_bill_prov_tin) END AS prov_tin,
                  batch_run_dt, 
                  cl_proc_cd, 
                  cl_proc_mod1, 
                  cl_proc_mod2, 
                  cl_proc_mod3,
                  cl_proc_mod4,
                  cl_line_item_chrg_amt, 
                  cl_place_of_srcv, 
                  cl_emergency_ind, 
                  cl_units_billed 
                FROM 
                  pi_prod.837p_clm_analytic_data 
                WHERE
                  batch_run_dt BETWEEN '{}' AND '{}'
            """.format(l_dt, u_dt)
    query = " ".join(query.split())
    data = get_data(sessn, query)
    data.write.mode("overwrite").format("parquet").saveAsTable(raw_table_op)
    print(raw_table_op)
	

final_cnt = []
batch_dfs = []
for b in list(date_split):
    batch_table = "{}_{}_temp".format(acquisition_table, b)
    data = sessn.table(batch_table)
    batch_dfs.append(data)
    data_cnt = data.count()
    final_cnt.append(data_cnt)

final_data = reduce(DataFrame.unionAll, batch_dfs)

#Sanity Check

final_data.count() == np.sum(final_cnt)

#True

final_data.select(F.min("batch_run_dt"), F.max("batch_run_dt")).toPandas()


#Writing the Data

final_data.write.partitionBy("batch_run_dt").mode("overwrite").format("parquet").saveAsTable(acquisition_table)
print("Data acquisition competed")

for b in list(date_split):
    batch_table = "{}_{}_temp".format(acquisition_table, b)
    drop_cmd = "drop table {}".format(batch_table)
    sessn.sql(drop_cmd)

print("data split dropped")

tend=time.time()

print("time taken by process----------------->"),(tend-initial_time)/60

sessn.stop()