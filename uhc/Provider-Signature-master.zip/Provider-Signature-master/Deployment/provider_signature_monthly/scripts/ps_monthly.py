import os
import ConfigParser
import sys
import pyspark
from pyspark.sql import Row
import datetime
from pyspark.sql import SQLContext
import ConfigParser
import pandas as pd
import numpy as np
import datetime
import requests
import itertools as it
import pyspark.sql.functions as F
from pyspark.sql.functions import udf
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import DoubleType
import time
from datetime import datetime
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

start = datetime.now().replace(microsecond=0)
print(start)


#paths
parent_path = sys.argv[1]
mapr_parent_path = sys.argv[2]
config_path = sys.argv[3]
tracking_url = sys.argv[4]+'UpdateModuleTrackingInfo'
source_tracking_url = sys.argv[4]+'UpdateSourceTrackingInfo'
guid = sys.argv[5]
pid = sys.argv[6]
aid = sys.argv[7]
sid = sys.argv[8]
uid = sys.argv[9]
py_libs = sys.argv[10]
memoryOverhead = sys.argv[11]
appname = sys.argv[12]
env = sys.argv[14]

portfolio_config_url = sys.argv[13] + 'GetPortfolioConfig'
source_config_url = sys.argv[13] + 'GetSourceConfig'
app_config_url = sys.argv[13] + 'GetApplicationConfig'

sys.path.insert(0, py_libs)


###Set configs####

config = ConfigParser.ConfigParser()
config.read(config_path)
feature_engineered_table = config.get('section1', 'feature_engineered_table')
modelling_table = config.get('section1', 'modelling_table')
mean_table = config.get('section1', 'mean_table')
icov_table = config.get('section1', 'icov_table')
p_input_database_table = config.get('section1', 'p_input_database_table')

#import portfolio config
portfolio_r = requests.post(portfolio_config_url,json={"PortfolioID":pid })
source_r = requests.post(source_config_url,json={"SourceID":aid })
app_r = requests.post(app_config_url,json={"ApplicationID":aid })
config_data = portfolio_r.json()
config_data_1 = source_r.json()
config_data_2 = app_r.json()


#application_name = sys.argv[12]
is_mock_run = filter(lambda x : x['Key'] == 'Is_Mock_Run', config_data_2)[0]['Value'].encode("utf-8")
database_name = filter(lambda x : x['Key'] == env+'_Hive_Database', config_data)[0]['Value'].encode("utf-8")
database_name_temp = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")
maprdb_path = filter(lambda x : x['Key'] == env+'_MapRDB_Path', config_data)[0]['Value'].encode("utf-8")
hdfs_parent_path = filter(lambda x : x['Key'] == env+'_HDFS_Parent_Path', config_data)[0]['Value'].encode("utf-8")


if is_mock_run == "True":
	database_name = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")


print("portfolio-- ",portfolio_r)
print("source -- ",source_r)
print("config data-- ",config_data_1)
print("app name-- ",appname)
print("mock run-- ",is_mock_run)
print("Db name -- ",database_name)
print("Hdfs parent name -- ",hdfs_parent_path)
print("Maprdb name -- ",maprdb_path)
print("Db name temp -- ",database_name_temp)
print("environment-- ", env) 


def parameters(a,b,c):
	params = {
	"GUID" : guid,
	"PortfolioID" : pid,
	"ApplicationID" : aid,
	"SourceID" : sid,
	"ModuleID" : a,
	"UserID" : uid,
	"Status" : b,
	"ErrorCode" : c
	}
	return params


#### arguments passed from java code
mid = ['513','514','515']
module_id=""
module_name="empty"
status = ['Start','End','Error']



sessn = SparkSession.builder.appName("PS").enableHiveSupport().getOrCreate()
sessn

sessn.conf.set("hive.exec.dynamic.partition","true")
sessn.conf.set("hive.exec.dynamic.partition.mode","nonstrict")

k = 1.5
lb_dur = 3

signal_list =  ['billed_amt_sum',
                 'clm_ln_cnt',
                 'clm_unit_billed',
                 'proc_code_unusual',
                 'pos_unsual',
                 'em_proc_ind',
                 'mod91_ind',
                 'modTC_ind',
                 'mod59_ind',
                 'high_cst_proc_ind',
                 'emgncy_ind']

clm_th =10
	

def get_first_day(dt, d_years=0, d_months=0):
    # d_years, d_months are "deltas" to apply to dt
    y, m = dt.year + d_years, dt.month + d_months
    a, m = divmod(m-1, 12)
    return date(y+a, m+1, 1)


def outlier_removal(data, signal):
    group_level = ["servicing_npi", "claim_number"]
    signal_list = [c for c in signal if "ind" not in c]
    col_to_work = signal_list + group_level
    
    data_to_work = data.select(col_to_work)
    for c in signal_list:
        c_ucl = c + "_UCL"
        c_lcl = c + "_LCL"
        c_flg = c + "_flag"
        op = control_limit(data_to_work, c, k)
        data_to_work = data_to_work.join(op, on = "servicing_npi", how = "inner")
        data_to_work = data_to_work.withColumn(c_flg, F.when(((data_to_work[c] <= data_to_work[c_ucl]) & (data_to_work[c] >= data_to_work[c_lcl])), F.lit(1)).otherwise(F.lit(0)))
        data_to_work = data_to_work.drop(c_ucl, c_lcl)
        
    data_to_work_outlier_removed = data_to_work.filter((F.col('billed_amt_sum_flag') == F.lit(1)) &
                                                    (F.col('clm_ln_cnt_flag') == F.lit(1)) &
                                                    (F.col('clm_unit_billed_flag') == F.lit(1)) &
                                                    (F.col('proc_code_unusual_flag') == F.lit(1)) &
                                                    (F.col('pos_unsual_flag') == F.lit(1)))
    data_to_work_outlier_removed = data_to_work_outlier_removed.select(group_level)
    modelling_data = data.join(data_to_work_outlier_removed, on = group_level, how = "inner")
    
    return modelling_data


def control_limit(data, c, k):
    print("Working on {}".format(c))
    col_list = ['servicing_npi', c]
    temp_df = data.select(col_list)
    temp_df.createOrReplaceTempView("t1")
    c_q1 = c + "_Q1"
    c_q3 = c + "_Q3"
    c_iqr = c + "_IQR"
    c_ucl = c + "_UCL"
    c_lcl = c + "_LCL"
    query =  "select servicing_npi, percentile({}, 0.25) as {}, percentile({}, 0.75) as {} from t1 group by servicing_npi".format(c, c_q1, c, c_q3)
    query = " ".join(query.split())
    op = get_data(query)
    op = op.withColumn(c_iqr, op[c_q3] - op[c_q1])
    op = op.withColumn(c_lcl, op[c_q1] - (op[c_iqr]*k))
    op = op.withColumn(c_ucl, op[c_q3] + (op[c_iqr]*k))
    op = op.select(['servicing_npi', c_ucl, c_lcl])
    return op


def get_data(query):
    
    try:
        return sessn.sql(query)
    except Exception as e:
        print(e)


def lookback_data(data, grouping_entity, entity):
    data = data.filter(~((data[entity] == "")|(data[entity].isNull())))
    df_agg = data.groupby(grouping_entity, entity).agg(F.count(entity).alias("freq"))
    df_agg_npi = df.groupby(grouping_entity).agg(F.count(entity).alias("freq_sum"))
    df_agg =  df_agg.join(df_agg_npi, on = grouping_entity, how = "inner")
    df_agg = df_agg.withColumn("freq_dist", F.round(F.col("freq")/F.col("freq_sum"), 3)).drop("freq", "freq_sum")
    df_agg.write.mode("overwrite").saveAsTable(database_name + "." +"ps_lb_"+entity)



@udf("int")
def place_of_srcv_validator(pls):
    
    try:
        if (pls in pls_lookup_list):
            return 1
        else:
            return 0
    except:
        return 0

try:
	module_id=str(mid[0])
	r = requests.post(tracking_url, json=parameters(module_id,status[0],""))
	
	print("************************************Application Starts*****************************************************")
	
	

	

	drop_start_date = get_first_day(date.today() - relativedelta(months = 13)).strftime('%Y%m%d')
	drop_end_date = get_first_day(date.today() - relativedelta(months = 12)).strftime('%Y%m%d')
	drop_dates = []

	for dt in range(int(drop_start_date),int(drop_end_date)-1):
		drop_dates.append(str(dt))
		

	for dp in drop_dates:
		print("Dropping Partition for:", dp)
		sessn.sql("""ALTER TABLE {database_name}.{feature_engineered_table} DROP IF EXISTS PARTITION(batch_run_dt = {dp})""".format(database_name=database_name,feature_engineered_table=feature_engineered_table,dp=dp))
	
	
	print("Dropping Partitions completed")

	
	r = requests.post(tracking_url, json=parameters(module_id,status[1],""))
	

	#################

	module_id=str(mid[1])
	r = requests.post(tracking_url, json=parameters(module_id,status[0],""))
	
	print("base_data started")

	base_data = sessn.read.table(database_name + "." +feature_engineered_table)

	modelling_data = outlier_removal(base_data, signal_list)
	modelling_data.write.mode("overwrite").saveAsTable(database_name_temp + "." +modelling_table)
	print("modelling_data completed")
	

	###########---------> Lookback Table Creation

	start_date = get_first_day(date.today() - relativedelta(months = lb_dur)).strftime('%Y%m%d')
	end_date = get_first_day(date.today()).strftime('%Y%m%d')
	
	query = """SELECT DISTINCT srk_clm_id,CASE WHEN trim(cl_rend_prov_npi) = '' OR trim(cl_rend_prov_npi) IS NULL THEN trim(clm_bill_prov_npi) ELSE trim(cl_rend_prov_npi) END AS servicing_npi,batch_run_dt, trim(cl_proc_cd) as cl_proc_cd, trim(cl_place_of_srcv) as cl_place_of_srcv FROM {database_name}.{p_input_database_table}  where batch_run_dt >= '{start_date}' AND batch_run_dt <'{end_date}' """.format(database_name=database_name,p_input_database_table=p_input_database_table,start_date=start_date, end_date=end_date)
	query = " ".join(query.split())
	print("query data completed")

	df = sessn.sql(query)
	print("query data 2 completed")
	global pls_lookup_list
	print("global  completed")
	pls_lookup_list = ["0" + str(i) for i in range(1, 10)] + [str(i) for i in range(1,100)]
	print("pls_lookup  completed")
	df1 = df.withColumn("valid_pls", place_of_srcv_validator("cl_place_of_srcv"))
	print("df1 with col completed")
	df1 = df1.filter(df1["valid_pls"] == 1)
	print("df1 filter  completed")
	df1 = df1.withColumn("cl_place_of_srcv", F.lpad(df1["cl_place_of_srcv"], 2, '0'))
	print("df1 with col 2  completed")
	
	lookback_data(df, "servicing_npi", "cl_proc_cd")
	print("Lookback table 1 created")
	lookback_data(df1, "servicing_npi", "cl_place_of_srcv")
	print("Lookback table 2 created")
	
	module_id=str(mid[1])
	r = requests.post(tracking_url, json=parameters(module_id,status[1],""))
	
	################### ----->Distribution creation started

	module_id=str(mid[2])
	r = requests.post(tracking_url, json=parameters(module_id,status[0],""))
	
	print("Distribution creation started")
	modelling_data = sessn.read.table(database_name_temp + "." +modelling_table)
	#modelling_data = sessn.read.parquet("/datalake/uhc/ei/pi_ara/sherlock/datasource/hive/pi_stg/ps_modelling_data")
	
	# Generating list Good NPIs (Having more than 10 Claims in Modelling data)
	npi_clm_cnt = modelling_data.groupby("servicing_npi").count()
	good_npi_clm = npi_clm_cnt.filter(F.col("count")>=clm_th)
	good_npi = good_npi_clm.select("servicing_npi")
	scorable_npi_count = good_npi.count()
	# data_to_work_modelling -> Consist modelling data for scorable NPIs
	data_to_work_modelling = modelling_data.join(good_npi, on ="servicing_npi", how ="inner")

	scnt = len(signal_list)
	signal_comb = list(it.product(signal_list, repeat =2 ))

	covarince_op = data_to_work_modelling.groupby("servicing_npi").agg(*[F.covar_samp(f[0],f[1]) for f in signal_comb])
	mean_op = data_to_work_modelling.groupBy("servicing_npi").agg(*[F.mean(f) for f in signal_list])

	covarince_op_pd = covarince_op.toPandas()

	covar_dump = covarince_op_pd.values[:,1:]
	covar_dump = covar_dump.reshape(scorable_npi_count, scnt, scnt)
	col_list = list(covarince_op_pd.columns[1:])

	# Computing Pseudo Inverse of covariance matrix
	final_list = []

	for npi in range(scorable_npi_count):
		temp_icov=np.linalg.pinv((covar_dump[npi]).astype(float))
		temp_icov=temp_icov.flatten().tolist()
		final_list.append(temp_icov)

	icovariance_op_pd = pd.DataFrame(final_list, columns = col_list)
	icovariance_op_pd['servicing_npi'] = covarince_op_pd['servicing_npi']
	icovariance_op_pd = icovariance_op_pd[list(covarince_op_pd)]

	icovariance_op = sessn.createDataFrame(icovariance_op_pd)

	for s in signal_list:
		s_col_ = "avg({})".format(s)
		s_col_op = "avg_{}".format(s)
		mean_op = mean_op.withColumnRenamed(s_col_, s_col_op)


	for s_c in signal_comb:
		s_col_ = "covar_samp({}, {})".format(s_c[0], s_c[1])
		s_col_op = "covar_samp_{}_{}".format(s_c[0], s_c[1])
		icovariance_op = icovariance_op.withColumnRenamed(s_col_, s_col_op)
	
	mean_op.write.mode("overwrite").format("orc").saveAsTable(database_name + "." +mean_table)
	print("mean table Created")
	icovariance_op.write.mode("overwrite").format("orc").saveAsTable(database_name + "." +icov_table)
	print("icov table Created")

	print("#######################  Total time taken  #######################")
	
	end = datetime.now().replace(microsecond=0)
	print(end-start)
	
	print("PS Monthly Process completed")

    	print("time taken by process----------------->"),(end-start)
    	r = requests.post(tracking_url, json=parameters(module_id,status[1],""))
    	print(r.text)
except:
    	error = sys.exc_info()[0]
    	print(sys.exc_info()[0], 'occured.')
    	r = requests.post(tracking_url, json=parameters(module_id,status[2],str(error)))
    	print(r.text)

exit()

