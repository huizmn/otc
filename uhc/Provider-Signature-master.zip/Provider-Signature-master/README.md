<h1><i>Provider Signature Monitoring Program</i></h1>

Provider Signature (PS) is a short and long-term change detection model at the provider (NPI) level, designed for real-time processing of pre-adjudicated claims on the Sherlock platform.  The objective is to check if a new claim coming in deviates a lot from what we have in history for that provider. The data from fresh batch is transformed at NPI level (rendering NPI if it's available, else billing NPI). It is then compared with historical claims for that NPI from the historical data that we have stored. The historical data for any NPI has a time constraint of a year and a volume constraint of minimum 10 claims and based on Mahalanobis score threshold decided, the claim will be flagged as a lead.

<h3>Solution Design </h3>

![Solution Design](solution_design.JPG)

***Defining the normal historical behavior***
- Historical data for is fetched for the providers that are to be monitored ( typically 12 months )
- A control analysis is performed for each one the providers to define his/her normal behavior  -   The claims with any of the features being at the extreme side are excluded to ensure that we don’t define extreme behavior to be normal

***Scoring the incoming claim***

A score is computed for each of the incoming claim for these providers . This score is a reflective of how much deviation is this claim showing, basis all the features, compared to the normal behavior of the provider
A cutoff score is identified to indicate that any claim having a higher score is deviating enough to cause suspicion and all such claims are flagged

***Scoring the Provider***

All the flagged claims are aggregated at a provider level to compute a provider risk score which is driven by frequency and severity of flagged claims

<h3>Features</h3>

- Claim Billed Amount 
- Total Units Billed for claim
- Number of lines in claim
- Fraction of claim lines having high cost JCodes
- If a high level E&M code used on claim
- If modifier ‘59’ used on a claim 
- If modifier ‘91’ used on a claim 
- If modifier ‘TC’ used on a claim 
- Was there an emergency indicator on the claim that was performed at ‘Emergency’ place of service
- Unusual Procedure code on claim 
- Unusual Place of Service on claim

<h3>Engineering Flow</h3>
The lifecycle of PS consists of sequential data-science modules that are intended to ship as part of independent intelligent applications. Exploratory analysis and ad hoc analytics are also part of this application.<br>
The lifecycle for PS outlines the major stages that a data science projects typically execute, often iteratively:

<h4>Modelling (Distribution Creation):</h4>
	
	• Business Understanding
	• Data Acquisition and Understanding.
	• Data Wrangling and Preprocessing.
	• Lookback Data Generation for scoring data.
	• Feature Engineering (Smoke signal Creation).
	• Outlier Removal.
	• Distribution Creation.

<h4>Batch Monitoring: </h4>

	• Business Understanding.
	• Data Acquisition and Understanding.
	• Data Wrangling and Preprocessing.
	• Feature Engineering (Smoke signal Creation)
	• Claim scoring with reason code generation.
	• NPI Scoring.
