#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import datetime
from datetime import datetime, timedelta
import time
import re
import copy
import pyspark
import os
import sys
from pyspark.sql import SQLContext, Row, SparkSession
from dateutil.relativedelta import relativedelta
import logging
# from sklearn.preprocessing.data import QuantileTransformer
from pyspark.sql.functions import count, avg,col,min,max,mean,stddev,lit,when,last_day,round,datediff, to_date, lit,abs,pow
from pyspark.sql.functions import rand, isnan, concat,split,size,array_except, array ,trim, log, countDistinct, format_number
from pyspark.sql.types import *

print("Start time :: ")
print(time.ctime())


# In[2]:


os.environ["MAPR_TICKETFILE_LOCATION"]="/home/jsingla/maprticket_jsingla"
try:
    spark.stop()
except Exception as e:
    print(e)                                        


# conf = pyspark.SparkConf().setAll([('spark.executor.memory', '8g'), 
#                                    ('spark.executor.instances', '10'), 
#                                    ('spark.driver.cores','4'), 
#                                    ('spark.executor.cores', '4'), 
#                                    ('spark.yarn.queue', 'araadh_q1.arapi_sq1'),
#                                    ('spark.driver.memory','8g'),
#                                    ('spark.yarn.executor.memoryOverhead','2g')]
#                                  )

conf = pyspark.SparkConf().setAll([('spark.executor.memory', '20g'), 
                                   ('spark.executor.instances', '20'), 
                                   ('spark.driver.cores','4'), 
                                   ('spark.executor.cores', '4'), 
                                   ('spark.yarn.queue', 'araadh_q1.arapi_sq1'),
                                   ('spark.driver.memory','12g'),
                                   ('spark.yarn.executor.memoryOverhead','4096')]
                                 )

spark = SparkSession.builder.appName("Insights").config(conf=conf).enableHiveSupport().getOrCreate().newSession()


print ("done")


# In[3]:


# threshold on total claim count of TIN is past 12 months
thresh_total_claims =30

# sigma multiplier factor for claims threshold ( 3 sigma)
thresh_factor_claims =3

# sigma multiplier factor for billed threshold ( 3 sigma)
thresh_factor_billed =3

# Threshold for Claims Insight, Physicians 
thresh_claims_p =10 

# Threshold for Claims Insight, Facility 
thresh_claims_i =15

# Threshold for Billed Insight, Physician (in $)
thresh_billed_p =150

# Threshold for Billed Insight, Facility (in $)
thresh_billed_i =1500


# In[4]:


# fetching the current date-1 
date_ =datetime.today()
previous_date =date_ -timedelta(days =1)
filter_date =str(previous_date.year)+str(previous_date.month).zfill(2)+str(previous_date.day).zfill(2)


# In[5]:


last_updated =spark.sql(''' select max(last_updated_date) from pi_usrs.837_npi_last_12_months_claims_agg_v2''').first()[0]


# ### Monthly Refresh Table
# 
# ### 837 Data preparation

# In[6]:


if date_.day >= 2 and date_.month != last_updated.month:
    
    # rolling data at NPI, prov_type and date level
    npi_last12_months_claims_all= spark.sql(
        ''' select clm_bill_prov_npi, 
            prov_type,
            batch_run_dt,
            count(distinct invn_ctl_nbr) as claim_count
            from pi_usrs.837_tin_last12_months_claims_all
            group by 
            clm_bill_prov_npi,prov_type, batch_run_dt''')

    npi_last12_months_claims_all.createOrReplaceTempView('npi_last12_months_claims_all')

    
    ## Aggregating at NPI level and calculating averages and std. deviation of claims and billed per claim

    # For  Claims aggregation, using data at Date level (npi_last12_months_claims_all)
    # For Billed per claim aggregation, using data at Claim level (pi_usrs.837_tin_last12_months_claims_all)
    npi_last_12_months_claims_agg= spark.sql(
        ''' select a.clm_bill_prov_npi,
            a.prov_type,
            b.avg_claims,
            b.total_claims,
            b.std_dev_claims,
            a.billed_per_claim,
            a.std_billed_per_claim
            from
            (select clm_bill_prov_npi,
            prov_type,
            avg(total_billed) as billed_per_claim,
            stddev(total_billed) as std_billed_per_claim
            from 
            pi_usrs.837_tin_last12_months_claims_all   
            group by clm_bill_prov_npi,prov_type) a
            inner join 
            (select clm_bill_prov_npi,
            prov_type,
            avg(claim_count) as avg_claims,
            sum(claim_count) as total_claims,
            stddev(claim_count) as std_dev_claims
            from npi_last12_months_claims_all
            group by clm_bill_prov_npi,prov_type) b
            on 
            a.clm_bill_prov_npi =b.clm_bill_prov_npi
            and a.prov_type =b.prov_type''')

    npi_last_12_months_claims_agg.createOrReplaceTempView('npi_last_12_months_claims_agg')
    

    # Calculating Control Limits at NPI level      
    spark.sql('''drop table if exists pi_usrs.837_npi_last_12_months_claims_agg_v2''')

    spark.sql(
    '''create table pi_usrs.837_npi_last_12_months_claims_agg_v2 
        as select clm_bill_prov_npi,
        prov_type, 
        round(avg_claims,2) as avg_claims, 
        total_claims,
        round(std_dev_claims,2) as std_dev_claims,
        round((if(cast(std_dev_claims as int)>0,(avg_claims+({}*std_dev_claims)),avg_claims)),2) as claims_threshold,
        round(billed_per_claim,2) as billed_per_claim,
        round(std_billed_per_claim,2) as std_billed_per_claim,
        round((if(cast(std_billed_per_claim as int)>0,(billed_per_claim +({}*std_billed_per_claim)),billed_per_claim)),2) as billed_threshold,
        current_date as last_updated_date
        from 
        npi_last_12_months_claims_agg
        where total_claims >={}'''.format(thresh_factor_claims,thresh_factor_billed, thresh_total_claims))


# ## Preparing 837 Daily Feed Data (Rule 1 and Rule 2) 
# #### Data pulled @ NPI and Claim level

# In[7]:


# aggregating data at NPI level
spark.sql('''drop table if exists pi_usrs.837_npi_data_daily_all_v2''')

spark.sql(
    '''create table pi_usrs.837_npi_data_daily_all_v2 as 
        select clm_bill_prov_npi,
        prov_type,
        batch_run_dt,
        count(distinct invn_ctl_nbr)as claim_count,
        round(avg(total_billed),2) as billed_per_claim
        from pi_usrs.837_tin_data_daily_all
        group by clm_bill_prov_npi,prov_type,batch_run_dt''')


# ### Generating Claims Insights

# In[8]:


# All the NPIs for which threshold is exceeded

npi_insights_claims_daily =spark.sql(
    '''select
    a.clm_bill_prov_npi,
    a.prov_type,
    a.batch_run_dt,
    a.claim_count,
    round(b.avg_claims,2) as avg_claims,
    b.claims_threshold,
    b.total_claims,
    "1" as rule_id
    from 
    pi_usrs.837_npi_data_daily_all_v2 a
    inner join 
    pi_usrs.837_npi_last_12_months_claims_agg_v2  b
    on a.clm_bill_prov_npi =b.clm_bill_prov_npi
    and a.prov_type =b.prov_type
    where a.claim_count > b.claims_threshold''')

npi_insights_claims_daily.createOrReplaceTempView('npi_insights_claims_daily')


# ##### Generating Insights for Physicians

# In[9]:


# Generating Physicians Insights
npi_insights_claims_837p = spark.sql(
    '''select * from
        npi_insights_claims_daily
        where prov_type ="P"
        and claim_count >={}'''.format(thresh_claims_p))


# In[10]:


npi_insights_claims_837p = npi_insights_claims_837p.withColumn("Insight",concat(lit("The Provider as Physician filed <span class='badge badge-danger'>"),format_number("claim_count",0),lit("</span> claims, exceeding the Upper Control Limit of <span class='badge badge-info'>"),format_number("claims_threshold",0),lit("</span> (three standard deviation above the mean of <span class='badge badge-info'>"),format_number("avg_claims",0),lit("</span>) calculated over past 12 months' data.")))


# In[11]:


npi_insights_claims_837p_repo =npi_insights_claims_837p.select("clm_bill_prov_npi","prov_type","batch_run_dt","rule_id","insight")


# #### Generating Insights for Facility

# In[12]:


# Generating Facility Insights
npi_insights_claims_837i =spark.sql(
    '''select * from 
    npi_insights_claims_daily
    where prov_type ="I"  and 
    claim_count>={}'''.format(thresh_claims_i))


# In[13]:


npi_insights_claims_837i = npi_insights_claims_837i.withColumn("Insight",concat(lit("The Provider as Facility filed <span class='badge badge-danger'>"),format_number("claim_count",0),lit("</span> claims, exceeding the Upper Control Limit of <span class='badge badge-info'>"),format_number("claims_threshold",0),lit("</span> (three standard deviation above the mean of <span class='badge badge-info'>"),format_number("avg_claims",0),lit("</span>) calculated over past 12 months' data.")))


# In[14]:


npi_insights_claims_837i_repo =npi_insights_claims_837i.select("clm_bill_prov_npi","prov_type","batch_run_dt","rule_id","insight")


# In[15]:


npi_insights_claims_837_repo_comb =npi_insights_claims_837p_repo.union(npi_insights_claims_837i_repo)


# In[16]:


npi_insights_claims_837_repo_comb.write.mode("append").saveAsTable("pi_usrs.npi_insights_repo_final")


# ## Generating Billed Per Claim Insights

# In[17]:


# All the NPIs for which threshold is exceeded

npi_insights_billed_daily =spark.sql(
    ''' select
        a.clm_bill_prov_npi,
        a.prov_type,
        a.batch_run_dt,
        b.billed_per_claim as overall_billed_per_claim,
        b.billed_threshold,
        "2" as rule_id,
         count(a.invn_ctl_nbr) as claim_count
        from
        pi_usrs.837_tin_data_daily_all a
        inner join 
        pi_usrs.837_npi_last_12_months_claims_agg_v2  b
        on a.clm_bill_prov_npi =b.clm_bill_prov_npi
        and a.prov_type =b.prov_type
        where a.total_billed > b.billed_threshold
        group by
        a.clm_bill_prov_npi,
        a.prov_type,
        a.batch_run_dt,
        b.billed_threshold,
        b.billed_per_claim''')

npi_insights_billed_daily.createOrReplaceTempView('npi_insights_billed_daily')


# #### Generating Physician Insights

# In[18]:


npi_insights_billed_837p =spark.sql(
    '''select * from 
    npi_insights_billed_daily
    where prov_type ="P" 
    and billed_threshold >={} '''.format(thresh_billed_p))


# In[19]:


npi_insights_billed_837p = npi_insights_billed_837p.withColumn("Insight",concat(lit("The Provider as Physician billed <span class='badge badge-danger'>"),format_number("claim_count",0),lit("</span> claim(s) where billed amount exceeded the Upper Control Limit of <span class='badge badge-info'>"),format_number("billed_threshold",0),lit("</span> (three standard deviation above the mean of <span class='badge badge-info'>$"),format_number("overall_billed_per_claim",0),lit("</span> per claim) calculated over past 12 months' data.")))


# In[20]:


npi_insights_billed_837p_repo =npi_insights_billed_837p.select("clm_bill_prov_npi","prov_type","batch_run_dt","rule_id","insight")


# #### Generating Billed per Claim Facility Insights

# In[21]:


npi_insights_billed_837i =spark.sql(
    '''select * from 
    npi_insights_billed_daily
    where prov_type ="I" 
    and billed_threshold >={} '''.format(thresh_billed_i))


# In[22]:


npi_insights_billed_837i = npi_insights_billed_837i.withColumn("Insight",concat(lit("The Provider as Facility billed <span class='badge badge-danger'>"),format_number("claim_count",0),lit("</span> claim(s) where billed amount exceeded the Upper Control Limit of <span class='badge badge-info'>"),format_number("billed_threshold",0),lit("</span> (three standard deviation above the mean of <span class='badge badge-info'>$"),format_number("overall_billed_per_claim",0),lit("</span> per claim) calculated over past 12 months' data.")))


# In[23]:


npi_insights_billed_837i_repo =npi_insights_billed_837i.select("clm_bill_prov_npi","prov_type","batch_run_dt","rule_id","insight")


# In[24]:


npi_insights_billed_837_repo_comb =npi_insights_billed_837p_repo.union(npi_insights_billed_837i_repo)


# In[25]:


npi_insights_billed_837_repo_comb.write.mode("append").saveAsTable("pi_usrs.npi_insights_repo_final")

