package com.uhg.sna.triage.function;

import org.apache.spark.api.java.function.Function;

import com.uhg.sna.triage.dto.ProviderResultDto;

public class FilterTopRecords implements Function<ProviderResultDto, Boolean> {

	private static final long serialVersionUID = 167548969L;

	@Override
	public Boolean call(ProviderResultDto v1) throws Exception {
		return Boolean.parseBoolean(v1.getTopFlag());
	}
}
