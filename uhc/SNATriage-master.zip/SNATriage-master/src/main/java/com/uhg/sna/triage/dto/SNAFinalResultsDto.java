package com.uhg.sna.triage.dto;

import java.io.Serializable;

public class SNAFinalResultsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2352352342345L;
	/**
	 * 
	 */

	private String providerId;
	private String SNA_ServiceNPI;
	private String SNAReasonCode;
	private String SNAReasonDesc;
	private String SNAAddrLine1;
	private String SNACityName;
	private String SNAZipCd;
	private String SNAStateCd;
	private String SNATaxanomyCode;
	private String SNAPhNo;
	private String SNAFName;
	private String SNAMName;
	private String SNALname;
	private String SNAThreshold;
	private String SNAOdarFlag;
	private String SNASanctionFlag;
	private String SNADeathMasterFlag;
	private String SNATrueFraudScoreEI;
	private String SNATrueFraudScoreCS;
	private String SNATrueFraudScoreMR;
	private String SNAWebCrawlerFlag;
	private String SNASpeciality;
	private String SNAProviderName;
	private String SNAFinalRecommendedFlag;
	private String SNACommViewLink;
	private String CompositeScore;
	private String SNABillingProvNPI;
	private String SNANeighborsOdar1DScore;
	private String SNANeighborsFraud1DScore;
	private String SNAPrimNeighIndicator;
	private String SNAclusterindex;
	private String SNAprvleadid;
	/*private String SNAIntelCenterIndic;
	private String SNALeadIndic;
	*/
	public SNAFinalResultsDto(String providerId, String sNA_ServiceNPI, String sNAReasonCode, String sNAReasonDesc,
			String sNAAddrLine1, String sNACityName, String sNAZipCd, String sNAStateCd, String sNATaxanomyCode,
			String sNAPhNo, String sNAFName, String sNAMName, String sNALname, String sNAThreshold, String sNAOdarFlag,
			String sNASanctionFlag, String sNADeathMasterFlag, String sNATrueFraudScoreEI, String sNATrueFraudScoreCS,
			String sNATrueFraudScoreMR, String sNAWebCrawlerFlag, String sNASpeciality, String sNAProviderName,
			String sNAFinalRecommendedFlag, String sNACommViewLink, String compositeScore, String sNABillingProvNPI,
			String sNANeighborsOdar1DScore, String sNAneighborsFraud1DScore, String sNAPrimNeighIndicator, String sNAclusterindex,
			String sNAprvleadid) {
		super();
		this.providerId = providerId;
		SNA_ServiceNPI = sNA_ServiceNPI;
		SNAReasonCode = sNAReasonCode;
		SNAReasonDesc = sNAReasonDesc;
		SNAAddrLine1 = sNAAddrLine1;
		SNACityName = sNACityName;
		SNAZipCd = sNAZipCd;
		SNAStateCd = sNAStateCd;
		SNATaxanomyCode = sNATaxanomyCode;
		SNAPhNo = sNAPhNo;
		SNAFName = sNAFName;
		SNAMName = sNAMName;
		SNALname = sNALname;
		SNAThreshold = sNAThreshold;
		SNAOdarFlag = sNAOdarFlag;
		SNASanctionFlag = sNASanctionFlag;
		SNADeathMasterFlag = sNADeathMasterFlag;
		SNATrueFraudScoreEI = sNATrueFraudScoreEI;
		SNATrueFraudScoreCS = sNATrueFraudScoreCS;
		SNATrueFraudScoreMR = sNATrueFraudScoreMR;
		SNAWebCrawlerFlag = sNAWebCrawlerFlag;
		SNASpeciality = sNASpeciality;
		SNAProviderName = sNAProviderName;
		SNAFinalRecommendedFlag = sNAFinalRecommendedFlag;
		SNACommViewLink = sNACommViewLink;
		CompositeScore = compositeScore;
		SNABillingProvNPI = sNABillingProvNPI;
		SNANeighborsOdar1DScore = sNANeighborsOdar1DScore;
		SNANeighborsFraud1DScore = sNAneighborsFraud1DScore;
		SNAPrimNeighIndicator = sNAPrimNeighIndicator;
		SNAclusterindex = sNAclusterindex;
		SNAprvleadid =sNAprvleadid;
		/*SNAIntelCenterIndic = sNAIntelCenterIndic;
		SNALeadIndic = sNALeadIndic;*/
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getSNABillingProvNPI() {
		return SNABillingProvNPI;
	}

	public String getSNANeighborsOdar1DScore() {
		return SNANeighborsOdar1DScore;
	}

	public String getSNANeighborsFraud1DScore() {
		return SNANeighborsFraud1DScore;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getSNA_ServiceNPI() {
		return SNA_ServiceNPI;
	}

	public void setSNA_ServiceNPI(String sNA_ServiceNPI) {
		SNA_ServiceNPI = sNA_ServiceNPI;
	}

	public String getSNAReasonCode() {
		return SNAReasonCode;
	}

	public void setSNAReasonCode(String sNAReasonCode) {
		SNAReasonCode = sNAReasonCode;
	}

	public String getSNAReasonDesc() {
		return SNAReasonDesc;
	}

	public void setSNAReasonDesc(String sNAReasonDesc) {
		SNAReasonDesc = sNAReasonDesc;
	}

	public String getSNAAddrLine1() {
		return SNAAddrLine1;
	}

	public void setSNAAddrLine1(String sNAAddrLine1) {
		SNAAddrLine1 = sNAAddrLine1;
	}

	public String getSNACityName() {
		return SNACityName;
	}

	public void setSNACityName(String sNACityName) {
		SNACityName = sNACityName;
	}

	public String getSNAZipCd() {
		return SNAZipCd;
	}

	public void setSNAZipCd(String sNAZipCd) {
		SNAZipCd = sNAZipCd;
	}

	public String getSNAStateCd() {
		return SNAStateCd;
	}

	public void setSNAStateCd(String sNAStateCd) {
		SNAStateCd = sNAStateCd;
	}

	public String getSNATaxanomyCode() {
		return SNATaxanomyCode;
	}

	public void setSNATaxanomyCode(String sNATaxanomyCode) {
		SNATaxanomyCode = sNATaxanomyCode;
	}

	public String getSNAPhNo() {
		return SNAPhNo;
	}

	public void setSNAPhNo(String sNAPhNo) {
		SNAPhNo = sNAPhNo;
	}

	public String getSNAFName() {
		return SNAFName;
	}

	public void setSNAFName(String sNAFName) {
		SNAFName = sNAFName;
	}

	public String getSNAMName() {
		return SNAMName;
	}

	public void setSNAMName(String sNAMName) {
		SNAMName = sNAMName;
	}

	public String getSNALname() {
		return SNALname;
	}

	public void setSNALname(String sNALname) {
		SNALname = sNALname;
	}

	public String getSNAThreshold() {
		return SNAThreshold;
	}

	public void setSNAThreshold(String sNAThreshold) {
		SNAThreshold = sNAThreshold;
	}

	public String getSNAOdarFlag() {
		return SNAOdarFlag;
	}

	public void setSNAOdarFlag(String sNAOdarFlag) {
		SNAOdarFlag = sNAOdarFlag;
	}

	public String getSNASanctionFlag() {
		return SNASanctionFlag;
	}

	public void setSNASanctionFlag(String sNASanctionFlag) {
		SNASanctionFlag = sNASanctionFlag;
	}

	public String getSNADeathMasterFlag() {
		return SNADeathMasterFlag;
	}

	public void setSNADeathMasterFlag(String sNADeathMasterFlag) {
		SNADeathMasterFlag = sNADeathMasterFlag;
	}

	public String getSNATrueFraudScoreEI() {
		return SNATrueFraudScoreEI;
	}

	public void setSNATrueFraudScoreEI(String sNATrueFraudScoreEI) {
		SNATrueFraudScoreEI = sNATrueFraudScoreEI;
	}

	public String getSNATrueFraudScoreCS() {
		return SNATrueFraudScoreCS;
	}

	public void setSNATrueFraudScoreCS(String sNATrueFraudScoreCS) {
		SNATrueFraudScoreCS = sNATrueFraudScoreCS;
	}

	public String getSNATrueFraudScoreMR() {
		return SNATrueFraudScoreMR;
	}

	public void setSNATrueFraudScoreMR(String sNATrueFraudScoreMR) {
		SNATrueFraudScoreMR = sNATrueFraudScoreMR;
	}

	public String getSNAWebCrawlerFlag() {
		return SNAWebCrawlerFlag;
	}

	public void setSNAWebCrawlerFlag(String sNAWebCrawlerFlag) {
		SNAWebCrawlerFlag = sNAWebCrawlerFlag;
	}

	public String getSNASpeciality() {
		return SNASpeciality;
	}

	public void setSNASpeciality(String sNASpeciality) {
		SNASpeciality = sNASpeciality;
	}

	public String getSNAProviderName() {
		return SNAProviderName;
	}

	public void setSNAProviderName(String sNAProviderName) {
		SNAProviderName = sNAProviderName;
	}

	public String getSNAFinalRecommendedFlag() {
		return SNAFinalRecommendedFlag;
	}

	public void setSNAFinalRecommendedFlag(String sNAFinalRecommendedFlag) {
		SNAFinalRecommendedFlag = sNAFinalRecommendedFlag;
	}

	public String getSNACommViewLink() {
		return SNACommViewLink;
	}

	public void setSNACommViewLink(String sNACommViewLink) {
		SNACommViewLink = sNACommViewLink;
	}

	public String getCompositeScore() {
		return CompositeScore;
	}

	public void setCompositeScore(String compositeScore) {
		CompositeScore = compositeScore;
	}
	
	public String getSNAPrimNeighIndicator() {
		return SNAPrimNeighIndicator;
	}

	public void setSNAPrimNeighIndicator(String sNAPrimNeighIndicator) {
		SNAPrimNeighIndicator = sNAPrimNeighIndicator;
	}

	public String getSNAclusterindex() {
		return SNAclusterindex;
	}

	public void setSNAclusterindex(String sNAclusterindex) {
		SNAclusterindex = sNAclusterindex;
	}

	public String getSNAprvleadid() {
		return SNAprvleadid;
	}

	public void setSNAprvleadid(String sNAprvleadid) {
		SNAprvleadid = sNAprvleadid;
	}

	/*public String getSNAIntelCenterIndic() {
		return SNAIntelCenterIndic;
	}

	public void setSNAIntelCenterIndic(String sNAIntelCenterIndic) {
		SNAIntelCenterIndic = sNAIntelCenterIndic;
	}

	public String getSNALeadIndic() {
		return SNALeadIndic;
	}

	public void setSNALeadIndic(String sNALeadIndic) {
		SNALeadIndic = sNALeadIndic;
	}*/
	

}
