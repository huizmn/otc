package com.uhg.sna.triage.function;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.FlatMapFunction;

import com.uhg.sna.triage.dto.ProviderResultDto;

public class ReadFileToProvDto implements FlatMapFunction<String, ProviderResultDto> {

	private String inputPath;
	private String delim;
	private String batchId;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getDelim() {
		return delim;
	}

	public void setDelim(String delim) {
		this.delim = delim;
	}

	public ReadFileToProvDto(String inputPath,String delim,String tmpBatchId) {
		super();
		this.inputPath = inputPath;
		this.delim = delim;
	}

	private static final long serialVersionUID = 1609884382893040769L;

	@Override
	public Iterator<ProviderResultDto> call(String batchId) throws Exception {

		FileSystem fs = FileSystem.get(new Configuration());

		ArrayList<ProviderResultDto> providerResultList = new ArrayList<ProviderResultDto>();

		FSDataInputStream inputStream = null;
		BufferedReader br = null;
		try {
			inputStream = fs.open(new Path(inputPath));
			br = new BufferedReader(new InputStreamReader(inputStream));
			String line=null;
			String[] split_line;

			while ((line = br.readLine()) != null) {
				split_line = line.split(delim);
				providerResultList.add(new ProviderResultDto(batchId,split_line[0],split_line[1],split_line[2],split_line[3]));
			}
		} finally {
			if (inputStream != null)
				inputStream.close();
			if (br != null)
				br.close();

		}

		return providerResultList.iterator();

	}

}
