package com.uhg.sna.triage.function;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;

import com.uhg.sna.triage.dto.SNAFinalResultsDto;
import com.uhg.sna.triage.util.SNATriageConfiguration;
import com.uhg.sna.triage.util.TriageKeys;

public class CreateFinalResultantFn implements Function<Row, SNAFinalResultsDto> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public CreateFinalResultantFn(SNATriageConfiguration snaConfig) {
		super();
		this.snaConfig=snaConfig;
		// TODO Auto-generated constructor stub
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private SNATriageConfiguration snaConfig;

	public SNATriageConfiguration getSnaConfig() {
		return snaConfig;
	}


	public SNAFinalResultsDto call(Row row) throws Exception {
		// TODO Auto-generated method stub
		
		 String fname=row.<String>getAs("SNAFName");
		 String mname=row.<String>getAs("SNAMName");
		 String lname=row.<String>getAs("SNALname");
		SNAFinalResultsDto dto = new 
				 SNAFinalResultsDto(row.<String>getAs("providerid"),
						 row.<String>getAs("SNAProviderid"),
						 row.<String>getAs("SNAReasonCode"),
						 row.<String>getAs("SNAReasonDesc"),
						 row.<String>getAs("SNAAddrLine1"),
						 row.<String>getAs("SNACityName"),
						 row.<String>getAs("SNAZipCd"),
						 row.<String>getAs("SNAStateCd"),
						 row.<String>getAs("SNATaxanomyCode"),
						 row.<String>getAs("SNAPhNo"),
						 fname,
						 mname,
						 lname,
						 row.<String>getAs("SNAThreshold"),
						 row.<String>getAs("SNAOdarFlag"),
						 row.<String>getAs("SNASanctionFlag"),
						 row.<String>getAs("SNADeathMasterFlag"),
						 row.<String>getAs("SNATrueFraudScoreEI"),
						 row.<String>getAs("SNATrueFraudScoreCS"),
						 row.<String>getAs("SNATrueFraudScoreMR"),
						 row.<String>getAs("SNAWebCrawlerFlag"),
						 row.<String>getAs("SNASpeciality"),
						 
						 fname+" "+mname+" "+lname,
						 row.<String>getAs("topFlag"),
						 getSnaConfig().get(TriageKeys.TRIAGE_DOCKER_URL)+row.<String>getAs("providerid"),
						 row.<String>getAs("suspicionScore"),
						 row.<String>getAs("SNABillingProviderNPI"),
						 row.<String>getAs("neighborsOdar1DScore"),
						 row.<String>getAs("neighborsFraud1DScore"),
						 row.<String>getAs("primaryneighbourflag"),
						 row.<String>getAs("clusterIndex"),
						 row.<String>getAs("SNAProviderid")
						 );
		return dto;
	}

}
