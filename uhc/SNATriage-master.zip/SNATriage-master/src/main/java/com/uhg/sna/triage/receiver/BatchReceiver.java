/**
 * 
 */
package com.uhg.sna.triage.receiver;

import org.apache.log4j.Logger;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.receiver.Receiver;
import com.uhc.sherlock.snaJobConnector.dbops.SNAJobProcessState;

/**
 * @author vamdiyal
 * 
 */
public class BatchReceiver extends Receiver<String> {

	private long BatchFrequency;
	static Logger logger = Logger.getLogger("file");
	public BatchReceiver(long batchFrequency2) {
		super(StorageLevel.MEMORY_AND_DISK_2());
		BatchFrequency = batchFrequency2;
	}

	private static final long serialVersionUID = -915684744218706633L;

	@Override
	public void onStart() {
		// Start the thread that receives batchId from the batch connector
		// library.
		new Thread() {
			@Override
			public void run() {
				receive();
			}
		}.start();

	}

	@Override
	public void onStop() {

	}

	private void receive() {

		try {
			while (!isStopped()) {
				Thread.sleep(this.BatchFrequency);
				String jobid = SNAJobProcessState.getSnaTriageJobId().trim();
				logger.info("Job Id "+jobid);
				if (!("".equalsIgnoreCase(jobid))) {
					store(jobid);
				}
				
			}
		} catch (Exception e) {
			restart("Error receiving data", e);
		}

	}
}
