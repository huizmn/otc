package com.uhg.sna.triage.function;

import java.io.Serializable;
import java.util.Comparator;

import com.uhg.sna.triage.dto.ProviderResultDto;

public class ProviderResultComparator implements Comparator<ProviderResultDto>,
		Serializable {

	private static final long serialVersionUID = 713671253712705789L;

	public int compare(ProviderResultDto o1, ProviderResultDto o2) {

		// Descending order
		return Integer.parseInt(o2.getNeighbourHoodScore())
				- Integer.parseInt(o1.getNeighbourHoodScore());
	}

}
