package com.uhg.sna.triage.function;

import org.apache.spark.api.java.function.Function;

import com.uhg.sna.triage.dto.SNAFinalResultsDto;

public class FilterRecommendedRecords implements Function<SNAFinalResultsDto, Boolean> {

	private static final long serialVersionUID = 167548969L;

	@Override
	public Boolean call(SNAFinalResultsDto v1) throws Exception {
		boolean returnVal = false;
		if (v1.getSNAFinalRecommendedFlag().trim().equalsIgnoreCase("true")) {
			returnVal = true;
		}
		return returnVal;
	}
}
