/**
 * 
 */
package com.uhg.sna.triage.function;

import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.spark.api.java.function.PairFunction;

import com.mapr.org.apache.hadoop.hbase.util.Bytes;
import com.uhg.sna.triage.dto.SNAFinalResultsDto;
import com.uhg.sna.triage.util.SNATriageConfiguration;
import com.uhg.sna.triage.dto.GenericDTO;
import com.uhg.sna.triage.util.TriageKeys;

import scala.Tuple2;

/**
 * @author vamdiyal
 * 
 */
public class HbaseMapToPairFn implements PairFunction<SNAFinalResultsDto, ImmutableBytesWritable, Put> {

	public HbaseMapToPairFn(int threshold, String batchId,SNATriageConfiguration snaConfig) {
		super();
		this.threshold = threshold;
		this.batchId = batchId;
		this.snaConfig=snaConfig;
	}

	private SNATriageConfiguration snaConfig;

	public SNATriageConfiguration getSnaConfig() {
		return snaConfig;
	}
	private int threshold;
	private String batchId;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	public HbaseMapToPairFn() {
		super();

	}

	private static final long serialVersionUID = -3108267573373010933L;

	public String PriNeighFlag;
	


	public Tuple2<ImmutableBytesWritable, Put> call(SNAFinalResultsDto snaProviderResultDto) throws Exception {

		String cFamily =getSnaConfig().get(TriageKeys.TRIAGE_RESULTS_COL_FAMILY);
	/*	GenericDTO GD = new GenericDTO();*/
		
		//Logic for appending N or P with prov_lead_id as per PrimaryNeighbourIndicator value
		if(snaProviderResultDto.getSNAPrimNeighIndicator().trim().equalsIgnoreCase("Primary")){
			
			PriNeighFlag = "P";	
		}
		else{
			PriNeighFlag = "N";			
		}
		
		Put put = new Put(Bytes.toBytes(getBatchId() + getSnaConfig().get(TriageKeys.TRIAGE_KEY_IDENTIFIER )+ snaProviderResultDto.getSNABillingProvNPI()+PriNeighFlag));
	
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAProviderId"),Bytes.toBytes(snaProviderResultDto.getProviderId()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAServiceNPI"),Bytes.toBytes(snaProviderResultDto.getSNA_ServiceNPI()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAReasonCode"),Bytes.toBytes(snaProviderResultDto.getSNAReasonCode()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAReasonDesc"),Bytes.toBytes(snaProviderResultDto.getSNAReasonDesc()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAAddrLine1"),Bytes.toBytes(snaProviderResultDto.getSNAAddrLine1()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNACityName"),Bytes.toBytes(snaProviderResultDto.getSNACityName()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAZipCd"),Bytes.toBytes(snaProviderResultDto.getSNAZipCd()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAStateCd"),Bytes.toBytes(snaProviderResultDto.getSNAStateCd()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNATaxanomyCode"),Bytes.toBytes(snaProviderResultDto.getSNATaxanomyCode()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAPhNo"),Bytes.toBytes(snaProviderResultDto.getSNAPhNo()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAFName"),Bytes.toBytes(snaProviderResultDto.getSNAFName()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAMName"),Bytes.toBytes(snaProviderResultDto.getSNAMName()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNALname"),Bytes.toBytes(snaProviderResultDto.getSNALname()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAThreshold"),Bytes.toBytes(snaProviderResultDto.getSNAThreshold()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAOdarFlag"),Bytes.toBytes(snaProviderResultDto.getSNAOdarFlag()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNASanctionFlag"),Bytes.toBytes(snaProviderResultDto.getSNASanctionFlag()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNADeathMasterFlag"),Bytes.toBytes(snaProviderResultDto.getSNADeathMasterFlag()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNATrueFraudScoreEI"),Bytes.toBytes(snaProviderResultDto.getSNATrueFraudScoreEI()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNATrueFraudScoreCS"),Bytes.toBytes(snaProviderResultDto.getSNATrueFraudScoreCS()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNATrueFraudScoreMR"),Bytes.toBytes(snaProviderResultDto.getSNATrueFraudScoreMR()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAWebCrawlerFlag"),Bytes.toBytes(snaProviderResultDto.getSNAWebCrawlerFlag()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNASpeciality"),Bytes.toBytes(snaProviderResultDto.getSNASpeciality()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAProviderName"),Bytes.toBytes(snaProviderResultDto.getSNAProviderName()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAFinalRecommendedFlag"),Bytes.toBytes(snaProviderResultDto.getSNAFinalRecommendedFlag()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNACommViewLink"),Bytes.toBytes(snaProviderResultDto.getSNACommViewLink()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNACompositeScore"),Bytes.toBytes(snaProviderResultDto.getCompositeScore()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNABillingProvNPI"),Bytes.toBytes(snaProviderResultDto.getSNABillingProvNPI()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNANeighborsOdar1DScore"),Bytes.toBytes(snaProviderResultDto.getSNANeighborsOdar1DScore()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNANeighborsFraud1DScore"),Bytes.toBytes(snaProviderResultDto.getSNANeighborsFraud1DScore()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAPrimNeighIndicator"),Bytes.toBytes(snaProviderResultDto.getSNAPrimNeighIndicator()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAclusterindex"),Bytes.toBytes(snaProviderResultDto.getSNAclusterindex()));
		put.addColumn(Bytes.toBytes(cFamily), Bytes.toBytes("SNAprvleadid"),Bytes.toBytes(snaProviderResultDto.getSNAprvleadid()));


			return new Tuple2<ImmutableBytesWritable, Put>(new ImmutableBytesWritable(Bytes.toBytes(getBatchId() + "SN"+snaProviderResultDto.getSNA_ServiceNPI())), put);
		
			

		
	}

}
