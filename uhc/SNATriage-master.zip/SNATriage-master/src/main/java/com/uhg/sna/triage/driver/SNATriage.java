package com.uhg.sna.triage.driver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.uhc.sherlock.snaJobConnector.dbops.AppConfig;
import com.uhc.sherlock.snaJobConnector.dbops.SNAJobProcessState;
import com.uhg.sna.triage.dto.ProviderResultDto;
import com.uhg.sna.triage.dto.SNAFinalResultsDto;
import com.uhg.sna.triage.function.CreateFinalResultantFn;
import com.uhg.sna.triage.function.FilterRecommendedRecords;
import com.uhg.sna.triage.function.FilterTopRecords;
import com.uhg.sna.triage.function.FlagRecordsFn;
import com.uhg.sna.triage.function.HbaseMapToPairFn;
import com.uhg.sna.triage.function.ReadFileToProvDto;
import com.uhg.sna.triage.function.SortProvidersFn;
import com.uhg.sna.triage.receiver.BatchReceiver;
import com.uhg.sna.triage.util.SNATriageConfiguration;
import com.uhg.sna.triage.util.TriageKeys;

public class SNATriage {
	static Logger logger = Logger.getLogger("file");
	private static final String SPACE = " ";
	private static final String SCP_COMMAND = "/usr/bin/scp";

	static {

	}

	public static void main(String[] args) throws IOException, InterruptedException {

		if (args.length < 1) {
			System.err.println("Missing argument==>Properties File Path");
			System.exit(1);
		}

		final SNATriageConfiguration snaConfig = new SNATriageConfiguration(args[0]);

		PropertyConfigurator.configure(snaConfig.get(TriageKeys.LOGFILE));
		SparkConf sparkConf = new SparkConf();
		final JavaStreamingContext jsct = new JavaStreamingContext(sparkConf,
				new Duration(Long.parseLong(snaConfig.get(TriageKeys.RECEIVER_METHOD_FREQUENCY))));

		try {
			final SparkSession sqlCtx = new org.apache.spark.sql.SparkSession.Builder().enableHiveSupport()
					.getOrCreate();

			// Properties for setting job output table after RDD
			// transformations.
			Configuration config = HBaseConfiguration.create();
			config.set(TableOutputFormat.OUTPUT_TABLE, snaConfig.get(TriageKeys.MAPRDB_PROVIDERRESULT));
			final Job job = Job.getInstance(config);
			job.setOutputFormatClass(TableOutputFormat.class);

			// Received data form the CustomReceiver process as a Dstream of
			// RDDS
			JavaReceiverInputDStream<String> batchDstream = jsct
					.receiverStream(new BatchReceiver(Long.parseLong(snaConfig.get(TriageKeys.RECEIVER_FREQUENCY))));

			batchDstream.print();

			batchDstream.foreachRDD(new VoidFunction<JavaRDD<String>>() {

				private static final long serialVersionUID = -6103807383023365038L;

				public void call(JavaRDD<String> batchRDD) throws Exception {

					try {
						// Check if RDD is not empty in the Dstream and then
						// process.
						String tmpBatchId = "";

						if (!batchRDD.isEmpty()) {

							for (String batchId : batchRDD.collect()) {
								logger.info("Starting to process batch-->" + batchId);
								SNAJobProcessState.snaTriageStarted(batchId);
								tmpBatchId = batchId;
							}

							// copy the file from docker to local edge node

							logger.debug(
									"########################Import Data NH_SCORE FROM DOCKER :: START  ###############");
							runJschCommand(SCP_COMMAND + SPACE + snaConfig.get(TriageKeys.TRIAGE_SCP_LOCATION)
									+ snaConfig.get(TriageKeys.TRAIGE_SCP_FILE_FILENAME) + SPACE
									+ snaConfig.get(TriageKeys.TRIAGE_MAPR_MOUNT)
									+ snaConfig.get(TriageKeys.INPUT_PATH), snaConfig);

							logger.debug(
									"########################Import Data NH_SCORE FROM DOCKER :: END  ###############");
							int threshhold = Integer.parseInt(AppConfig.getSNAThreshhold());
							logger.debug("SNA Thresh hold value " + threshhold);

							JavaRDD<ProviderResultDto> provResultDtoRDD = batchRDD
									.flatMap(new ReadFileToProvDto(snaConfig.get(TriageKeys.INPUT_PATH),
											snaConfig.get(TriageKeys.INPUT_FILE_DELIM), tmpBatchId))
									.sortBy(new SortProvidersFn(), false, 1).zipWithIndex()
									.map(new FlagRecordsFn(threshhold)).cache();

							logger.debug("Creating nhscore results");
							Dataset<Row> nhscoreResults = sqlCtx.createDataFrame(provResultDtoRDD,
									ProviderResultDto.class);

							logger.debug("nhscoreResults" + nhscoreResults.schema());
							nhscoreResults.write().mode(SaveMode.Overwrite).insertInto("sna_dm.nhscoreResults");
							logger.debug("Count nhscoreResults " + nhscoreResults.count());

							// saving extract
							provResultDtoRDD.filter(new FilterTopRecords())
									.saveAsTextFile(snaConfig.get(TriageKeys.TRIAGE_OP));

							logger.debug("First filter npis");
							String suffix = tmpBatchId.substring(1, 9);
							logger.debug("Suffix for table mr provider " + suffix);

							Dataset<Row> firstfltrNPI = sqlCtx
									.sql(snaConfig.get(TriageKeys.FIRST_FLTR_QUERY).replace(":1", suffix));
							firstfltrNPI.write().mode(SaveMode.Overwrite)
									.insertInto(snaConfig.get(TriageKeys.FIRST_FLTR_TBL));

							// firstfltrNPI.createOrReplaceTempView("firstfltrNPI");;
					//		logger.debug("Count firstfltrNPI " + firstfltrNPI.count());
							Dataset<Row> mpinList = sqlCtx
									.sql(snaConfig.get(TriageKeys.MPIN_QUERY).replace(":1", suffix));
							mpinList.write().mode(SaveMode.Overwrite).insertInto(snaConfig.get(TriageKeys.MPIN_TBLNM));
							//mpinList.write().mode(SaveMode.Append).saveAsTable(snaConfig.get(TriageKeys.MPIN_TBLNM));
							

							logger.debug("Final set of providers");
							Dataset<Row> finalfilterprovs = sqlCtx
									.sql(snaConfig.get(TriageKeys.FINAL_FLTR_QUERY).replace(":1", suffix));
				//			logger.debug("Count for finalfilter "+finalfilterprovs.count());
							finalfilterprovs.write().mode(SaveMode.Overwrite)
									.insertInto(snaConfig.get(TriageKeys.FINAL_TBL_NAME));
							

							logger.debug("Executing lead query");
							Dataset<Row> leadQuery = sqlCtx
									.sql(snaConfig.get(TriageKeys.LEAD_QRY).replace(":1", suffix));
			//				logger.debug("Count for lead "+leadQuery.count());
							leadQuery.write().mode(SaveMode.Append).saveAsTable(snaConfig.get(TriageKeys.LEAD_TBLNM));
							
							logger.debug("Executing LINKAGE query");
							Dataset<Row> linkageQuery = sqlCtx
									.sql(snaConfig.get(TriageKeys.LINKAGE_QUERY).replace(":1", suffix));
						//	logger.debug("Count for linkage "+linkageQuery.count());
							
							linkageQuery.write().mode(SaveMode.Append).saveAsTable(snaConfig.get(TriageKeys.LINKAGE_TBLNM));
							
							
					//		logger.debug("Count finalfilterprovs " + finalfilterprovs.count());

							Dataset<Row> df1 = sqlCtx.sql(snaConfig.get(TriageKeys.TRIAGE_FINAL_RES_QUERY).replace(":1", suffix));
							
							String show_q= snaConfig.get(TriageKeys.TRIAGE_FINAL_RES_QUERY).replace(":1", suffix);
							
							logger.debug("Query for nhscore_arch"+ show_q);
							
							logger.debug("Saving text file started");

							logger.debug("Saving text file completed");
								
							logger.debug("Count: "+ df1.count());
							
							if ("Y".equalsIgnoreCase(snaConfig.get(TriageKeys.ARCH_DATA))) {
								logger.debug("Archiving triage results data");
								String tablename = snaConfig.get(TriageKeys.TRIAGE_INPUT_ARCHTABLE);
								logger.debug("Arch Table name " + tablename);
								
										
										df1.select("jobid","providerid","primaryneighbourflag").write().mode(SaveMode.Append).saveAsTable(snaConfig.get(TriageKeys.TRIAGE_INPUT_ARCHTABLE));
										
							}

							/*df1.createOrReplaceTempView("provdf1");
							String query = snaConfig.get(TriageKeys.TRIAGE_DEMOGRAPHIC_QUERY);

							query = query.replace(":1", suffix);
							Dataset<Row> df2 = sqlCtx.sql(query);
							df2.createOrReplaceTempView("provdf2");
							// logger.info("Count from second RDD" +
							// df2.count());
							logger.debug("Creating Resultant result set to shared start");*/
							logger.debug("Joining the data now");
					//		Dataset<Row> joinedData = sqlCtx.sql(snaConfig.get(TriageKeys.TRIAGE_FINAL_RES_QUERY).replace(":1", suffix));
							
							logger.debug("Mapping the joined Data");
							JavaRDD<SNAFinalResultsDto> rdd = df1.toJavaRDD()
									.map(new CreateFinalResultantFn(snaConfig));

							logger.info("Final Resultant ready. Count" + rdd.count());

							rdd.mapToPair(new HbaseMapToPairFn(
									Integer.parseInt(snaConfig.get(TriageKeys.TOP_RECORDS_NUM)), tmpBatchId, snaConfig))
									.saveAsNewAPIHadoopFile("TriageSNA", ImmutableBytesWritable.class, Put.class,
											TableOutputFormat.class, job.getConfiguration());

							// create list for provider leads- to uncomment for
							// provider leads
							JavaRDD<SNAFinalResultsDto> filterRec = rdd.filter(new FilterRecommendedRecords());
							logger.debug("Count of records " + filterRec.count());

							// filterRec.foreach(new
							// CreateProviderLead(tmpBatchId, snaConfig));
							logger.info("Gracefully stopping Spark Streaming Application");
							sqlCtx.sparkContext().stop();
							jsct.stop(true, true);
							jsct.close();
							logger.info("Application stopped");
							System.exit(0);
						}
					} catch (Exception e) {
						for (String jobId : batchRDD.collect()) {
							logger.error("Aborting process for jobId: " + jobId +" "+  e.getMessage());
							// SNAJobProcessState.snaTriageAborted(jobId);
							Runtime.getRuntime().exit(0);
						}
						e.printStackTrace();
					}
				}

			});

			jsct.start();
			jsct.awaitTermination();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (jsct != null)
				jsct.stop();
		}

	}

	public static void runOSCommand(List<String> arguments) throws Exception, IOException, InterruptedException {
		ProcessBuilder pb = new ProcessBuilder(arguments);
		pb.redirectErrorStream(true);
		pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
		if (pb.start().waitFor() != 0)
			throw new Exception("Exception caught while running shell$" + StringUtils.join(arguments, SPACE));

	}

	public static void runJschCommand(String cmd, SNATriageConfiguration snaConfig) throws Exception {
		JSch jsh = new JSch();
		StringBuilder sb = new StringBuilder();

		List<String> opErr = new ArrayList<String>();
		// Session remoteSession = jsh.getSession("srkexeid",
		// "apsrp00610.uhc.com", 22);
		Session remoteSession = jsh.getSession(snaConfig.get(TriageKeys.SERVER_USERID),
				snaConfig.get(TriageKeys.SERVER_ADD), 22);
		remoteSession.setConfig("StrictHostKeyChecking", "no");
		// remoteSession.setPassword("AraSrkP@17");
		remoteSession.setPassword(snaConfig.get(TriageKeys.SERVER_PWD));
		remoteSession.connect();
		logger.info("Session Established");
		ChannelExec channelExec = (ChannelExec) remoteSession.openChannel("exec");

		InputStream in = channelExec.getInputStream();
		InputStream err = channelExec.getErrStream();
		logger.info("Trying to run command :: " + cmd);
		channelExec.setCommand(cmd);
		channelExec.connect();
		logger.info("command ran");
		BufferedReader brIn = new BufferedReader(new InputStreamReader(in));
		BufferedReader brErr = new BufferedReader(new InputStreamReader(err));

		String line, errLine;

		while ((line = brIn.readLine()) != null) {
			sb = sb.append(line);
		}

		while ((errLine = brErr.readLine()) != null) {
			opErr.add(errLine);
		}

		if (channelExec.getExitStatus() != 0) {
			throw new Exception("Error : " + opErr);
		}
	}
}
