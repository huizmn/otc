package com.uhg.sna.triage.function;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.function.VoidFunction;

import com.uhc.sherlock.batchConnector.dbops.UpsertProvResultDeatils;
import com.uhc.sherlock.batchConnector.vo.ProviderLeadData;
import com.uhg.sna.triage.dto.SNAFinalResultsDto;
import com.uhg.sna.triage.util.SNATriageConfiguration;
import com.uhg.sna.triage.util.TriageKeys;

public class CreateProviderLead implements VoidFunction<SNAFinalResultsDto> {

	public CreateProviderLead(String batchId, SNATriageConfiguration snaConfig) {
		super();

		this.batchId = batchId;
		this.snaConfig = snaConfig;
	}

	private static final long serialVersionUID = 3343434L;
	private SNATriageConfiguration snaConfig;

	public SNATriageConfiguration getSnaConfig() {
		return snaConfig;
	}

	private String batchId;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public void call(SNAFinalResultsDto finalResults) throws Exception {
		Timestamp t = new Timestamp(System.currentTimeMillis());
		SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
		List<ProviderLeadData> listProv = new ArrayList<ProviderLeadData>();
		ProviderLeadData lead = new ProviderLeadData();
		lead.setProviderLeadId(getBatchId() + getSnaConfig().get(TriageKeys.TRIAGE_KEY_IDENTIFIER)
				+ finalResults.getSNABillingProvNPI());
		lead.setSNAServiceNPI(finalResults.getSNA_ServiceNPI());
		lead.setReasonCode(finalResults.getSNAReasonCode());
		lead.setReasonDescription(finalResults.getSNAReasonDesc());
		lead.setSnaAddrLine1(finalResults.getSNAAddrLine1());
		lead.setSnaCityName(finalResults.getSNACityName());
		lead.setSnaZipCd(finalResults.getSNAZipCd());
		lead.setSnaStateCd(finalResults.getSNAStateCd());
		lead.setSnaPhNo(finalResults.getSNAPhNo());
		lead.setSnaTaxanomyCode(finalResults.getSNATaxanomyCode());
		lead.setSnaLname(finalResults.getSNALname());
		lead.setSnaMName(finalResults.getSNAMName());
		lead.setSnaFName(finalResults.getSNAFName());
		lead.setSnaThreshold(finalResults.getSNAThreshold());
		lead.setSnaOdarFlag(finalResults.getSNAOdarFlag());
		lead.setSnaSanctionFlag(finalResults.getSNASanctionFlag());
		lead.setSnaDeathMasterFlag(finalResults.getSNADeathMasterFlag());
		lead.setSnaTrueFraudScoreEI(finalResults.getSNATrueFraudScoreEI());
		lead.setSnaTrueFraudScoreCS(finalResults.getSNATrueFraudScoreCS());
		lead.setSnaTrueFraudScoreMR(finalResults.getSNATrueFraudScoreMR());
		lead.setSnaWebCrawlerFlag(finalResults.getSNAWebCrawlerFlag());
		lead.setSnaSpeciality(finalResults.getSNASpeciality());
		lead.setSnaProviderName(finalResults.getSNAProviderName());
		lead.setSNAFinalRecommendedFlag(finalResults.getSNAFinalRecommendedFlag());
		lead.setSNACommViewLink(finalResults.getSNACommViewLink());
		lead.setCompositeScore(finalResults.getCompositeScore());
		lead.setSNABillingProvNPI(finalResults.getSNABillingProvNPI());
		lead.setSNANeighborsFraud1DScore(finalResults.getSNANeighborsFraud1DScore());
		lead.setSNANeighborsOdar1DScore(finalResults.getSNANeighborsOdar1DScore());
		lead.setProviderLeadSource("SNA");
		lead.setProviderLeadSentDate(dateFormat.format(t));
		lead.setSnaPrimNeighIndicator(finalResults.getSNAPrimNeighIndicator());
		lead.setSnaclusterindex(finalResults.getSNAclusterindex());
		lead.setSnaprvleadid(finalResults.getSNAprvleadid());
	/*	lead.setSnaIntelCenterIndic(finalResults.getSNAIntelCenterIndic());
		lead.setSnaLeadIndic(finalResults.getSNALeadIndic());*/		
		listProv.add(lead);
		
		UpsertProvResultDeatils.UpsertSNAScoreDtls(listProv);

	}

}
