package com.uhg.sna.triage.dto;

import java.io.Serializable;

public class ProviderResultDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6199842700005736322L;
	private String jobId;
	private String providerId;
	private String neighbourHoodScore;
	private String neighborsOdar1DScore;
	private String neighborsFraud1DScore;
	private String rowId="";
	private String topFlag = "false";
	
	
	public void setRowId(String rowId ) {
		this.rowId=rowId;
	}
	
	public String getRowId() {
		return rowId;
	}

	public String getJobId() {
		return jobId;
	}

	

	public String getTopFlag() {
		return topFlag;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getNeighbourHoodScore() {
		return neighbourHoodScore;
	}

	public String getNeighborsOdar1DScore() {
		return neighborsOdar1DScore;
	}

	public String getNeighborsFraud1DScore() {
		return neighborsFraud1DScore;
	}

	@Override
	public String toString() {
		return providerId;
			}

	public void setTopFlag(String topFlag) {
		this.topFlag = topFlag;
	}

	public ProviderResultDto(String jobId, String providerId, String neighbourHoodScore,String neighborsOdar1DScore,String neighborsFraud1DScore) {
		super();
		this.jobId=jobId;
		this.providerId = "P"+"00000000".substring(providerId.length()) + providerId;
		this.neighbourHoodScore = neighbourHoodScore;
		this.neighborsFraud1DScore=neighborsFraud1DScore;
		this.neighborsOdar1DScore=neighborsOdar1DScore;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	
}
