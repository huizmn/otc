package com.uhg.sna.triage.util;

public enum TriageKeys {
	LOGFILE("sna.triage.log4jPath"), MAPRDB_PROVIDERRESULT(
			"sna.triage.providerResultMaprdb"), RECEIVER_FREQUENCY(
			"sna.triage.receiverFrequency"), RECEIVER_METHOD_FREQUENCY(
			"sna.triage.receiverReceiveMethodSleepTime"), INPUT_PATH(
			"sna.triage.inputFile"), INPUT_FILE_DELIM(
			"sna.triage.inputFileDelim"),TOP_RECORDS_NUM("sna.triage.topRecordsNum"),TRIAGE_OP("sna.triage.output"),TRIAGE_CSV("sna.triage.csvFile"),TRIAGE_SCP_LOCATION("sna.triage.scpLocation"),
	TRAIGE_SCP_FILE_FILENAME("sna.triage.scpFileName"),TRIAGE_MAPR_MOUNT("sna.triage.maprMount"),TRIAGE_INPUT_ARCHTABLE("sna.triage.inputArchTable"),TRIAGE_DEMOGRAPHIC_QUERY("sna.triage.demographicQuery"),
	TRIAGE_FINAL_RES_QUERY("sna.triage.finalResultantQuery"),TRIAGE_RESULTS_COL_FAMILY("sna.triage.finalColFamily"),
	TRIAGE_KEY_IDENTIFIER("sna.triage.keyIdentifier"),
	TRIAGE_DOCKER_URL("sna.triage.dockerURL"),
	DOCKER_ADDRESS("sna.triage.dockerAddress"),
	DOCKER_SCRIPT_LOCATION("sna.triage.dockerScriptLocation"),
	FIRST_FLTR_QUERY("sna.triage.firstfltrquery"),
	FIRST_FLTR_TBL("sna.triage.tablefirst"),
	FINAL_FLTR_QUERY("sna.triage.fnlFltrQuery"),
	FINAL_TBL_NAME("sna.triage.fnlTblName"),
	FINAL_RES_QUERY("sna.triage.resultantQuery"),
	SERVER_ADD("sna.triage.currServerEdgeNode"),
	SERVER_USERID("sna.triage.userId"),
	SERVER_PWD("sna.triage.pwd"),
	ARCH_DATA("sna.traige.archFlag"),
	MPIN_QUERY("sna.triage.mpins"),
	MPIN_TBLNM("sna.triage.mpinTblNme"),
	
	LEAD_QRY("sna.triage.LeadQuery"),
	LEAD_TBLNM("sna.triage.LeadTblNm"),
	LINKAGE_QUERY("sna.triage.LinkageQuery"),
	LINKAGE_TBLNM("sna.triage.LinkageTblName")
	;

	private String value;
 
	TriageKeys(String in_text) {
		value = in_text;
	}

	public String getValue() {
		return value;
	}

}
