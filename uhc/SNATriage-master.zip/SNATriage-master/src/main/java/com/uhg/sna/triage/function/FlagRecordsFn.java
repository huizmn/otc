package com.uhg.sna.triage.function;

import org.apache.spark.api.java.function.Function;

import scala.Tuple2;

import com.uhg.sna.triage.dto.ProviderResultDto;

public class FlagRecordsFn implements
		Function<Tuple2<ProviderResultDto, Long>, ProviderResultDto> {

	public FlagRecordsFn(Integer threshold) {
		super();
		this.threshold = threshold;
	}

	private Integer threshold;

	public Integer getThreshold() {
		return threshold;
	}

	public void setThreshold(Integer threshold) {
		this.threshold = threshold;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -5146866976775419668L;

	@Override
	public ProviderResultDto call(Tuple2<ProviderResultDto, Long> tuple)
			throws Exception {
		// TODO Auto-generated method stub
		if (tuple._2 < threshold){
			tuple._1.setTopFlag("true");
			tuple._1.setRowId((tuple._2).toString());
		}
		
		return tuple._1;

	}

}
