package com.uhg.sna.triage.function;

import org.apache.spark.api.java.function.Function;

import com.uhg.sna.triage.dto.ProviderResultDto;

public class SortProvidersFn implements Function<ProviderResultDto, Float> {

	private static final long serialVersionUID = -8479530185211647949L;

	public Float call(ProviderResultDto v1) throws Exception {
		return Float.parseFloat((v1.getNeighbourHoodScore()));
	}

}
