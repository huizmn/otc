root@4ae064b7be64:/# cat run_neighborhood_scoring.sh
#!/usr/bin/env bash

set +x
set -e

echo "===========================================$0"

spark-submit --packages graphframes:graphframes:0.1.0-spark1.6 etl_1_degree_2_degree_fraud_scoring_graphframes.py --communities_file '/data_share/post_dga_etl_output/community_info_for_ui.csv' --provider_file '/data_share/current_linkage_files/MRProviderList.txt' --edge_file '/data_share/current_linkage_files/MRNetwork.txt' --output_filename '/data_share/post_dga_etl_output/neighborhood_scoring' --array_tempfile_dir '/data_share/post_dga_etl_output/'
root@4ae064b7be64:/# cat etl_1_degree_2_degree_fraud_scoring_graphframes.py
import os
import pandas as pd
import ctypes
import sys
import csv
import tempfile
import numpy as np
from pysparkling import Context
from pyspark import SparkConf
import argparse
import json
import time
import multiprocessing
from functools import partial
from scipy.stats import hypergeom
import ujson_norm
import math
import re

from graphframes import GraphFrame
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import HiveContext

# pid_to_1D_2D_neighbors_arr_global = ([],[],{},{})
pid_to_1D_2D_neighbors_arr_global = ([],[])
# total number of providers
N_PIDS = 0
# total number of odar fraud flag providers
K_ODAR = 0
MAX_V_NUM_GLOBAL = 1
PROVIDER_ID_STR = 'providerid'
ODAR_FLAG_STR = 'odarfraudflag'
TRUE_FRAUD_COMBO_SCORE_STR = 'true_fraud_score_combo'

def to_dict(x):
    arr = x.split(',')
    level = arr[0]
    node_1 = arr[1]
    node_2 = arr[2]
    weight = arr[3]
    dict = {}
    dict["level"] = level
    dict["node_1"] = node_1
    dict["node_2"] = node_2
    dict["weight"] = weight
    return dict

def dump(x):
    # return json.dumps(x)
    return ujson.dumps(x)


def get_max_vertex_num_from_df_pids(df_pids):
    max_pid = 1
    for index, row in df_pids.iterrows():
        pid = int(row[PROVIDER_ID_STR][1:])
        if(pid > max_pid):
            max_pid = pid
    return max_pid


def get_graph_from_edge_file_graphframes(edge_file, sc):
    # Create networkx graph:
    data = open(edge_file, "r")  # replace with the path to your edge file
    # Create Graph:
    # ---------------
    print('---stage 1 --------')
    # sc = SparkContext('local[*]')
    sqlContext = SQLContext(sc)
    # sqlContext = HiveContext(sc)

    count = 0
    div = 1000000

    max_v_num = MAX_V_NUM_GLOBAL
    local_vertices = []
    for i in range(max_v_num):
        local_vertices.append((i, str(i)))
    # print(local_vertices)
    local_edges = []
    print('begin adding edges')
    for line in data:
        if count == 0:
            count += 1
            continue
        str_arr = line.strip().split('\t')
        if(count % div == 0):
            print(count)
        node_1 = int(str_arr[0][1:]) - 1
        node_2 = int(str_arr[1][1:]) - 1
        weight = float(str_arr[2])
        local_edges.append((node_1, node_2, weight))
        # for debugging, use only 1 of 2 directions:
        # FOR FULL GRAPH, include below line for bidirectionality:
        # ----------------------------------
        local_edges.append((node_2, node_1, weight))
        # ----------------------------------

        count += 1
    num_parts_v_and_e = 1000
    v_rdd = sc.parallelize(local_vertices, num_parts_v_and_e)
    e_rdd = sc.parallelize(local_edges, num_parts_v_and_e)
    print('start creating vertices and edges dataframes')
    v = sqlContext.createDataFrame(v_rdd, ["id", "name"])
    e = sqlContext.createDataFrame(e_rdd, ["src", "dst", "weight"])
    print('done creating vertices and edges dataframes')


    print('Creating graphframes graph:')
    G = GraphFrame(v, e)
    print('Finished graph creation method')
    print('edge file line count:')
    print(count)
    data.close()
    return G

def get_graph_from_edge_file_graphframes_threshold(edge_file, sc):
    # Create networkx graph:
    data = open(edge_file, "r")  # replace with the path to your edge file
    # Create Graph:
    # ---------------
    print('---stage 1 --------')
    # sc = SparkContext('local[*]')
    sqlContext = SQLContext(sc)
    # sqlContext = HiveContext(sc)

    count = 0
    div = 1000000
    threshold_w = 0.05
    max_v_num = MAX_V_NUM_GLOBAL
    local_vertices = []
    for i in range(max_v_num):
        local_vertices.append((i, str(i)))
    # print(local_vertices)
    local_edges = []
    print('begin adding edges')
    for line in data:
        if count == 0:
            count += 1
            continue
        str_arr = line.strip().split('\t')
        if(count % div == 0):
            print(count)
        node_1 = int(str_arr[0][1:]) - 1
        node_2 = int(str_arr[1][1:]) - 1
        weight = float(str_arr[2])
        if(weight >= threshold_w):
            local_edges.append((node_1, node_2, weight))
            # for debugging, use only 1 of 2 directions for halving graph size:
            # FOR FULL GRAPH, include below line for bidirectionality:
            # ----------------------------------
            local_edges.append((node_2, node_1, weight))
        # ----------------------------------
        count += 1

    # v = sqlContext.createDataFrame(local_vertices, ["id", "name"])
    # e = sqlContext.createDataFrame(local_edges, ["src", "dst", "weight"])

    num_parts_v_and_e = 1000
    v_rdd = sc.parallelize(local_vertices, num_parts_v_and_e)
    e_rdd = sc.parallelize(local_edges, num_parts_v_and_e)
    print('start creating vertices and edges dataframes')
    v = sqlContext.createDataFrame(v_rdd, ["id", "name"])
    e = sqlContext.createDataFrame(e_rdd, ["src", "dst", "weight"])
    print('done creating vertices and edges dataframes')

    # v = sc.parallelize(local_vertices)
    # e = sc.parallelize(local_edges)
    print('Creating graphframes graph:')
    G = GraphFrame(v, e)
    print('Finished add edge list method')
    print('edge file line count:')
    print(count)
    data.close()
    return G

def get_pid_to_community_pids_arr(df_community, max_vertex_num):
    pid_comm_map = np.empty([max_vertex_num,], dtype=object)
    for index, row in df_community.iterrows():
        pid_array = row['provider_ids']
        for i in pid_array:
            pid_index = i - 1
            pid_comm_map[pid_index] = pid_array
    return pid_comm_map.tolist()

def get_neighbors_fraud(neighbors_list, pid_fraud_arr, n_dict):
    # Note:
    # pid_fraud_arr is 0-indexed, and n_dict is 1-indexed
    total_neighbor_fraud = 0
    for i in neighbors_list:
        pid_fraud_index = i - 1
        *Hello***
        total_neighbor_fraud += pid_fraud_arr[pid_fraud_index]*n_dict[pid_fraud_index+1]
    return total_neighbor_fraud

# GET NEIGHBORHOOD HYPERGEOMETRIC SCORE USING ODAR:
# USE CUMULATIVE DIST FUNCTION : (1 - p ) for score
# This is the probability that should see more fraud
# neighbors than less than or equal to number we currently see
# for a given provider:
def get_neighbors_hgs_odar(neighbors_list, pid_odar_flag_arr):
    # Note:
    # pid_fraud_arr is 0-indexed, and n_dict is 1-indexed
    total_neighbor_odar_flags = 0
    for i in neighbors_list:
        pid_fraud_index = i - 1
        total_neighbor_odar_flags += pid_odar_flag_arr[pid_fraud_index]
    n = len(neighbors_list)
    # k = total_neighbor_odar_flags
    # stats.hypergeom.sf(k, N, K, n)
    # print('k = %d' % total_neighbor_odar_flags)
    # print('N = %d' % N_PIDS)
    # print('K = %d' % K_ODAR)
    # print('n = %d' % n)
    if(n == 0):
        return 0
    pvalue = hypergeom.sf(total_neighbor_odar_flags, N_PIDS, K_ODAR, n)
    if(math.isnan(pvalue)):
        print('-----------FOUND NAN IN COMPUTATION OF ODAR FLAG SCORE-----------------')
        return 0
    return 1000*pvalue


def write_neighborhood_score_info_to_file_each_provider_gf(entry, pid_to_community_pids_arr, pid_fraud_arr,
                                                        pid_odar_flag_arr):
    print('CURRENT PID IS:')
    print(entry)
    pid = entry
    pid_index = pid - 1
    pid_array = pid_to_community_pids_arr[pid_index]

    try:
        Sc = set(pid_array)
    except:
        Sc = set()
    try:
        S1_arr_neighbor_edge = pid_to_1D_2D_neighbors_arr_global[0][pid_index][1]
    except:
        S1_arr_neighbor_edge = []
    try:
        S2_arr_neighbor_edge = pid_to_1D_2D_neighbors_arr_global[1][pid_index][1]
    except:
        S2_arr_neighbor_edge = []
    # Let 2d list include 1d and 2d neighbors:
    pid_1D_ns = []
    pid_2D_ns = []
    n1_dict = {}
    n2_dict = {}
    print('1D neighbors and edges of pid:')
    print(S1_arr_neighbor_edge)

    print('2D neighbors and edges of pid:')
    print(S2_arr_neighbor_edge)
    # pid_to_1D_2D_neighbors_arr_global contains pids that are 0-indexed
    # so we need to adjust back to 1-indexed:
    for n in S1_arr_neighbor_edge:
        print('neighbor and weight:')
        print(n)
        pid_i = int(n[0]) + 1
        pid_1D_ns.append(pid_i)
        pid_2D_ns.append(pid_i)
        n1_dict[pid_i] = n[1]
        # n2 dict includes 1D neighbors:
        n2_dict[pid_i] = n[1]
    # free up memory:
    del(S1_arr_neighbor_edge)

    for n in S2_arr_neighbor_edge:
        print('neighbor and weight')
        print(n)
        pid_i = int(n[0]) + 1
        pid_2D_ns.append(pid_i)
        # prevent 1D neighbors from being taken as 2D neighbors in terms of edge weights:
        if(pid_i in n2_dict):
            continue
        n2_dict[pid_i] = n[1]
    # free up memory:
    del(S2_arr_neighbor_edge)

    S1 = set(pid_1D_ns)
    S2 = set(pid_2D_ns)
    S_1c = S1.intersection(Sc)
    S_1c_arr = list(S_1c)
    S_2c = S2.intersection(Sc)
    S_2c_arr = list(S_2c)
    dict_i = {}
    dict_i['provider_id'] = pid
    dict_i['1D_louvain_neighbors'] = S_1c_arr
    dict_i['1D_neighbors_fraud'] = get_neighbors_fraud(S_1c_arr, pid_fraud_arr, n1_dict)
    dict_i['1D_neighbors_odar'] = get_neighbors_hgs_odar(S_1c_arr, pid_odar_flag_arr)

    dict_i['2D_louvain_neighbors'] = S_2c_arr
    dict_i['2D_neighbors_fraud'] = get_neighbors_fraud(S_2c_arr, pid_fraud_arr, n2_dict)
    dict_i['2D_neighbors_odar'] = get_neighbors_hgs_odar(S_2c_arr, pid_odar_flag_arr)
    *Hello**
    dict_i['true_fraud_odar_comprehensive_score'] = dict_i['2D_neighbors_fraud'] * dict_i['1D_neighbors_odar']

    dict_i['community_pids'] = pid_array
    return dict_i


# Write neighborhood score and other data for each provider to new file:
# Written data fields include:
# Community Fraud Score - 1 & 2 Degree
# 1 Degree Edges (within louvain community of interest)
# 1 & 2 Degree Edges (within louvain community of interest)
def write_neighborhood_score_info_to_file_all_providers_gf(sc, full_pid_array, pid_to_community_pids_arr,
                                                        pid_fraud_arr, pid_odar_flag_arr, output_filename):

    # For each provider p:
    # ----------------------------
    #     Get S1 = set of all 1 degree neighbors
    # Get S2 = set of all 2 degree neighbors
    # Get Sc = set of all providers in Community c,
    # where c is community of provider p:
    # For 1 degree, get S_1c = intersection(S1, S3)
    # Output S_1C to new_provider_file
    # Output edges of S1_c to new provider file

    # For 2 degree, get S_2c = intersection(S2, Sc)
    # For 2 degree, get S_2c = intersection(S2, Sc)
    # Output S_2c to new_provider_file
    # Output edges of S_2c to new_provider_file

    #     prev:
    # csv_df_file = 'dataframe_pids.csv'
    # neighborhood_metadata_file = output_filename
    # df_pids.to_csv(csv_df_file, header=False, index=False)

    # switch to pysparkling:
    # sc = Context()

    neighborhood_metadata_file = output_filename

    sc = Context()
    num_partitions = 1000
    rdd_pid_community_relation = sc.parallelize(full_pid_array, num_partitions)
    df_providers_and_fraud = rdd_pid_community_relation.map(
        lambda entry_i: write_neighborhood_score_info_to_file_each_provider_gf(entry_i, pid_to_community_pids_arr,
                                                                            pid_fraud_arr, pid_odar_flag_arr))
    print('proceeding to output results to file:')
    df_providers_and_fraud.map(dump).saveAsTextFile(neighborhood_metadata_file)
    return


# USE THIS IF COST OF OTHER 1D PATHS REDUCE FCT IS TOO GREAT:
def get_all_1d_paths_simple(x, y):
    x_edge = x['a']
    y_edge = y['a']
    z = x
    z_arr = []
    for i in x_edge:
        z_arr.append(i)
    for i in y_edge:
        z_arr.append(i)
    z['a'] = z_arr
    return z


def get_all_1d_paths(x, y):
    x_edge = x['a']
    y_edge = y['a']
    z = x
    z_arr = []
    # if both x and y have not joined with others before
    if(type(x_edge) == dict and type(y_edge) == dict):
        x_dst_and_weight = (x_edge['dst'], x_edge['weight'])
        y_dst_and_weight = (y_edge['dst'], y_edge['weight'])
        z_arr.append(x_dst_and_weight)
        z_arr.append(y_dst_and_weight)
        z['a'] = z_arr
    elif(type(x_edge)== dict and type(y_edge)==list):
        x_dst_and_weight = (x_edge['dst'], x_edge['weight'])
        z_arr = y_edge
        z_arr.append(x_dst_and_weight)
        z['a'] = z_arr
    elif(type(x_edge)== list and type(y_edge)==dict):
        z_arr = x_edge
        y_dst_and_weight = (y_edge['dst'], y_edge['weight'])
        z_arr.append(y_dst_and_weight)
        z['a'] = z_arr
    else:
        # then they are both lists - have joined before:
        z_arr = x_edge
        for i in y_edge:
            z_arr.append(i)
        z['a'] = z_arr
    z.pop('x1', None)
    z.pop('x2', None)
    return z

def get_all_2d_paths(x, y):
    x_endpt = x['x3']['id']
    y_endpt = y['x3']['id']
    x_weight = x['a']['weight']*x['b']['weight']
    y_weight = y['a']['weight']*y['b']['weight']
    paths_2d_key = 'paths_2d_dict'

    z = x
    z_dict = {}

    # PATTERN:
    # pattern = "(x1) - [a] -> (x2); (x2) - [b] -> (x3)"
    # x1, x2, x3 are vertices
    # a is edge from x1 to x2: x1 -a- x2
    # b is edge from x2 to x3: x2 -b- x3
    #     LET vi-vj-vk represent 2degree path from vi to vk for v1
    #   and va-vb-vc represent 2 degree path from vertex va to vc for va
    # case 1:
    #  vk != vc
    # then keep track of both paths in a store
    #     x_endpt = x["x3"]
    # case 2:
    # vk == vc
    # then combine weights


    paths_2d_dict_exists_bool_x = (paths_2d_key in x)
    paths_2d_dict_exists_bool_y = (paths_2d_key in y)

        # if both have a 2d dictionary:
    if (paths_2d_dict_exists_bool_x and paths_2d_dict_exists_bool_y):
        z_dict = x[paths_2d_key]
        y_dict = y[paths_2d_key]
        for key, value in y_dict.iteritems():
            # if vk != vc:
            if(key in z_dict):
                weight_count_tpl = z_dict[key]
                z_dict[key] = (weight_count_tpl[0]+value[0], weight_count_tpl[1]+value[1])
            else:
                z_dict[key] = value
        z[paths_2d_key] = z_dict
    elif (paths_2d_dict_exists_bool_x):
        z_dict = x[paths_2d_key]
        if (y_endpt in z_dict):
            weight_count_tpl = z_dict[y_endpt]
            z_dict[y_endpt] = (weight_count_tpl[0] + y_weight, weight_count_tpl[1] + 1)
        else:
            z_dict[y_endpt] = (y_weight, 1)
        z[paths_2d_key] = z_dict
    elif (paths_2d_dict_exists_bool_y):
        z_dict = y[paths_2d_key]
        if (x_endpt in z_dict):
            weight_count_tpl = z_dict[x_endpt]
            z_dict[x_endpt] = (weight_count_tpl[0] + x_weight, weight_count_tpl[1] + 1)
        else:
            z_dict[x_endpt] = (x_weight, 1)
        z[paths_2d_key] = z_dict
    else:
        # then neither have a 2d dictionary already:
        if(x_endpt == y_endpt):
            z_dict[x_endpt] = (x_weight + y_weight, 2)
        else:
            z_dict[x_endpt] = (x_weight, 1)
            z_dict[y_endpt] = (y_weight, 1)
        z[paths_2d_key] = z_dict
    z.pop('x1', None)
    z.pop('x2', None)
    return z


def loads(x):
    return ujson.loads(x)

def avg_weights(x):
    paths_2d_key = 'paths_2d_dict'
    # if the following is true,
    # then this pid is a leaf with only
    # one outgoing edge:
    if not(paths_2d_key in x[1]):
        x_weight = x[1]['a']['weight'] * x[1]['b']['weight']
        x_endpt = x[1]['x3']['id']
        n2_list = [(x_endpt, x_weight)]
        return (x[0], n2_list)

    z_dict = x[1][paths_2d_key]
    z_arr = []
    for key, value in z_dict.iteritems():
        w = float(value[0])/value[1]
        z_arr.append((key, w))
    # remove source pid from 2d list:
    z_arr_clean = []
    for i in z_arr:
        if not(i[0] == x[0]):
            z_arr_clean.append(i)
    z = (x[0], z_arr_clean)
    return z

def clean_1d_intermediate(x):
    val = x[1]['a']
    # check to see if x had only 1 neighbor
    if(type(val) == dict):
        x_weight = val['weight']
        x_endpt = val['dst']
        n1_list = [(x_endpt, x_weight)]
        return (x[0], n1_list)
    else:
        z = (x[0], val)
        return z



def write_tuple_arr_to_file(arr, file_name):
    with open(file_name, 'w') as fd:
        for i in arr:
            fd.write(str(i))
            fd.write('\n')


def get_tuple_single_elem_from_str(sng_elem_str):
    sng_elem_arr_split = sng_elem_str.split('(')[1].split(',')
    tpl = (int(sng_elem_arr_split[0]), float(sng_elem_arr_split[1]))
    return tpl


def get_tuple_arr_from_comma_sep_tuples_str(elems_str):
    elems_str_split_arr = elems_str.split(')')[:-1]
    elem_arr = []
    for i in elems_str_split_arr:
        elem_arr.append(get_tuple_single_elem_from_str(i))
    return elem_arr


def get_full_tuple_from_str(tuple_str):
    tuple_str_arr = tuple_str.split('[')
    ind = int(tuple_str_arr[0].split(',')[0][1:])
    arr_elems = tuple_str_arr[1][:-2]
    prepend_arr_elems = ', ' + arr_elems
    lst = get_tuple_arr_from_comma_sep_tuples_str(prepend_arr_elems)
    tuple_ind_list = (ind, lst)
    print(tuple_ind_list)
    return tuple_ind_list


def get_tuple_arr_from_file(num_entries, file_name):
    tst_tuple_arr_ordered = np.empty([num_entries, ], dtype=tuple)
    with open(file_name, 'r') as fd:
        for line in fd:
            tuple_i = get_full_tuple_from_str(line)
            ind = tuple_i[0]
            tst_tuple_arr_ordered[ind] = tuple_i
    return tst_tuple_arr_ordered.tolist()


# # EXAMPLE USING ABOVE READ AND WRITE TUPLE ARR FCTS:
# # -------------------------------------------------
# tst1 = (2, [(2, 3), (4, 5), (12, 12612500)])
# tst2 = (0, [(2, 3), (4, 5)])
# tst3 = (1, [(8, 10), (4, 5)])
# tst_tuple_arr = [tst1, tst2, tst3]
# out_read_test_tuple_file = 'out_read_test_tuple_file'
# # WRITE TO FILE:
# write_tuple_arr_to_file(tst_tuple_arr, out_read_test_tuple_file)
#
# # READ FROM FILE:
# tst_tuple_arr_ordered_l = get_tuple_arr_from_file(num_entries, out_read_test_tuple_file)
# print('disordered tuple arr:')
# # print(tst_tuple_arr)
# for i in tst_tuple_arr:
#     print(i)
# print('ordered tuple arr:')
# # print(tst_tuple_arr_ordered)
# for i in tst_tuple_arr_ordered_l:
#     print(type(i))
#     print(i)
# # -------------------------------------------------


def get_pid_to_1D_2D_neighbors_arr_gf(sc, edge_file, arr_temp_file_dir_path):
    num_pids = MAX_V_NUM_GLOBAL
    print('getting 1d, 2d neighbors array:')
    print(num_pids)
    start_time = time.time()
    # Get graph for finding 1d neighbors:
    G = get_graph_from_edge_file_graphframes(edge_file, sc)
    # GET 1D PATHS:
    # -----------------------------------------
    # 1D NEIGHBORS:
    pattern = "(x1) - [a] -> (x2)"
    paths = G.find(pattern)
    print('SAMPLE 1D NEIGHBORS PATTERN MATCH:')
    paths.show(1000)

    print('---------------GETTING 1D NEIGHBORS----------------------')
    df_1d_paths_rdd = (paths.toJSON().map(loads).keyBy(lambda d: d["x1"]["id"])
                       .reduceByKey(get_all_1d_paths).map(clean_1d_intermediate).sortByKey())
    n1_arr = df_1d_paths_rdd.collect()
    del(G)

    # OUTPUT N1_ARR TO FILE AND REMOVE FROM MEMORY
    # THEN GET ORDERED, PROPERLY INDEXED ARRAY:
    # -----------------------------------------
    n1_arr_filename = os.path.join(arr_temp_file_dir_path, 'n1_arr.txt')
    # WRITE TO FILE:
    write_tuple_arr_to_file(n1_arr, n1_arr_filename)
    del(n1_arr)

    # READ FROM FILE:
    n1_arr = get_tuple_arr_from_file(MAX_V_NUM_GLOBAL, n1_arr_filename)
    os.remove(n1_arr_filename)
    # -----------------------------------------

    print('GETTING 2D GRAPH:')
    G_2d = get_graph_from_edge_file_graphframes_threshold(edge_file, sc)
    print('---------------GETTING 2D NEIGHBORS----------------------')
    # 2D NEIGHBORS:

    pattern_2d = "(x1) - [a] -> (x2); (x2) - [b] -> (x3)"
    paths_2d = G_2d.find(pattern_2d)
    # prev 2d neighbor retrieval - used too much disk space in tmp:
    df_2d_paths_rdd = (paths_2d.toJSON().map(loads).keyBy(lambda d: d["x1"]["id"])
                       .reduceByKey(get_all_2d_paths).map(avg_weights).sortByKey())
    n2_arr = df_2d_paths_rdd.collect()
    del(G_2d)

    # OUTPUT N2_ARR TO FILE AND REMOVE FROM MEMORY
    # THEN GET ORDERED ARRAY, PROPERLY INDEXED ARRAY:
   # -----------------------------------------
    n2_arr_filename = os.path.join(arr_temp_file_dir_path, 'n2_arr.txt')
    # WRITE TO FILE:
    write_tuple_arr_to_file(n2_arr, n2_arr_filename)
    del(n2_arr)

    # READ FROM FILE:
    n2_arr = get_tuple_arr_from_file(MAX_V_NUM_GLOBAL, n2_arr_filename)
    # delete temp file to free storage:
    os.remove(n2_arr_filename)
    # -----------------------------------------

    delta_t_in_minutes = (time.time() - start_time) / 60.0
    print('------------- %f ELAPSED MINUTES FOR BUILDING NEIGHBOR LIST ---------------------' % delta_t_in_minutes)
    return (n1_arr, n2_arr)


def get_pid_fraud_and_odar_flag_arr(csv_file, max_vertex_pid):
    csvfile = open(csv_file, 'r')
    csv_first_line = csvfile.readline().strip()
    csvfile.seek(0)
    #     fieldnames = ("FirstName","LastName","IDNumber","Message")
    fieldnames = csv_first_line.split('\t')
    #     print(fieldnames)
    reader = csv.DictReader(csvfile, fieldnames, delimiter='\t')
    title = reader.fieldnames
    print(title)
    #     fraud_arr is TrueFraud score and 0-indexed, so fraud_arr[0] is fraud score for P0000001
    fraud_arr = np.zeros([max_vertex_pid,])
    odar_flag_arr = np.zeros([max_vertex_pid,])
    count = 0
    for row in reader:
        #skip header
        if count == 0:
            count += 1
            continue
        pid = int(row[PROVIDER_ID_STR][1:])
        pid_ind = pid - 1
        fraud_i = float(row[TRUE_FRAUD_COMBO_SCORE_STR])
        odar_i = int(row[ODAR_FLAG_STR])
        fraud_arr[pid_ind] = fraud_i
        odar_flag_arr[pid_ind] = odar_i
        count += 1
    csvfile.close()
    print(count)
    return fraud_arr.tolist(), odar_flag_arr.tolist()

def get_pid_fraud_and_odar_flag_arr_from_df(df, max_vertex_pid):
    fraud_arr = np.zeros([max_vertex_pid,])
    odar_flag_arr = np.zeros([max_vertex_pid,])
    count = 0
    for index, row in df.iterrows():
        pid = int(row[PROVIDER_ID_STR][1:])
        pid_ind = pid - 1
        fraud_i = float(row[TRUE_FRAUD_COMBO_SCORE_STR])*1000
        odar_i = int(row[ODAR_FLAG_STR])
        fraud_arr[pid_ind] = fraud_i
        odar_flag_arr[pid_ind] = odar_i
        count += 1
    print(count)
    return fraud_arr.tolist(), odar_flag_arr.tolist()

def get_pid_df(filepath):
    with open(filepath) as pfd:
        df_pids = pd.read_csv(pfd, delimiter='\t')
        return df_pids


def get_pid_df_with_combo_true_fraud(file_path):
    df_pids = get_pid_df(file_path)
    provider_id_str = PROVIDER_ID_STR
    odar_flag_str = ODAR_FLAG_STR
    true_fraud_score_ei_str = 'truefraudscore_ei'
    true_fraud_score_cs_str = 'truefraudscore_cs'
    true_fraud_score_mr_str = 'truefraudscore_mr'

    true_fraud_score_ei_normalized_str = true_fraud_score_ei_str + '_norm'
    true_fraud_score_cs_normalized_str = true_fraud_score_cs_str + '_norm'
    true_fraud_score_mr_normalized_str = true_fraud_score_mr_str + '_norm'

    df_pids[provider_id_str] = df_pids.filter(regex=re.compile(provider_id_str, re.IGNORECASE))
    df_pids[odar_flag_str] = df_pids.filter(regex=re.compile(odar_flag_str, re.IGNORECASE))
    df_pids[true_fraud_score_ei_str] = df_pids.filter(regex=re.compile(true_fraud_score_ei_str, re.IGNORECASE))
    df_pids[true_fraud_score_cs_str] = df_pids.filter(regex=re.compile(true_fraud_score_cs_str, re.IGNORECASE))
    df_pids[true_fraud_score_mr_str] = df_pids.filter(regex=re.compile(true_fraud_score_mr_str, re.IGNORECASE))

    true_fraud_score_cumulative_str = TRUE_FRAUD_COMBO_SCORE_STR
    true_fraud_score_ei_col_max = float(df_pids[true_fraud_score_ei_str].max())
    true_fraud_score_cs_col_max = float(df_pids[true_fraud_score_cs_str].max())
    true_fraud_score_mr_col_max = float(df_pids[true_fraud_score_mr_str].max())

    df_pids[true_fraud_score_ei_normalized_str] = df_pids[true_fraud_score_ei_str].apply(lambda x:
                                                                                         x / true_fraud_score_ei_col_max)
    df_pids[true_fraud_score_cs_normalized_str] = df_pids[true_fraud_score_cs_str].apply(lambda x:
                                                                                         x / true_fraud_score_cs_col_max)
    df_pids[true_fraud_score_mr_normalized_str] = df_pids[true_fraud_score_mr_str].apply(lambda x:
                                                                                         x / true_fraud_score_mr_col_max)

    cols = [true_fraud_score_ei_normalized_str, true_fraud_score_cs_normalized_str, true_fraud_score_mr_normalized_str]
    lst = df_pids[cols].idxmax(axis=1)

    df_pids[true_fraud_score_cumulative_str] = df_pids.lookup(list(range(df_pids.shape[0])), lst)
    df_pids = df_pids.drop(true_fraud_score_ei_normalized_str, 1)
    df_pids = df_pids.drop(true_fraud_score_cs_normalized_str, 1)
    df_pids = df_pids.drop(true_fraud_score_mr_normalized_str, 1)
    return df_pids


# Write all community fraud score meta-data of interest to neighborhood scoring file
if __name__ == "__main__":

    conf = (SparkConf()
            .setMaster('local[*]')
            .set("spark.driver.maxResultSize", "20g")
            .set("spark.worker.cleanup.enabled", "true")
            .set("spark.worker.cleanup.interval", "300")
            .set("spark.shuffle.consolidateFiles", "true")
            .set("spark.shuffle.memoryFraction", "0.4")
            .set("spark.shuffle.file.buffer.kb", "64")
            .set("spark.reducer.maxMbInFlight", "96"))
    #         .set("spark.shuffle.manager", "SORT")
    #         .set("spark.executor.memory", "32G")
    #         .set("spark.akka.frameSize", "1000")
    sc = SparkContext(conf=conf)

    start_time = time.time()
    desc = 'provider id - 1degree, 2degree louvain community fraud scoring'
    parser = argparse.ArgumentParser(
        description=desc,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=desc)
    default_community_filename = 'community_info_for_ui.csv'
    default_provider_filename = 'MRProviderList.txt'
    default_edge_filename = 'MRNetwork.txt'
    default_output_filename = 'neighborhood_metadata'
    default_array_tempfile_dir = '/data_share/neighborhood_score_large_linkage_set/'

    parser.add_argument("--communities_file", help="input directory", default=default_community_filename)
    parser.add_argument("--provider_file", help="output file", default=default_provider_filename)
    parser.add_argument("--edge_file", help="output file", default=default_edge_filename)
    parser.add_argument("--output_filename", help="output file", default=default_output_filename)
    parser.add_argument("--array_tempfile_dir", help="temp file path", default=default_array_tempfile_dir)
    args = parser.parse_args()

    # READ in file with each community id and all providers for each community:
    #     --------------------
    communities_with_all_providers_filepath = args.communities_file
    #     communities_json = json.loads(communities_with_all_providers_filepath)
    with open(communities_with_all_providers_filepath) as json_data:
        l_arr = [json.loads(l) for l in json_data]
        df_communities = pd.DataFrame(l_arr)

    # READ in provider list (MRProviderList):
    # --------------------
    # provider_list_filepath = args.provider_file
    # provider_list_filepath = 'MRProviderList.txt'
    # with open(provider_list_filepath) as pfd:
    #     df_pids = pd.read_csv(pfd, delimiter='\t')

    # ADD trueFraudScore column to pandas df:
    # USING UHC specified formula:
    # ---------------------------
    provider_list_filepath = args.provider_file
    # SEE GLOBAL STRINGS USED TO INDEX df_pids -
    # listed below for convenience:
    # provider_id_str = 'providerid'
    # odar_flag_str = 'odarfraudflag'
    # true_fraud_score_cumulative_str = 'true_fraud_score_combo'

    df_pids = get_pid_df_with_combo_true_fraud(provider_list_filepath)
    # -----------------------------

    #     GET 1d, 2d neighbors for each pid:
    # ------------------------------
    edge_file = args.edge_file
    MAX_V_NUM_GLOBAL = get_max_vertex_num_from_df_pids(df_pids)

    pid_to_1D_2D_neighbors_arr_global = get_pid_to_1D_2D_neighbors_arr_gf(sc, edge_file, args.array_tempfile_dir)
    # ------------------------------

    num_pids = df_pids.shape[0]
    N_PIDS = num_pids
    print('num_pids')
    print(num_pids)
    pid_to_community_pids_arr = get_pid_to_community_pids_arr(df_communities, MAX_V_NUM_GLOBAL)

    # pid_fraud_arr, pid_odar_flag_arr = get_pid_fraud_and_odar_flag_arr(provider_list_filepath, MAX_V_NUM_GLOBAL)
    pid_fraud_arr, pid_odar_flag_arr = get_pid_fraud_and_odar_flag_arr_from_df(df_pids, MAX_V_NUM_GLOBAL)

    def get_num_odar_fraud_pids(odar_flag_arr):
        total = 0
        for i in odar_flag_arr:
            total += i
        return total

    K_ODAR = get_num_odar_fraud_pids(pid_odar_flag_arr)
    print('before degree neighbors computation - time:')
    print(time.time())

    def get_pids_array(df):
        arr = []
        for index, row in df.iterrows():
            pid = int(row[PROVIDER_ID_STR][1:])
            arr.append(pid)
        return arr

    print(df_pids.info())
    print(df_pids.shape)
    full_pid_array = get_pids_array(df_pids)
    write_neighborhood_score_info_to_file_all_providers_gf(sc, full_pid_array, pid_to_community_pids_arr,
                                                        pid_fraud_arr, pid_odar_flag_arr, args.output_filename)

    delta_t_in_minutes = (time.time() - start_time) / 60.0
    print('------------- %f ELAPSED MINUTES ---------------------' % delta_t_in_minutes)
