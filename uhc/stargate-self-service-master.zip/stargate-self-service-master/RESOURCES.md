Documentation migrated to here: https://stargate-docs.optum.com/docs/self-service-resources.html
