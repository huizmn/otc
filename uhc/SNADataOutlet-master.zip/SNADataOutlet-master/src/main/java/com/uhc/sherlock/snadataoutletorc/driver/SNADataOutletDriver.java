package com.uhc.sherlock.snadataoutletorc.driver;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import com.mapr.org.apache.hadoop.hbase.util.Bytes;
import com.uhc.sherlock.batchConnector.dbops.UpsertProvResultDeatils;
import com.uhc.sherlock.batchConnector.vo.ProviderLeadData;
import com.uhc.sherlock.snaJobConnector.dbops.SNAJobProcessState;
import com.uhc.sherlock.snadataoutletorc.common.Utils;
import com.uhc.sherlock.snadataoutletorc.jaxbclasses.SNAProviderLeadBatch;
import com.uhc.sherlock.snadataoutletorc.receiver.JobReceiver;

public class SNADataOutletDriver {

	static Logger logger = Logger.getLogger("file");
	private static  SimpleDateFormat FINAL_SHERLOCK_DATE_FORMAT;
	static final SimpleDateFormat LEAD_GENERATION_FORMAT = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
	static final String CLAIM_GENERATION_TIME = LEAD_GENERATION_FORMAT.format(Calendar.getInstance().getTime());
	public static void main(String[] args) throws Exception {
		
		if (args.length < 1) {
			System.err.println("Missing argument==>Properties File Path");
			System.exit(1);
		}

		final Utils util = new Utils(args[0]);
		
			try {
				FINAL_SHERLOCK_DATE_FORMAT = new SimpleDateFormat(util.getString("sherlock.snadataoutlet.finalDateFormat"));
			} catch (Exception e) {
				throw new RuntimeException("Unable to parse final date format for lead files");
			}
		
		PropertyConfigurator.configure(util.getString("sna.snadataoutlet.log4jConf"));

		final String providerResultMAPRDB = util.getString("sna.snadataoutlet.providerResultMaprdb");
		final String ndbMaprDb = util.getString("sna.snadataoutlet.ndbprovtbl");
		final String sourceCf = util.getString("sna.snadataoutlet.sourceCf");
		final String ndbCf = util.getString("sna.snadataoutlet.ndbprovcf");
		final String ndbTaxIdCol = util.getString("sna.snadataoutlet.ndbprovTIN");
		final String pHistoryMaprdb = util.getString("sherlock.dataoutlet.pHistoryMaprdb");
		final String pHistoryCf = util.getString("sherlock.dataoutlet.pHistoryCf");
		final String pHistoryCol = util.getString("sherlock.dataoutlet.pHistoryCol");

		JavaStreamingContext jsct = null;

		try {

			SparkConf sparkConf = new SparkConf().setAppName("SNADataOutletORCApplication");

			final JavaSparkContext jsc = new JavaSparkContext(sparkConf);

			logger.info("New Run! ApplicationId==>" + jsc.sc().applicationId());
			jsct = new JavaStreamingContext(jsc,
					new Duration(Long.parseLong(util.getString("sna.snadataoutlet.receiverFrequency"))));
			JavaReceiverInputDStream<String> jobDstream = jsct.receiverStream(new JobReceiver(
					Long.parseLong(util.getString("sna.snadataoutlet.receiverReceiveMethodSleepTime"))));
			jobDstream.print();

			jobDstream.foreachRDD(new VoidFunction<JavaRDD<String>>() {
				private static final long serialVersionUID = 1239370L;

				@Override
				public void call(JavaRDD<String> jobIdRDD) throws Exception {
					String jobId = null;
					try {

						if (!jobIdRDD.isEmpty()) {

							for (String job : jobIdRDD.collect()) {
								jobId = job;
							}

							SNAJobProcessState.snaDataOutletStarted(jobId);

							SNAProviderLeadBatch snaResultBatch = new SNAProviderLeadBatch();
							List<ProviderLeadData> resultsList = snaResultBatch.getProviderLead();
							logger.info("Connecting to maprdb to fetch Data");

							Configuration config = HBaseConfiguration.create();
							Connection connection = ConnectionFactory.createConnection(config);
							try {
								Table table = connection.getTable(TableName.valueOf(providerResultMAPRDB));
								Table ndbTable = ndbTable = connection.getTable(TableName.valueOf(ndbMaprDb));
								Table pHistoryTable = connection.getTable(TableName.valueOf(pHistoryMaprdb));

								try {
									Scan s = new Scan();
									SingleColumnValueFilter singleColumnValueFilter = new SingleColumnValueFilter(
											Bytes.toBytes(sourceCf), Bytes.toBytes("SNAFinalRecommendedFlag"),
											CompareFilter.CompareOp.EQUAL, Bytes.toBytes("true"));

									singleColumnValueFilter.setFilterIfMissing(true);

									List<Filter> filterListOrdered = new ArrayList<Filter>();

									String prefix = jobId + "SN";

									PrefixFilter prefixFilter = new PrefixFilter(prefix.getBytes());
									filterListOrdered.add(prefixFilter);
									filterListOrdered.add(singleColumnValueFilter);

									FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL,
											filterListOrdered);

									s.setFilter(filterList);

									ResultScanner scanner = table.getScanner(s);
									try {
										for (Result rr = scanner.next(); rr != null; rr = scanner.next()) {
											ProviderLeadData providerLeadData = new ProviderLeadData();
											providerLeadData.setProviderLeadId(Bytes.toString(rr.getRow()));
											String npi = Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNABillingProvNPI".getBytes()));
											providerLeadData.setSNABillingProvNPI(npi);

											providerLeadData.setSnaReasonDesc(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAReasonDesc".getBytes())));
											providerLeadData.setSnaAddrLine1(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAAddrLine1".getBytes())));
											providerLeadData.setSnaCityName(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNACityName".getBytes())));
											providerLeadData.setSnaZipCd(Bytes
													.toString(rr.getValue(sourceCf.getBytes(), "SNAZipCd".getBytes())));
											providerLeadData.setSnaStateCd(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAStateCd".getBytes())));

											providerLeadData.setSnaTaxanomyCode(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNATaxanomyCode".getBytes())));

											// Added by Nikhil for ndb tax id
											// changes
											logger.info("npi"+npi);
											String taxId = getTaxIdFromPhistory(pHistoryTable, npi, pHistoryCf, pHistoryCol);
											if (taxId == null || taxId.isEmpty()){
											logger.info("Inside if ");
												taxId = getTaxId(ndbTable, npi, ndbCf, ndbTaxIdCol);
											}
											providerLeadData.setSnaProviderTaxID(taxId);
/*
											providerLeadData
													.setSnaProviderTaxID(getTaxId(ndbTable, npi, ndbCf, ndbTaxIdCol));*/

											providerLeadData.setSnaPhNo(Bytes
													.toString(rr.getValue(sourceCf.getBytes(), "SNAPhNo".getBytes())));
											providerLeadData.setSnaFName(Bytes
													.toString(rr.getValue(sourceCf.getBytes(), "SNAFName".getBytes())));
											providerLeadData.setSNAFinalRecommendedFlag(Bytes.toString(rr.getValue(
													sourceCf.getBytes(), "SNAFinalRecommendedFlag".getBytes())));
											providerLeadData.setSnaMName(Bytes
													.toString(rr.getValue(sourceCf.getBytes(), "SNAMName".getBytes())));
											providerLeadData.setSnaLname(Bytes
													.toString(rr.getValue(sourceCf.getBytes(), "SNALname".getBytes())));
											providerLeadData.setSnaOdarFlag(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAOdarFlag".getBytes())));
											providerLeadData.setSnaSanctionFlag(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNASanctionFlag".getBytes())));
											providerLeadData.setSnaDeathMasterFlag(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNADeathMasterFlag".getBytes())));
											providerLeadData.setSnaTrueFraudScoreEI(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreEI".getBytes())));
											providerLeadData.setSnaTrueFraudScoreCS(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreCS".getBytes())));
											providerLeadData.setSnaTrueFraudScoreMR(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreMR".getBytes())));
											providerLeadData.setSnaWebCrawlerFlag(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAWebCrawlerFlag".getBytes())));
											providerLeadData.setSnaSpeciality(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNASpeciality".getBytes())));
											providerLeadData.setSnaProviderName(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAProviderName".getBytes())));
											providerLeadData.setSnaReasonCode(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAReasonCode".getBytes())));
											providerLeadData.setCompositeScore(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNACompositeScore".getBytes())));
											providerLeadData.setSNACommViewLink(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNACommViewLink".getBytes())));
											providerLeadData.setSNANeighborsFraud1DScore(Bytes.toString(rr.getValue(
													sourceCf.getBytes(), "SNANeighborsFraud1DScore".getBytes())));
											providerLeadData.setSNANeighborsOdar1DScore(Bytes.toString(rr.getValue(
													sourceCf.getBytes(), "SNANeighborsOdar1DScore".getBytes())));
											providerLeadData.setSNAServiceNPI(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAServiceNPI".getBytes())));
											providerLeadData.setSnaThreshold(Bytes.toString(
													rr.getValue(sourceCf.getBytes(), "SNAThreshold".getBytes())));
											providerLeadData.setSnaTrueFraudScoreCS(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreCS".getBytes())));
											providerLeadData.setSnaTrueFraudScoreEI(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreEI".getBytes())));
											providerLeadData.setSnaTrueFraudScoreMR(Bytes.toString(rr
													.getValue(sourceCf.getBytes(), "SNATrueFraudScoreMR".getBytes())));
											providerLeadData.setProviderLeadSource("SNA");
											providerLeadData.setProviderLeadSentDate(CLAIM_GENERATION_TIME);
											providerLeadData.setSnaPrimNeighIndicator(Bytes.toString
													(rr.getValue(sourceCf.getBytes(), "SNAPrimNeighIndicator".getBytes())));
											providerLeadData.setSnaclusterindex(Bytes.toString
													(rr.getValue(sourceCf.getBytes(), "SNAclusterindex".getBytes())));
											providerLeadData.setSnaprvleadid(Bytes.toString
													(rr.getValue(sourceCf.getBytes(), "SNAprvleadid".getBytes())));
										/*	providerLeadData.setSnaIntelCenterIndic("N");
											providerLeadData.setSnaLeadIndic(Bytes.toString
													(rr.getValue(sourceCf.getBytes(), "SNALeadIndic".getBytes())));*/
															
											
											// Missing in schema this
											// //providerLeadData.set(Bytes.toString(rr.getValue(sourceCf.getBytes(),"SNAProviderId".getBytes())));

											resultsList.add(providerLeadData);
										}

									} finally {

										scanner.close();
									}

								} finally {
									if (table != null)
										table.close();
									ndbTable.close();
								}
							} finally {
								connection.close();
							}

							if (!resultsList.isEmpty()) {

								logger.info("Received provider lead count" + resultsList.size());
								
								for (ProviderLeadData providerLeadData : resultsList) {
									providerLeadData.setProviderLeadSentDate(
											FINAL_SHERLOCK_DATE_FORMAT.format(LEAD_GENERATION_FORMAT.parse(CLAIM_GENERATION_TIME)));
								}
								
								SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
								String currentTimeStamp = df.format(new Date());
								File file = new File(
										util.getString("sna.snadataoutlet.outputexport") + currentTimeStamp + ".xml");
								JAXBContext jaxbContext = JAXBContext.newInstance(SNAProviderLeadBatch.class);
								Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
								jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
								logger.info("Marshalling now");
								jaxbMarshaller.marshal(snaResultBatch, file);
								
								reformatAndSQLInsert(resultsList);
							}

							logger.info("processed jobId--->" + jobId);
							com.uhc.sherlock.jobConnector.common.Utils.send(
									util.getString("sherlock.dataoutlet.frmAdd"),
									util.getString("sherlock.dataoutlet.toAdd"),
									util.getString("sherlock.dataoutlet.subjLn"),
									util.getString("sherlock.dataoutlet.mailCnt") + " " + jobId);

							SNAJobProcessState.snaDataOutletCompleted(jobId);
							Runtime.getRuntime().exit(0);

						}
					} catch (Exception e) {
						e.printStackTrace();
						for (String jobid : jobIdRDD.collect()) {
							logger.error("Job aborted: Reporting " + jobid + " as aborted to SQLSERVER"
									+ "  Exception-->" + e.getMessage());
							SNAJobProcessState.snaDataOutletAborted(jobid, e.getLocalizedMessage());
							Runtime.getRuntime().exit(1);

						}
					}

				}

			});

			jsct.start();
			jsct.awaitTermination();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (jsct != null)
				jsct.stop();
		}

	}
	
	/*
	 * reformat dates to use actual claim generation time.
	 * Change added. New method.
	 */
	private static void reformatAndSQLInsert(List<ProviderLeadData> providerLeadsData)
			throws ClassNotFoundException, SQLException {
		for (ProviderLeadData providerLeadData : providerLeadsData) {
			providerLeadData.setProviderLeadSentDate(CLAIM_GENERATION_TIME);
		}
		UpsertProvResultDeatils.UpsertSNAScoreDtls(providerLeadsData);
		logger.info("Import into SQLSERVER of Provider Lead File Done");
	}

	// added by Nikhil for tax id inclusion
	public static String getTaxId(Table ndbTable, String npi, String cf, String col) throws IOException {
		String taxId = "";
		try {
			Get get = new Get(Bytes.toBytes(npi));
			Result r = ndbTable.get(get);
			taxId = Bytes.toString(r.getValue(cf.getBytes(), col.getBytes()));
		} catch (Exception e) {
			logger.error("Error in get taxid" + e.getMessage());
		}

		return taxId;
	}
	
	private static String getTaxIdFromPhistory(Table pHistoryTable, String npi, String cf, String col)
			throws IOException {
		String taxId = "";
		PrefixFilter prefixFilter = new PrefixFilter(npi.getBytes());
		Scan scan = new Scan();
		scan.setStartRow(npi.getBytes());
		scan.setFilter(prefixFilter);
		ResultScanner scanner = pHistoryTable.getScanner(scan);
		Iterator<Result> resultsItr = scanner.iterator();
		while (resultsItr.hasNext()) {
			// Serialized form of Claim in String format is PIPE '|' delimited
			// with tin in 3 position of the array after split.
			taxId = Bytes.toString(resultsItr.next().getValue(cf.getBytes(), col.getBytes())).split("\\|", -1)[2];
			if (!taxId.isEmpty() || taxId == null) {
				logger.info("Found TIN from Phistory for npi" + npi);
				return taxId;

			}
		}
		logger.info("No TaxId found for npi" + npi);
		return taxId;

	}

}
