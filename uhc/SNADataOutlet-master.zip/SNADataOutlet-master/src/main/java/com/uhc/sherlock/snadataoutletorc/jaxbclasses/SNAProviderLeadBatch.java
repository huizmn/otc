package com.uhc.sherlock.snadataoutletorc.jaxbclasses;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.uhc.sherlock.batchConnector.vo.ProviderLeadData;

@XmlRootElement
public class SNAProviderLeadBatch {
	
	private List<ProviderLeadData> providerLead = new ArrayList<ProviderLeadData>();

	public List<ProviderLeadData> getProviderLead() {
		return providerLead;
	}

	public void setProviderLead(List<ProviderLeadData> providerLead) {
		this.providerLead = providerLead;
	}
	
	//test

}
