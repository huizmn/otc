package com.uhc.sherlock.snadataoutletorc.receiver;

import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.receiver.Receiver;

import com.uhc.sherlock.snaJobConnector.dbops.SNAJobProcessState;

public class JobReceiver extends Receiver<String> {
	private long BatchFrequency;

	public JobReceiver(long batchFrequency2) {
		super(StorageLevel.MEMORY_AND_DISK_2());
		BatchFrequency = batchFrequency2;
	}

	private static final long serialVersionUID = -915684744218706633L;

	@Override
	public void onStart() {
		// Start the thread that receives batchId from the batch connector
		// library.
		new Thread() {
			@Override
			public void run() {
				receive();
			}
		}.start();
	}

	@Override
	public void onStop() {

	}

	private void receive() {
		try {
			while (true) {
				Thread.sleep(this.BatchFrequency);
				String jobid = SNAJobProcessState.getSnaDataOutletJobId()
						.trim();
				if (jobid.length() != 0) {
					store(jobid);
				}

			

			}
		} catch (Exception e) {
			restart("Error receiving data", e);
		}

	}

}
