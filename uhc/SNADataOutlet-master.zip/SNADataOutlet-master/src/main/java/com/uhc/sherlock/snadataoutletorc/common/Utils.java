package com.uhc.sherlock.snadataoutletorc.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Utils {
	private String propertiesPath;

	public Utils(String path) {
		propertiesPath = path;
	}

	static Properties properties = new Properties();

	public String getString(String key) throws Exception {
		// Load each time a value may change in the file.
		properties.load(new FileInputStream(propertiesPath));
		String value = properties.getProperty(key);
		if (value != null)
			return value;
		else
			throw new Exception("Missing value for Key" + key);

	}

	public static String replaceBlankWithHash(String inputStr) {
		if ("".equals(inputStr.trim()) || inputStr == null)
			return "-";
		else
			return inputStr;
	}

}
