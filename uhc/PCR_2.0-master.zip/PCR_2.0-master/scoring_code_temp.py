
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
from pyspark.sql.functions import count, avg,col,min,max,mean,stddev,lit,when,last_day,round,datediff, to_date, lit
import time
from dateutil.relativedelta import relativedelta
import datetime
import pandas as pd
import re
from pyspark.sql.functions import last_day
from pyspark.sql.functions import count, avg,col,min,max,mean,stddev,lit,when,last_day,round,datediff, to_date, lit
import time
from dateutil.relativedelta import relativedelta
import datetime
import copy
from  pyspark.sql.functions import abs
print("Start time ::")
print(time.ctime())
from pyspark.sql.functions import pow, col
from pyspark.sql.functions import log
import logging
import ConfigParser


spark = SparkSession \
    .builder \
    .appName("Python Spark SQL basic example").enableHiveSupport() \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()

####### loading FE tool kit

import FeatureEnginnering_final

####### loading parquet location

config_path = '/home/ssing339/pcr2_ei.config'

spark.conf.set("spark.sql.execution.arrow.enabled", "true")
print("Start")

print("************************************application id for spark*****************************************************")
print(spark.sparkContext.applicationId)

print("process run date calculation begins")
t1=time.time()
tstart=time.time()
configParser = ConfigParser.RawConfigParser()
configFilePath = config_path
configParser.read(configFilePath)
last_date = configParser.get('file', 'last_date')
path_parquet= configParser.get('file', 'path_parquet')
n_months= int(configParser.get('file', 'n_months'))
std_count= int(configParser.get('file', 'std_count'))

start_date=(datetime.datetime.strptime(last_date, "%Y-%m-%d")-relativedelta(months=18)).strftime("%Y-%m-%d")
end_date=(datetime.datetime.strptime(last_date, "%Y-%m-%d")-relativedelta(months=n_months)).strftime("%Y-%m-%d")

spark.conf.set("hive.exec.dynamic.partition","true")
spark.conf.set("hive.exec.dynamic.partition.mode","nonstrict")
spark.conf.set("spark.sql.broadcastTimeout",3600)
#################### unet_claim_header data pull ######################
### Pull 1.5 data from unet_claim_header basis early service date ##### 
#######################################################################

spark.sql('''drop table if exists ssing339_pcr.pcr_sk_claim_header''')
spark.sql('''create table ssing339_pcr.pcr_sk_claim_header as select distinct 
mbr_bth_dt,
mbr_sys_id,
mbr_age,
erly_srvc_dt,
mbr_gdr_cd,
mbr_zip_cd,
UNET_CLM_HEAD_SYS_ID
from galaxy.unet_claim_header 
where unix_timestamp(erly_srvc_dt, "yyyy-MM-dmbr_sys_idd") >= unix_timestamp("2017-08-01", "yyyy-MM-dd")
and unix_timestamp(erly_srvc_dt, "yyyy-MM-dd") <= unix_timestamp("2019-01-31", "yyyy-MM-dd")''')


#################### unet_claim_statistical_service data pull #########
####Pull data from unet_claim_statistical_service basis 		  #####
####claims from header table pulled in previous query 			  ##### 
#### Filter for physician claims only                             #####
#######################################################################


print(" galaxy line level data pull ")

spark.sql('''drop table if exists ssing339_pcr.pcr_ss_claim_statistical_service_fully_paid''')
spark.sql('''create table ssing339_pcr.pcr_ss_claim_statistical_service_fully_paid as 
select a.mbr_sys_id,
a.bil_prov_npi_nbr,
a.clm_aud_nbr,
a.cust_seg_nbr,
a.cust_seg_sys_id,
a.diag_1_cd,
a.diag_2_cd,
a.diag_3_cd,
a.diag_4_cd,
a.icd_ver_cd,
a.proc_cd,
a.proc_mod_1_sys_id,
a.proc_mod_2_sys_id,
a.proc_mod_3_sys_id,
a.proc_mod_4_sys_id,
a.proc_mod_5_sys_id,
a.prov_prtcp_sts_cd,
a.prov_st_abbr_cd,
a.prov_tin,
a.prov_zip_cd,
a.srvc_prov_catgy_cd,
a.srvc_prov_npi_nbr,
a.SRVC_PROV_ROW_EFF_DT,
a.srvc_prov_sys_id,
a.fst_srvc_dt,
a.clm_pd_dt,
a.adj_srvc_unit_cnt,
a.allw_amt,
a.net_pd_amt,
a.sbmt_chrg_amt,
b.mbr_age, 
b.mbr_bth_dt,
b.mbr_gdr_cd, 
b.mbr_zip_cd, 
b.erly_srvc_dt
from galaxy.unet_claim_statistical_service as a
inner join 
ssing339_pcr.pcr_sk_claim_header as b
on a.UNET_CLM_HEAD_SYS_ID=b.UNET_CLM_HEAD_SYS_ID
and a.mbr_sys_id= b.mbr_sys_id
where upper(trim(a.clm_loc_cd))="2"''')

########## dont pull all columns


############## line level roll up ####################
### Identify the columns which define a claim line ###
### Roll up the dollar attributes and dates        ###
######################################################


spark.sql('''drop table if exists ssing339_pcr.pcr_sk_claim_statistical_service_line_agg''')
spark.sql('''create table ssing339_pcr.pcr_sk_claim_statistical_service_line_agg as 
select mbr_sys_id, clm_aud_nbr, cust_seg_sys_id, cust_seg_nbr, mbr_bth_dt, mbr_gdr_cd, mbr_zip_cd, 
diag_1_cd, diag_2_cd, diag_3_cd, diag_4_cd, icd_ver_cd, proc_cd, proc_mod_1_sys_id, proc_mod_2_sys_id, proc_mod_3_sys_id, proc_mod_4_sys_id, proc_mod_5_sys_id, 
prov_tin, prov_prtcp_sts_cd, prov_st_abbr_cd, prov_zip_cd, srvc_prov_catgy_cd, srvc_prov_sys_id, SRVC_PROV_ROW_EFF_DT, bil_prov_npi_nbr, srvc_prov_npi_nbr, 
min(erly_srvc_dt) as erly_srvc_dt, 
min(fst_srvc_dt) as fst_srvc_dt,
min(clm_pd_dt) as clm_pd_dt, 
sum(adj_srvc_unit_cnt) as adj_srvc_unit_cnt , 
sum(allw_amt) as allw_amt,
sum(net_pd_amt) as net_pd_amt,
sum(sbmt_chrg_amt) as bil_amt
from ssing339_pcr.pcr_ss_claim_statistical_service_fully_paid
group by mbr_sys_id, clm_aud_nbr, cust_seg_sys_id, cust_seg_nbr, mbr_bth_dt, mbr_gdr_cd, mbr_zip_cd, diag_1_cd, diag_2_cd, diag_3_cd, diag_4_cd, icd_ver_cd, proc_cd, proc_mod_1_sys_id, proc_mod_2_sys_id, proc_mod_3_sys_id, proc_mod_4_sys_id, proc_mod_5_sys_id, prov_tin, prov_prtcp_sts_cd, prov_st_abbr_cd, prov_zip_cd, srvc_prov_catgy_cd, srvc_prov_sys_id, SRVC_PROV_ROW_EFF_DT, bil_prov_npi_nbr, srvc_prov_npi_nbr''')


################### Idenify Fully insured claims ######################################################
### Using the "finc_arng_cd" column from member table, idenify fully insured members   				###
### Idenify the coverage status of member for each claim using "mbr_cov_mo_row_eff_dt" 				###
### Member can be fully insured for claim X, but when mbr applies y, mbr is no more fully insured   ###
#######################################################################################################

spark.sql('''drop table if exists ssing339_pcr.pcr_ss_claim_statistical_service_distinct_mbr_dt''')
spark.sql('''create table ssing339_pcr.pcr_ss_claim_statistical_service_distinct_mbr_dt as
select  distinct a.mbr_sys_id, a.fst_srvc_dt, b.finc_arng_cd
from 
(select distinct mbr_sys_id, fst_srvc_dt 
from ssing339_pcr.pcr_sk_claim_statistical_service_line_agg) as a
inner join 
(select distinct mbr_sys_id, finc_arng_cd, mbr_cov_mo_row_eff_dt, mbr_cov_mo_row_end_dt
from galaxy.MEMBER_COVERAGE_MONTH) as b
where upper(trim(b.finc_arng_cd))="F" 
and a.mbr_sys_id=b.mbr_sys_id
and a.fst_srvc_dt >= b.mbr_cov_mo_row_eff_dt 
and a.fst_srvc_dt <= b.mbr_cov_mo_row_end_dt''')

######################### Filter the claims basis amt and unit count #################
##### Filter out claims where allw_amt <=0 and srvc unit count <=0   #################
######################################################################################

spark.sql('''drop table if exists ssing339_pcr.pcr_ss_claim_statistical_service_filtered''')
spark.sql('''create table ssing339_pcr.pcr_ss_claim_statistical_service_filtered as 
select a.*
from ssing339_pcr.pcr_sk_claim_statistical_service_line_agg as a
inner join ssing339_pcr.pcr_ss_claim_statistical_service_distinct_mbr_dt as b
on a.mbr_sys_id=b.mbr_sys_id
and a.fst_srvc_dt = b.fst_srvc_dt
where adj_srvc_unit_cnt>0
and allw_amt>0''')


################ Mapping proc_mod_sys_id with their actual values ####################

spark.sql('''drop table if exists ssing339_pcr.procedure_codes_mapping''')
spark.sql('''create table ssing339_pcr.procedure_codes_mapping as 
select distinct proc_mod_sys_id,proc_mod_cd from galaxy.PROCEDURE_MODIFIER_CODE''')

############ Pull provider and procedure modifier values #####################
### Filter out ICD 9 lines from the table                              #######
### Using provider table in galaxy, pull the service provider details  #######
### Provider name, address and speciality 							   #######
### Using PROV_PRTCP_STS_CD, create par-non par flag with P/N vaues only######
##############################################################################

spark.sql('''drop table if exists ssing339_pcr.pcr_sk_claim_statistical_service_raw_columns''')
spark.sql('''create table ssing339_pcr.pcr_sk_claim_statistical_service_raw_columns as 
select 
a.*,
c.mpin,
c.adr_ln_1_txt,
c.billing_provider_st_abbr_cd,
c.prov_typ_nm,
c.provider_cty_nm,
c.provider_fst_nm,
c.provider_lst_nm,
c.provider_zip_cd,
concat(month(a.fst_srvc_dt),year(a.fst_srvc_dt)) as month_year_id,
concat(trim(provider_fst_nm),",",trim(provider_lst_nm)) as Providername,
CASE WHEN a.PROV_PRTCP_STS_CD = "" THEN "N" WHEN a.PROV_PRTCP_STS_CD = "T" THEN "P" ELSE a.PROV_PRTCP_STS_CD END AS par_non_par_flag,
d.proc_mod_cd as proc_mod_cd1,
e.proc_mod_cd as proc_mod_cd2,
f.proc_mod_cd as proc_mod_cd3,
g.proc_mod_cd as proc_mod_cd4,
h.proc_mod_cd as proc_mod_cd5
from ( select * from ssing339_pcr.pcr_ss_claim_statistical_service_filtered where allw_amt > 0
and icd_ver_cd!=9 and adj_srvc_unit_cnt>0 ) as a
left join ( select distinct 
PROV_ROW_EFF_DT,PROV_SYS_ID,
mpin,adr_ln_1_txt,st_abbr_cd as billing_provider_st_abbr_cd,
spcl_grp_desc as prov_typ_nm,
cty_nm as provider_cty_nm,
fst_nm as provider_fst_nm,
lst_nm as provider_lst_nm,
zip_cd as provider_zip_cd from galaxy.provider ) as c
on a.SRVC_PROV_ROW_EFF_DT =  c.PROV_ROW_EFF_DT
and a.SRVC_PROV_SYS_ID  = c.PROV_SYS_ID
left join ssing339_pcr.procedure_codes_mapping  d 
on 
a.proc_mod_1_sys_id=d.proc_mod_sys_id
left join ssing339_pcr.procedure_codes_mapping  e 
on 
a.proc_mod_2_sys_id=e.proc_mod_sys_id
left join ssing339_pcr.procedure_codes_mapping  f 
on 
a.proc_mod_3_sys_id=f.proc_mod_sys_id
left join ssing339_pcr.procedure_codes_mapping  g 
on 
a.proc_mod_4_sys_id=g.proc_mod_sys_id
left join ssing339_pcr.procedure_codes_mapping  h 
on 
a.proc_mod_5_sys_id=h.proc_mod_sys_id''')








pcr_sk_claim_statistical_service_raw_columns = spark.sql("select * from ssing339_pcr.pcr_sk_claim_statistical_service_raw_columns")

pcr_sk_claim_statistical_service_raw_columns.createOrReplaceTempView("pcr_sk_claim_statistical_service_raw_columns")



################ allowed amount reduction logic ##################################
#### Identify common modifiers 26,53,TC in proc mod 1-5       				  ####
#### using RVU lookup table, idenitfy if cpt-modifier qualifies for reduction ####
#### Generate a flag common_cpt_mult_unit_flag                				  ####
##################################################################################


pcr_sk_claim_statistical_service_raw_columns_adjusted_amt_temp = spark.sql('''
select b.*, c.code, c.modifier, (case when c.code is not null then 1 else 0 end) as common_cpt_mult_unit_flag, coalesce(nfrvu,0) as nfrvu
from
(select *, 
case when proc_mod_cd_concat like "%26%" then "26" 
when proc_mod_cd_concat like "%53%" then "53" 
when proc_mod_cd_concat like "%TC%" then "TC" 
when trim(proc_mod_cd_concat) ="" then "" 
else trim(proc_mod_cd_concat) end as common_cpt_mod
from
(
select *,concat_ws(" ",proc_mod_cd1, proc_mod_cd2, proc_mod_cd3, proc_mod_cd4, proc_mod_cd5) as proc_mod_cd_concat
from pcr_sk_claim_statistical_service_raw_columns 
where allw_amt>0
and trim(srvc_prov_catgy_cd)!="" and trim(srvc_prov_catgy_cd)!="?" and trim(srvc_prov_catgy_cd) is not null 
and trim(diag_1_cd)!="" and trim(diag_1_cd)!="?" and trim(diag_1_cd) is not null 
and trim(proc_cd)!="" and trim(proc_cd)!="?" and trim(proc_cd) is not null
) as a) as b
left join pi_usrs.pcr_ss_rvu_lookup as c
on trim(b.proc_cd)=trim(c.code)
and trim(b.common_cpt_mod)=trim(c.modifier)''').repartition(1000)


pcr_sk_claim_statistical_service_raw_columns_adjusted_amt_temp.createOrReplaceTempView("pcr_sk_claim_statistical_service_raw_columns_adjusted_amt_temp")


############ Identify the primary and secondary procedure ############################
#### Within a claim, Using nfrvu value, identify primary and secondary procedures ####
### cpt with highest  nfrvu value is  primary procedure 						  ####
######################################################################################

pcr_ss_allw_amt_adjustment_base_temp2 = spark.sql('''
select *, rank() over (partition by mbr_sys_id, clm_aud_nbr, bil_prov_npi_nbr, mpin, diag_1_cd, diag_2_cd, diag_3_cd, diag_4_cd order by nfrvu desc, allw_amt desc) as common_proc_rank
from pcr_sk_claim_statistical_service_raw_columns_adjusted_amt_temp
where code is not null
and modifier is not null''')

pcr_ss_allw_amt_adjustment_base_temp2.createOrReplaceTempView("pcr_ss_allw_amt_adjustment_base_temp2")


################ Generate common_cpt_mult_cpt_flag flag ####################
### Join the previous two tables and mark 1 for all secondary cpt ##########
############################################################################


pcr_ss_allw_amt_adjustment_base = spark.sql('''
select a.*, common_proc_rank, common_cpt_mult_cpt_flag
from pcr_sk_claim_statistical_service_raw_columns_adjusted_amt_temp as a
left join 
(select mbr_sys_id, mbr_bth_dt, cust_seg_nbr, clm_aud_nbr, fst_srvc_dt, erly_srvc_dt, par_non_par_flag, prov_zip_cd, prov_st_abbr_cd, bil_prov_npi_nbr, srvc_prov_npi_nbr, srvc_prov_catgy_cd, mpin, adj_srvc_unit_cnt, diag_1_cd, diag_2_cd, diag_3_cd, diag_4_cd, proc_cd, proc_mod_cd_concat, nfrvu, common_proc_rank, 
(case when common_proc_rank > 1 then 1 else 0 end) as common_cpt_mult_cpt_flag, allw_amt
from pcr_ss_allw_amt_adjustment_base_temp2) as b
on a.mbr_sys_id=b.mbr_sys_id
and a.clm_aud_nbr=b.clm_aud_nbr
and a.bil_prov_npi_nbr=b.bil_prov_npi_nbr
and a.cust_seg_nbr = b.cust_seg_nbr
and a.fst_srvc_dt=b.fst_srvc_dt
and a.erly_srvc_dt=b.erly_srvc_dt
and a.diag_1_cd=b.diag_1_cd
and a.diag_2_cd = b.diag_2_cd
and a.diag_3_cd = b.diag_3_cd
and a.diag_4_cd = b.diag_4_cd
and a.proc_cd = b.proc_cd
and a.proc_mod_cd_concat=b.proc_mod_cd_concat
and a.srvc_prov_catgy_cd=b.srvc_prov_catgy_cd
and a.mpin=b.mpin
and a.allw_amt=b.allw_amt
and a.prov_st_abbr_cd=b.prov_st_abbr_cd
and a.adj_srvc_unit_cnt = b.adj_srvc_unit_cnt
and a.mbr_bth_dt=b.mbr_bth_dt
and a.prov_zip_cd = b.prov_zip_cd
and a.srvc_prov_npi_nbr=b.srvc_prov_npi_nbr''')

pcr_ss_allw_amt_adjustment_base.createOrReplaceTempView("pcr_ss_allw_amt_adjustment_base")

################### Creating Base table for Feature creation ############################
## Missing value imputation repeated as done during model development      			 ####
## Allowed amount reduction to per unit as allw_amt/adj_srvc_unit_cnt if all flags 0 ####
## allw_amt*2/(1+adj_srvc_unit_cnt) if either of binary flags created above is set 	 ####
#########################################################################################

print("creating  base table to be used for feature craetion ")

pcr_sk_claim_statistical_service_raw_columns_adjusted_amt = spark.sql('''
select
mbr_sys_id,
clm_aud_nbr,
cust_seg_sys_id,
cust_seg_nbr,
mbr_bth_dt,
mbr_gdr_cd,
mbr_zip_cd,
diag_1_cd,
diag_2_cd,
diag_3_cd,
diag_4_cd,
icd_ver_cd,
proc_cd,
proc_mod_1_sys_id,
proc_mod_2_sys_id,
proc_mod_3_sys_id,
proc_mod_4_sys_id,
proc_mod_5_sys_id,
prov_tin,
prov_prtcp_sts_cd,
prov_zip_cd,
srvc_prov_catgy_cd,
srvc_prov_sys_id,
srvc_prov_row_eff_dt,
erly_srvc_dt,
fst_srvc_dt,
clm_pd_dt,
adj_srvc_unit_cnt,
allw_amt,
net_pd_amt,
bil_amt,
adr_ln_1_txt,
billing_provider_st_abbr_cd,
prov_typ_nm,
provider_cty_nm,
provider_fst_nm,
provider_lst_nm,
provider_zip_cd,
month_year_id,
providername,
par_non_par_flag,
proc_mod_cd1,
proc_mod_cd2,
proc_mod_cd3,
proc_mod_cd4,
proc_mod_cd5,
common_cpt_mod,
code,
modifier,
proc_mod_cd_concat,
common_cpt_mult_cpt_flag,
common_cpt_mult_unit_flag,	
case when mpin in (null,"","?") then "others" else mpin end as mpin,
case when trim(bil_prov_npi_nbr) in (null,"","?") then "others" else bil_prov_npi_nbr end as bil_prov_npi_nbr,
case when trim(srvc_prov_npi_nbr) in (null,"","?") then "others" else srvc_prov_npi_nbr end as srvc_prov_npi_nbr,
case when trim(prov_st_abbr_cd) in (null,"","?") then "TX" else prov_st_abbr_cd end as prov_st_abbr_cd,
case when ((common_cpt_mult_unit_flag=1 or common_cpt_mult_cpt_flag=1 ) 
and (proc_mod_cd_concat not like "%50%") 
and (adj_srvc_unit_cnt>1) )
then (2*allw_amt)/(1+adj_srvc_unit_cnt) 
else allw_amt/adj_srvc_unit_cnt end as common_cpt_final_adjusted_allw_amt
from pcr_ss_allw_amt_adjustment_base''')

pcr_sk_claim_statistical_service_raw_columns_adjusted_amt.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"pcr_sk_claim_statistical_service_raw_columns_adjusted_amt.parquet")


print("######################## feature creation ##############################")

pcr_sk_claim_statistical_service_raw_columns_adjusted_amt = spark.read.parquet(path_parquet+"pcr_sk_claim_statistical_service_raw_columns_adjusted_amt.parquet")

pcr_sk_claim_statistical_service_raw_columns_adjusted_amt.createOrReplaceTempView("pcr_sk_claim_statistical_service_raw_columns_adjusted_amt")
base_table = spark.sql('''select *,common_cpt_final_adjusted_allw_amt as allw_amt_per_unit from pcr_sk_claim_statistical_service_raw_columns_adjusted_amt''')

base_table.createOrReplaceTempView("base_table")



########## creating the four model features   ##################
### proc code lookback 6 months								####
### modifier avg lookback 6 months							####
### state AVG LOOKBACK	6 mponths							####
### speciality AVG LOOKBACK 6 months						####
################################################################




######### proc code lookback 6 months calculation 				##################################
#### creating tall format data for all 5 proc modifier fields                   		##########
#### taking 6 months lookback at par non par level for tall format proc modifier mod	##########
##################################################################################################

tall_table = spark.sql('''
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd1 as mod ,allw_amt_per_unit from base_table  a where trim(proc_mod_cd1)!=''
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd2 as mod ,allw_amt_per_unit from base_table b where trim(proc_mod_cd2)!=''
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd3 as mod ,allw_amt_per_unit from base_table c where trim(proc_mod_cd3)!=''
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd4 as mod ,allw_amt_per_unit from base_table  d where trim(proc_mod_cd4)!=''
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd5 as mod ,allw_amt_per_unit from base_table  e where trim(proc_mod_cd5)!=''
''')

tall_table.createOrReplaceTempView("tall_table")

cpt_mod_avg_lookback_6 = FeatureEnginnering_final.look_back_fxn(tall_table,["proc_cd","par_non_par_flag","mod"],"fst_srvc_dt","allw_amt_per_unit",["mean"],6,n_months)

cpt_mod_avg_lookback_6.createOrReplaceTempView(" cpt_mod_avg_lookback_6")

######### proc modifier lookback for situation when all modifiers are null ###################

base_table1= spark.sql("select *,proc_mod_cd1 as mod from base_table where trim(proc_mod_cd1)='' and trim(proc_mod_cd2)='' and trim(proc_mod_cd3)='' and trim(proc_mod_cd4)='' and trim(proc_mod_cd5)=''")



base_table1.createOrReplaceTempView("base_table1")

cpt_mod_avg_lookback_6_210 = FeatureEnginnering_final.look_back_fxn(base_table1,["proc_cd","par_non_par_flag","mod"],"fst_srvc_dt","allw_amt_per_unit",["mean"],6,n_months)

cpt_mod_avg_lookback_6_210.createOrReplaceTempView(" cpt_mod_avg_lookback_6_210")

cpt_mod_avg_lookback_df= spark.sql("select * from cpt_mod_avg_lookback_6 union all select * from cpt_mod_avg_lookback_6_210")

cpt_mod_avg_lookback_df.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"cpt_mod_avg_lookback_df.parquet")

######################## Missing value imputation table generation for proc modifier feature #############
###### creating tall format for all proc modifier fields									 #############
###### Taking average at cpt, par non par level      										 #############
###### national_cpt_mod_avg table created to be used while imputation 						 #############
##########################################################################################################


tall_table1 = spark.sql('''
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd1 as mod ,allw_amt_per_unit from base_table  a 
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd2 as mod ,allw_amt_per_unit from base_table b 
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd3 as mod ,allw_amt_per_unit from base_table c 
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd4 as mod ,allw_amt_per_unit from base_table  d 
union all
select proc_cd,par_non_par_flag,fst_srvc_dt,proc_mod_cd5 as mod ,allw_amt_per_unit from base_table  e 
''')

national_cpt_mod_avg = FeatureEnginnering_final.Aggregation_fxn(tall_table1,["proc_cd","par_non_par_flag","mod"],["allw_amt_per_unit"],["mean"])

national_cpt_mod_avg.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"national_cpt_mod_avg.parquet")

###################lookback tables creation using FeatureEnginnering_final.look_back_fxn ############################################

########## CPT STATE lookback table 


cpt_state_lookback_6 = FeatureEnginnering_final.look_back_fxn(base_table,["proc_cd","prov_st_abbr_cd","par_non_par_flag"],"fst_srvc_dt","allw_amt_per_unit",["mean"],6,n_months)

cpt_state_lookback_6.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"cpt_state_lookback_6.parquet")


######## CPT SPECIALITY lookback table

cpt_speciality_lookback_6 = FeatureEnginnering_final.look_back_fxn(base_table,["proc_cd","srvc_prov_catgy_cd","par_non_par_flag"],"fst_srvc_dt","allw_amt_per_unit",["mean"],6,n_months)

cpt_speciality_lookback_6.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"cpt_speciality_lookback_6.parquet")

##### CPT level lookback table

cpt_average = FeatureEnginnering_final.look_back_fxn(base_table,["proc_cd","par_non_par_flag"],"fst_srvc_dt","allw_amt_per_unit",["mean"],6,n_months)

cpt_average.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"cpt_average.parquet")

########### LOADING TABLES TO BE USED IN CREATION OF ANALYTICAL TABLE 							    ######
######## 1. LINE LEVEL CLAIMS TABLE "pcr_sk_claim_statistical_service_raw_columns_adjusted_amt" 	######
######## 2. LOOKBACK TABLES GENERATED USING FEATURE ENGINEERING KIT     							######
##########################################################################################################

base_table = spark.sql('''select *,common_cpt_final_adjusted_allw_amt as allw_amt_per_unit from pcr_sk_claim_statistical_service_raw_columns_adjusted_amt''')

base_table =base_table.withColumn("last_day_base",last_day("fst_srvc_dt"))

base_table.createOrReplaceTempView("base_table")

cpt_average= spark.read.parquet(path_parquet+"cpt_average.parquet")
cpt_average.createOrReplaceTempView("cpt_average")

cpt_speciality_lookback_6 = spark.read.parquet(path_parquet+"cpt_speciality_lookback_6.parquet")

cpt_speciality_lookback_6.createOrReplaceTempView("cpt_speciality_lookback_6")

cpt_state_lookback_6 = spark.read.parquet(path_parquet+"cpt_state_lookback_6.parquet")

cpt_state_lookback_6.createOrReplaceTempView("cpt_state_lookback_6")

cpt_mod_avg_lookback_df = spark.read.parquet(path_parquet+"cpt_mod_avg_lookback_df.parquet")

cpt_mod_avg_lookback_df.createOrReplaceTempView("cpt_mod_avg_lookback_df")

national_cpt_mod_avg= spark.read.parquet(path_parquet+"national_cpt_mod_avg.parquet")
national_cpt_mod_avg.createOrReplaceTempView("national_cpt_mod_avg")

print("################ joining with the line level data to create model base table ##########################")

######### CREATION OF BASE TABLE WITH LOOK BACK FEATURES ##############
##### speciality_lb_6months 								###########
##### state_lb_6months      								###########
#######################################################################

base_table_model = spark.sql('''
select a.*,
b.pre6_proc_cd_srvc_prov_catgy_cd_par_non_par_flag_mean_allw_amt_per_unit as speciality_lb_6months,
c.pre6_proc_cd_prov_st_abbr_cd_par_non_par_flag_mean_allw_amt_per_unit as state_lb_6months
from 
base_table a
left join cpt_speciality_lookback_6 b 
on 
trim(upper(a.proc_cd))=trim(upper(b.proc_cd))
and 
trim(upper(a.srvc_prov_catgy_cd))=trim(upper(b.srvc_prov_catgy_cd))
and 
a.last_day_base=b.last_day
and 
trim(a.par_non_par_flag)= trim(b.par_non_par_flag)
left join cpt_state_lookback_6 c 
on 
trim(upper(a.proc_cd))=trim(upper(c.proc_cd))
and 
trim(upper(a.prov_st_abbr_cd))=trim(upper(c.prov_st_abbr_cd))
and 
a.last_day_base=c.last_day
and 
trim(a.par_non_par_flag)= trim(c.par_non_par_flag)
''')


#####################  		saving model base table in parquet format#################################
base_table_model.createOrReplaceTempView("base_table_model")

############# FILTER 12 MONTHS OF DATA TO BE SCORED BASIS END DATE FILTER ###################

pcr_ss_model_base_table_select1= spark.sql('''
select *
from base_table_model
where last_day_base>"'''+end_date+'''"''')

pcr_ss_model_base_table_select1.createOrReplaceTempView("pcr_ss_model_base_table_select1")

############# MISSING VALUE IMPUTATION TABLE FOR PROC CODE LOOK BACK FEATURE ################
proc_cd_mvi_map1 = spark.sql(''' select 
proc_cd,
par_non_par_flag,
avg(allw_amt_per_unit) as mean_amt from 
pcr_ss_model_base_table_select1 group by proc_cd,par_non_par_flag''')
proc_cd_mvi_map1.createOrReplaceTempView("proc_cd_mvi_map1")

print("############## created imputed base table for model ")

################### MISSING VALUE IMPUTATION FOR FEATURES #######
####   Target variable  : Imputation logic 			      #######
####   cpt_modifier_lb_6months: national average          #######
####   speciality_lb_6months  :	national average	      #######
#################################################################



pcr_ss_model_base_table_select_imputed_final_adjusted_allw_amt = spark.sql('''
select 
mbr_sys_id,
clm_aud_nbr,
cust_seg_sys_id,
cust_seg_nbr,
mbr_bth_dt,
mbr_gdr_cd,
mbr_zip_cd,
diag_1_cd,
diag_2_cd,
diag_3_cd,
diag_4_cd,
icd_ver_cd,
proc_cd,
prov_tin,
prov_prtcp_sts_cd,
prov_zip_cd,
srvc_prov_catgy_cd,
srvc_prov_sys_id,
srvc_prov_row_eff_dt,
erly_srvc_dt,
fst_srvc_dt,
clm_pd_dt,
adj_srvc_unit_cnt,
allw_amt,
net_pd_amt,
bil_amt,
adr_ln_1_txt,
billing_provider_st_abbr_cd,
prov_typ_nm,
provider_cty_nm,
provider_fst_nm,
provider_lst_nm,
provider_zip_cd,
month_year_id,
providername,
par_non_par_flag,
proc_mod_cd1,
proc_mod_cd2,
proc_mod_cd3,
proc_mod_cd4,
proc_mod_cd5,
common_cpt_mod,
code,
modifier,
proc_mod_cd_concat,
common_cpt_mult_cpt_flag,
common_cpt_mult_unit_flag,
mpin,
bil_prov_npi_nbr,
srvc_prov_npi_nbr,
prov_st_abbr_cd,
allw_amt_per_unit,
last_day_base,
case when speciality_lb_6months is null then mean_amt else speciality_lb_6months end as speciality_lb_6months,
case when state_lb_6months is null then mean_amt else state_lb_6months end as state_lb_6months,
case when Pre6_proc_cd_par_non_par_flag_mean_allw_amt_per_unit is null then mean_amt else Pre6_proc_cd_par_non_par_flag_mean_allw_amt_per_unit end  as cpt_lb_6months
from 
(select
a.*,
b.mean_amt,
c1.Pre6_proc_cd_par_non_par_flag_mean_allw_amt_per_unit
from 
pcr_ss_model_base_table_select1 a 
left join ( select distinct proc_cd,par_non_par_flag,mean_amt from proc_cd_mvi_map1 ) b 
on trim(a.proc_cd)=trim(b.proc_cd)
and 
trim(a.par_non_par_flag)=trim(b.par_non_par_flag)
left join cpt_average c1 
on trim(a.proc_cd)=trim(c1.proc_cd)
and 
trim(a.par_non_par_flag)=trim(c1.par_non_par_flag)
and 
a.last_day_base=c1.last_day
) c
''')


pcr_ss_model_base_table_select_imputed_final_adjusted_allw_amt.createOrReplaceTempView("pcr_ss_model_base_table_select_imputed_final_adjusted_allw_amt")

base_table= spark.sql("select * from pcr_ss_model_base_table_select_imputed_final_adjusted_allw_amt")

base_table.createOrReplaceTempView("base_table")

##########  CREATION OF PROC MODIFIER FEATURE #################
### 1. jOIN BACK PROC MODIFIER LOOKBACK FEATURES FOR ALL 5 PROC MODIFIERS ####
### 2. TAKE MAX OF ALL THE 5 LOOKBACK FEATURES AND CREATE FINAL COLUMNS   ####
##############################################################################

base_table_cpt_join = spark.sql('''
select k.*,greatest(mod1_avg,mod2_avg,mod3_avg,mod4_avg,mod5_avg) as mod_avg from 
(
select a.*,
b.Pre6_proc_cd_par_non_par_flag_mod_mean_allw_amt_per_unit as mod1_avg,
c.Pre6_proc_cd_par_non_par_flag_mod_mean_allw_amt_per_unit as mod2_avg,
d.Pre6_proc_cd_par_non_par_flag_mod_mean_allw_amt_per_unit as mod3_avg,
e.Pre6_proc_cd_par_non_par_flag_mod_mean_allw_amt_per_unit as mod4_avg,
f.Pre6_proc_cd_par_non_par_flag_mod_mean_allw_amt_per_unit as mod5_avg
from 
base_table a 
left join 
cpt_mod_avg_lookback_df b 
on 
trim(a.proc_cd)=trim(b.proc_cd)
and 
trim(a.par_non_par_flag)=trim(b.par_non_par_flag)
and
trim(a.proc_mod_cd1)=trim(b.mod)
and
a.last_day_base=b.last_day
left join 
cpt_mod_avg_lookback_df c 
on 
trim(a.proc_cd)=trim(c.proc_cd)
and 
trim(a.par_non_par_flag)=trim(c.par_non_par_flag)
and
trim(a.proc_mod_cd2)=trim(c.mod)
and
a.last_day_base=c.last_day
left join 
cpt_mod_avg_lookback_df d 
on 
trim(a.proc_cd)=trim(d.proc_cd)
and 
trim(a.par_non_par_flag)=trim(d.par_non_par_flag)
and
trim(a.proc_mod_cd3)=trim(d.mod)
and
a.last_day_base=d.last_day
left join 
cpt_mod_avg_lookback_df e 
on 
trim(a.proc_cd)=trim(e.proc_cd)
and 
trim(a.par_non_par_flag)=trim(e.par_non_par_flag)
and
trim(a.proc_mod_cd4)=trim(e.mod)
and
a.last_day_base=e.last_day
left join 
cpt_mod_avg_lookback_df f 
on 
trim(a.proc_cd)=trim(f.proc_cd)
and 
trim(a.par_non_par_flag)=trim(f.par_non_par_flag)
and
trim(a.proc_mod_cd5)=trim(f.mod)
and
a.last_day_base=f.last_day
) k 
''')

base_table_cpt_join.createOrReplaceTempView("base_table_cpt_join")


print("creating final analytical 3 months data for OOT testing ")

################### MISSING VALUE IMPUTATION FOR PROC MODIFIER FEATURE #######
####   Target variable  : cpt_modifier_lb_6months 			         #########
####   Imputation logic : national average		 			         #########
##############################################################################
pcr_line_lvl_scoring_input = spark.sql('''
select 
a.mbr_sys_id,
a.clm_aud_nbr,
a.cust_seg_sys_id,
a.cust_seg_nbr,
a.mbr_bth_dt,
a.mbr_gdr_cd,
a.mbr_zip_cd,
a.diag_1_cd,
a.diag_2_cd,
a.diag_3_cd,
a.diag_4_cd,
a.icd_ver_cd,
a.proc_cd,
a.prov_tin,
a.prov_prtcp_sts_cd,
a.prov_zip_cd,
a.srvc_prov_catgy_cd,
a.srvc_prov_sys_id,
a.srvc_prov_row_eff_dt,
a.erly_srvc_dt,
a.fst_srvc_dt,
a.clm_pd_dt,
a.adj_srvc_unit_cnt,
a.allw_amt,
a.net_pd_amt,
a.bil_amt,
a.adr_ln_1_txt,
a.billing_provider_st_abbr_cd,
a.prov_typ_nm,
a.provider_cty_nm,
a.provider_fst_nm,
a.provider_lst_nm,
a.provider_zip_cd,
a.month_year_id,
a.providername,
a.par_non_par_flag,
a.proc_mod_cd1,
a.proc_mod_cd2,
a.proc_mod_cd3,
a.proc_mod_cd4,
a.proc_mod_cd5,
a.common_cpt_mod,
a.code,
a.modifier,
a.proc_mod_cd_concat,
a.common_cpt_mult_cpt_flag,
a.common_cpt_mult_unit_flag,
a.mpin,
a.bil_prov_npi_nbr,
a.srvc_prov_npi_nbr,
a.prov_st_abbr_cd,
a.allw_amt_per_unit,
a.last_day_base,
a.cpt_lb_6months,
a.speciality_lb_6months,
a.state_lb_6months,
case when a.mod_avg is null then round(b.proc_cd_par_non_par_flag_mod__mean_allw_amt_per_unit,2) else round(a.mod_avg,2) end as cpt_modifier_lb_6months
from 
base_table_cpt_join a 
left join 
national_cpt_mod_avg b 
on 
trim(a.proc_cd)=trim(b.proc_cd)
and 
trim(a.par_non_par_flag)=trim(b.par_non_par_flag)
and
trim(a.proc_mod_cd1)=trim(b.mod)
''')

pcr_line_lvl_scoring_input.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"pcr_line_lvl_scoring_input.parquet")

print("process completed ")

print(" Import line level scoring data")

pcr_line_lvl_scoring_input = spark.read.parquet(path_parquet+"pcr_line_lvl_scoring_input.parquet")

################# Box Cox Transformations 			  #############################
######    USING THE LAMBDA VALUES GENERATED FROM BOX COX WHILE SCORING        #####
######    allw_amt_per_unit 		: 0.093  			 					  #####
######    cpt_modifier_lb_6months 	: 0.057  			          			  #####
######    state_lb_6months 			: 0.069  						          #####
######    speciality_lb_6months 	: 0.071	
###################################################################################

pcr_line_lvl_scoring_input = pcr_line_lvl_scoring_input.withColumn("allw_amt_per_unit_tranformed",round((pow(col("allw_amt_per_unit"),0.0934786)-1)/0.0934786,2))

pcr_line_lvl_scoring_input = pcr_line_lvl_scoring_input.withColumn("cpt_modifier_lb_6months_transformed",round((pow(col("cpt_modifier_lb_6months"),0.05734906)-1)/0.05734906,2))

pcr_line_lvl_scoring_input = pcr_line_lvl_scoring_input.withColumn("state_lb_6months_tranformed",round((pow(col("state_lb_6months"),0.06914841)-1)/0.06914841,2))

pcr_line_lvl_scoring_input = pcr_line_lvl_scoring_input.withColumn("speciality_lb_6months_tranformed",round((pow(col("speciality_lb_6months"),0.07193741)-1)/0.07193741,2))

pcr_line_lvl_scoring_input = pcr_line_lvl_scoring_input.withColumn("cpt_lb_6months_tranformed",round((pow(col("cpt_lb_6months"),0.06131305)-1)/0.06131305,2))

pcr_line_lvl_scoring_input.createOrReplaceTempView("pcr_line_lvl_scoring_input")

################# ALLOWED AMOUNT PREDICTION #############################
######    USING THE BETA VALUES GENERATED FROM H2O GLM MODEL        #####
######    INTERCEPT 							: -0.4953  			#####
######    cpt_modifier_lb_6months_transformed 	: 0.2548  			#####
######    state_lb_6months_tranformed 			: 0.5479  			#####
######    speciality_lb_6months_tranformed 		: 0.3251 			#####
######    cpt_lb_6months_tranformed             : 0.1289            #####
#########################################################################




pcr_line_lvl_predicted_temp  =spark.sql('''
select *,
round((-0.4953 + 
cpt_modifier_lb_6months_transformed*0.2548 +
cpt_lb_6months_tranformed*0.00001 + 
0.5479*state_lb_6months_tranformed + 
speciality_lb_6months_tranformed*0.3251 ),2) as predicted_allowed_amt_per_unit_trans
from pcr_line_lvl_scoring_input''')

pcr_line_lvl_predicted_temp.createOrReplaceTempView("pcr_line_lvl_predicted_temp")


pcr_line_lvl_predicted = pcr_line_lvl_predicted_temp.withColumn("predicted_allowed_amt_per_unit",pow(2.71828,log(col("predicted_allowed_amt_per_unit_trans")*0.0934786+1)/0.0934786))

pcr_line_lvl_predicted.createOrReplaceTempView("pcr_line_lvl_predicted")


################# ALLOWED AMOUNT EXTRAPLATION #############################
######    EXTRAPOLATION OF ALLOWED AMOUNT PER UNIT                    #####
######    INTO TOTAL ALLOWED AMOUNT USING INVERSE OF REDUCTION LOGIC  #####
###########################################################################

pcr_line_lvl_predicted_1 = spark.sql('''select *,
case when ((common_cpt_mult_unit_flag=1 or common_cpt_mult_cpt_flag=1 ) 
and (proc_mod_cd_concat not like "%50%") 
and (adj_srvc_unit_cnt>1) )
then (0.5*predicted_allowed_amt_per_unit)*(1+adj_srvc_unit_cnt) 
else predicted_allowed_amt_per_unit*adj_srvc_unit_cnt end as predicted_allowed_amt
from pcr_line_lvl_predicted''')


pcr_line_lvl_predicted_1.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"pcr_line_lvl_predicted1.parquet")



print("Scoring completed at time ::")
print(time.ctime())

#################### LOADING LINE LEVEL ALLOWED AMOUNT PREDICTED DATAFRAME INTO MEMORY

path_parquet="/datalake/uhc/ei/pi_ara/kappa/users/ssing339/pcr_model/scoring/"
pcr_line_lvl_predicted = spark.read.parquet(path_parquet+"pcr_line_lvl_predicted1.parquet")

pcr_line_lvl_predicted.createOrReplaceTempView("pcr_line_lvl_predicted")


################# SUSPICION SCORE GENERATION #####################
#######If Residuals have a Normal/Symmetric Distribution
#######1.	Calculate Median of Residuals
#######		a.	MED = Median(Residuals)
#######2.	Calculate Absolute Deviation for each point for the median
#######		a.	MD = Residuals - MED
#######		b.	AMD = abs(Residuals - MED)
#######		c.	One value for each row
#######3.	Calculate Median Absolute Deviation
#######		a.	MAE = Median(AMD)
#######		b.	Single value for whole data
#######4.	Consistency constant = CC = 1.4826 (provided that the Residual is Normally distributed)
#######5.	OUTLIER Identification
#######		a.	Outlier if MD – (1/2/3)*CC*MAE > 0
####################################################################




def suspicious_sheet_fxn(base_table,var_list,std_count_var):
	trans_predicted = var_list[0]
	trans_actual = var_list[1]
	actual = var_list[2]
	predicted = var_list[3]
	std_count=std_count_var
	temp_table = base_table
	temp_table = temp_table.withColumn("resid_trans",col(trans_actual)-col(trans_predicted))
	temp_table = temp_table.withColumn("resid_actual",col(actual)-col(predicted))
	temp_table.createOrReplaceTempView("temp_table")
	temp_table_1 = spark.sql('''select * from temp_table
	cross join (select percentile(resid_trans,0.5) as MED from temp_table) a ''').repartition(500)
	temp_table_1.createOrReplaceTempView("temp_table_1")
	temp_table_1_temp = spark.sql('''select *,(resid_trans-MED) as MD,abs(resid_trans-MED) as AMD from temp_table_1''')
	temp_table_1_temp.createOrReplaceTempView("temp_table_1_temp")
	temp_table_1_temp_1 = spark.sql('''select * from temp_table_1_temp
	cross join (select percentile(abs(AMD),0.5) as mae from temp_table_1_temp) a ''').repartition(500)
	temp_table_1_temp_1.createOrReplaceTempView("temp_table_1_temp_1")
	temp_table_1_1 = temp_table_1_temp_1.withColumn("MAET",col("MD")-lit(std_count)*1.4826*col("mae"))
	temp_table_1_1.createOrReplaceTempView("temp_table_1_1")
	temp_table_1_2=spark.sql('''select a.*,
	case when MAET<0 then "NOT SUSPICIOUS" else "SUSPICIOUS" end as Suspicious_Flag,case when MAET<0 then 0 else 1 end as outlier
	from temp_table_1_1 a ''')
	temp_table_1_2.createOrReplaceTempView("temp_table_1_2")
	Prov_lvl_stats =spark.sql('''
	select b.*,
	b.Frequency_term*b.severity+0.0000001 as Suspicion_score
	from
	(select a.*,
	a.Pos_outlier_count/a.Total_visit_count as Frequency_term,
	case when Total_allwd_amount=0 then 0.0000001 else a.error_amt/a.Total_allwd_amount end as severity
	from
	(select mpin,proc_cd,
	count(*) as Total_visit_count,
	sum (case when outlier=1 and resid_trans>0 then 1 else 0 end) as Pos_outlier_count,
	sum(case when outlier=1 and resid_trans>0 then round('''+actual+''',3) else 0 end) as Total_allwd_amount,
	sum (case when outlier=1 and resid_trans>0 then round(resid_actual,3) else 0 end) as error_amt
	from temp_table_1_2
	group by mpin,proc_cd) a) b where b.Pos_outlier_count>0''')
	return Prov_lvl_stats,temp_table_1_2


base_table=pcr_line_lvl_predicted
var_list=["predicted_allowed_amt_per_unit_trans","allw_amt_per_unit_tranformed","allw_amt","predicted_allowed_amt"]

##################fUNCTION CALL TO THE SUSPICION SCORE GENERATOR UDF ###################
	
Prov_lvl_stats,line_lvl_suspicous_tagged_df=suspicious_sheet_fxn(base_table,var_list,3)

Prov_lvl_stats.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"Prov_lvl_stats.parquet")

line_lvl_suspicous_tagged_df.write.mode("overwrite").format("parquet").option("compression", "snappy").save(path_parquet+"line_lvl_suspicous_tagged_df.parquet")



line_lvl_suspicous_tagged_df= spark.read.parquet(path_parquet+"line_lvl_suspicous_tagged_df.parquet")

line_lvl_suspicous_tagged_df.createOrReplaceTempView("line_lvl_suspicous_tagged_df")

Prov_lvl_stats= spark.read.parquet(path_parquet+"Prov_lvl_stats.parquet")
Prov_lvl_stats.createOrReplaceTempView("Prov_lvl_stats")

scoring_data = Prov_lvl_stats
training_data = spark.sql("select * from ssing339_pcr.Prov_lvl_stats3")
from sklearn.preprocessing.data import QuantileTransformer
import numpy as np
import pandas as pd
def suspscore_normalize(training_data,scoring_data):
    base_table1=training_data
    base_table = scoring_data
    base_table.createOrReplaceTempView("base_table")
    base_table.createOrReplaceTempView("base_table1")
    scores_df = spark.sql("select case when suspicion_score is null then 0.0001 else suspicion_score end as score from training_data")
    df = scores_df.select("score").toPandas()
    QuantileTransformer_1 = QuantileTransformer(output_distribution='normal', random_state=1234567890)
    Continuous=df
    Continuous1 = pd.DataFrame(QuantileTransformer_1.fit_transform(np.array(Continuous).reshape(-1, Continuous.shape[1])))
    df["normal_score"]=Continuous1
    s_min=df["normal_score"].min()
    s_max=df["normal_score"].max()
    Continuous2=pd.DataFrame(df1["score"])
    scores_df1 = spark.sql("select mpin,proc_cd,suspicion_score,case when suspicion_score is null then 0.0001 else suspicion_score end as score from base_table")
    df1 = scores_df1.select("mpin","proc_cd","score","suspicion_score").toPandas()
    Continuous2=df1["score"]
    df2=QuantileTransformer_1.transform(np.array(Continuous2).reshape(-1, Continuous2.shape[1]))
    df["normal_score"]=df2
    df1["score_scaled"]=((df1["normal_score"]-s_min)/(s_max-s_min))*1000
    final_df=spark.createDataFrame(df1[['mpin','proc_cd','score_scaled']])
    return final_df

output_df = suspscore_normalize(training_data,scoring_data)

output_df.createDataFrame("output_df")

final_df.createOrReplaceTempView("final_df")
spark.sql('''drop table ssing339_pcr.Prov_lvl_stats3_normal''')
spark.sql('''create table ssing339_pcr.Prov_lvl_stats3_normal as select a.score_scaled,b.* from Prov_lvl_stats3  b  
left join final_df a
on 
trim(a.mpin)=trim(b.mpin) and trim(a.proc_cd)=trim(b.proc_cd)
''')




test = spark.sql('''
select substr(clm_aud_nbr,1,10) as clm_aud_nbr, mpin,  max(flag) as flag, sum(allw_amt) as allw_amt
from
(select a.*, (case when b.proc_cd is null then 0 else 1 end) as flag
from
(select clm_aud_nbr,  proc_cd, mpin, allw_amt
from ssing339_pcr.line_lvl_suspicous_tagged_df3) as a
left join 
(select distinct mpin, proc_cd
from ssing339_pcr.Prov_lvl_stats3_normal 
where suspiciuos_lines_cnt >= 1
and score_scaled >= 0.7
) as b
on a.mpin=b.mpin
and a.proc_cd=b.proc_cd) as c
group by substr(clm_aud_nbr,1,10) , mpin''')

test.createOrReplaceTempView("test")

mpin_list=spark.sql'''
select mpin, count(distinct substr(clm_aud_nbr,1,10)) as clm_cnt, avg(allw_amt) as avg_allw_amt_clm
from test
where flag = 1
group by mpin''')

mpin_list.createOrReplaceTempView("mpin_list")

spark.sql("drop table ssing339_pcr.pcr_eni_raw_leads_7")

spark.sql("drop table ssing339_pcr.pcr_eni_raw_leads_7")
spark.sql('''create table ssing339_pcr.pcr_eni_raw_leads_7 as 
select a.mpin,b.proc_cd from 
(
select * from mpin_list where avg_allw_amt_clm>=1000 and clm_cnt>=5 
) a 
left join 
(
select distinct mpin, proc_cd
from ssing339_pcr.Prov_lvl_stats3_normal 
where suspiciuos_lines_cnt >= 1
and score_scaled >= 0.7
) as b
on 
a.mpin=b.mpin''')



