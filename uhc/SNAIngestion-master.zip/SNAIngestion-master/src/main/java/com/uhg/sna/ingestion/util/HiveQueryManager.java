package com.uhg.sna.ingestion.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class HiveQueryManager {

	//~ Static fields/initializers ---------------------------------------------

	private static HiveQueryManager instance = null;
	//private static ILogger logger = LogManager.getInstance().getLogger();

	//Database Definitions - XML Names
	private static String DATABASE = "database";
	private static String DBMANAGER = "dbManager";
	//private static String IDENTITY_SQL = "identity_sql";

	//Class Definitions - XML Names
	private static String CLASS = "class";
	private static String STATEMENT = "statement";
	private static String NAME = "name";


	//~ Instance fields --------------------------------------------------------

	private Hashtable<String, ClassDescriptor> classDescriptors;


	//~ Constructors -----------------------------------------------------------

  /**
   * Creates a new PersistenceManager object.
   */
  protected HiveQueryManager() {}

	//~ Methods ----------------------------------------------------------------

	/**
	 * Returns the instance. 
	 *
	 * @return PersistenceManager
	 */
	public static HiveQueryManager getInstance() {
		if (instance == null) {
			instance = new HiveQueryManager();
		}
		return instance;
	}
	public ClassDescriptor getDescriptor(String className) {
		return (ClassDescriptor) classDescriptors.get(className);
	}

	/**
	 * Replaces the owner attribute to the right qualifies
	 * depending upon the database manager.
	 *
	 * @param sql that should be prefixed with the owner
	 * @param owner string that should be set
	 *
	 * @return complete SQL
	 */
	public String replaceOwner(String sql, String owner) {
		Object[] vals = { owner };
		return MessageFormat.format(sql, vals);
	}

	public void start(Properties props) throws Exception {
		Boolean usePersistence = new Boolean(props.getProperty("config.attribute.use.persistence"));

    if (usePersistence.booleanValue()) {
      try {
        loadPersistenceProperties(props);
        // logger.info(this, "hive query Manager started successfully");
      } catch (java.io.IOException ie) {
        ie.printStackTrace();
        throw new Exception("hivequerymanager  got a IO Exception");
      } catch (Exception e) {
        e.printStackTrace();
        throw new Exception(" hivequerymanager exception");
      }
    }
  }

  public void stop() {}

  private ClassDescriptor buildClassDescriptor(Element aClass, String owner) throws Exception {
    // First lets create the class descriptor
    ClassDescriptor aDesc = new ClassDescriptor();

		//Get the attributes of the node
		NamedNodeMap map = aClass.getAttributes();
		String className = map.getNamedItem(NAME).getNodeValue();

		if (classDescriptors != null) {
			ClassDescriptor _desc = (ClassDescriptor) classDescriptors.get(className);

			if (_desc != null) {
				aDesc = _desc;
			}
		}

		NodeList statements = aClass.getElementsByTagName(STATEMENT);

		for (int i = 0; i < statements.getLength(); i++) {
			Element statement = (Element) statements.item(i);
			setStatement(statement, aDesc, owner);
		}

		aDesc.setClassName(className);
		return aDesc;
	}

  private Document fileToXmlDoc(String fileName)
      throws ParserConfigurationException, IOException, org.xml.sax.SAXException {
    Configuration conf = new Configuration();
    InputStream is = null;
    Document xmlDoc = null;
    try {
      FileSystem fs = FileSystem.get(conf);
      DocumentBuilderFactory Factory = DocumentBuilderFactory.newInstance();
      Factory.setValidating(false);
      DocumentBuilder builder = Factory.newDocumentBuilder();
      // File configFile = new File(fileName);
      // InputStream is = new FileInputStream(configFile);
      is = fs.open(new Path(fileName));
      xmlDoc = builder.parse(is);
    } finally {
      is.close();
    }


    return xmlDoc;
  }

	private void loadDescriptors(String filename) throws Exception {
		try {
			Document xmlDoc = fileToXmlDoc(filename);
			System.out.println("File Name "+ filename);
			//Create the hashmap to store the descriptors
			classDescriptors = new Hashtable<String, ClassDescriptor>();

			//Get the database nodes first
			NodeList databases = xmlDoc.getElementsByTagName(DATABASE);
			int noOfDbEntries = databases.getLength();
System.out.println("noOfDbEntries"+noOfDbEntries);
			for (int i = 0; i < noOfDbEntries; i++) {
				Element database = (Element) databases.item(i);
				NamedNodeMap databaseAttrs = database.getAttributes();

        String dbManager = databaseAttrs.getNamedItem(DBMANAGER).getNodeValue();
        String owner = "owner";

				//Get the class descriptors within the database
				if (database.hasChildNodes()) {
					NodeList classes = database.getElementsByTagName(CLASS);
					
					int noOfClassEntries = classes.getLength();
					System.out.println("noOfClassEntries"+noOfClassEntries);
					for (int j = 0; j < noOfClassEntries; j++) {

            Element aclass = (Element) classes.item(j);
            ClassDescriptor aDesc = buildClassDescriptor(aclass, owner);
            aDesc.setDbManager(dbManager);
            aDesc.setOwner(owner);

						classDescriptors.put(aDesc.getClassName(), aDesc);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}

  private void loadPersistenceProperties(Properties props) throws java.io.IOException, Exception {
    classDescriptors = new Hashtable<String, ClassDescriptor>(50);
    loadDescriptors(props.getProperty("Spark.Mapping.File"));
  }

  private void setStatement(Element statement, ClassDescriptor aDesc, String owner) {
    Node sql = statement.getFirstChild();
    NamedNodeMap attrs = statement.getAttributes();
    String statementType = attrs.getNamedItem(NAME).getNodeValue();
    String statementString = sql.getNodeValue();
    statementString = replaceOwner(statementString, owner);
    aDesc.setSQL(statementType, statementString);
  }
}


