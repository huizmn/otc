package com.uhg.sna.ingestion.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.security.InvalidParameterException;
import java.text.MessageFormat;
import java.util.Properties;

public class SNAIngestConfiguration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9159954484215017307L;

	public class Configuration extends Properties implements Serializable {
		private static final long serialVersionUID = -2239478815205674380L;

		@Override
		public String getProperty(String key) {
			String value = super.getProperty(key);
			if (value == null) {
				throw new InvalidParameterException(MessageFormat.format(
						"Value missing for key {0}!", key));
			}
			return value;
		}

	}

	public SNAIngestConfiguration(String filePath) throws IOException {
		super();
		this.filePath = filePath;
		Configuration prop = new Configuration();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(new File(filePath));
			prop.load(inputStream);
		} finally {
			if (inputStream != null)
				inputStream.close();
		}
		for (SNAIngestKeys key : SNAIngestKeys.values()) {
			System.out.println("Key:" + key.toString() + "  Value:"
					+ (String) prop.getProperty(key.getValue()));
		}
	}

	private String filePath;



	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	Properties properties = new Properties();

	public String get(SNAIngestKeys key) throws FileNotFoundException, IOException {
		properties.load(new FileInputStream(filePath));
		return properties.getProperty(key.getValue());
	}

	// For test
	public static void main(String[] args) throws IOException {

		// String in =
		// "C:/Users/vamdiyal/git/triage/src/main/resources/log4j.properties";
		// FileInputStream fis = new FileInputStream(in);
		//
		// PropertyConfigurator.configure(fis);
		//
		// logger.debug("printing info");
		//
		// System.exit(0);

//		System.out.println(TriageKeys.MAPRDB_CLAIMRESULT);
//		SNATriageConfiguration triageConfig = new SNATriageConfiguration(
//				"C:/Users/vamdiyal/git/triage/src/main/resources/triageORC.properties");
//		System.out.println(triageConfig.get(TriageKeys.FINAL_REC_COLUMN));

		// // Map<TriageKeys, String> propertiesMap = new
		// TriageOrcConfiguration(
		// // "test").getPropMap();
		//
		// System.out.println(propertiesMap.get(TriageKeys.MAPRDB_CLAIMRESULT));
		//
		// System.out.println(TriageKeys.BATCHDELIM);
		//
		// for (TriageKeys keys : propertiesMap.keySet()) {
		// System.out.println(keys.toString());
		// System.out.println(propertiesMap.get(keys));
	}

	// for (String s : triagConfig.getPropMap().keySet()) {
	// System.out.println(s);
	// System.out.println(triagConfig.getPropMap().get(s));
	// }
	// System.out.println(triagConfig.getPropMap().get();

}
