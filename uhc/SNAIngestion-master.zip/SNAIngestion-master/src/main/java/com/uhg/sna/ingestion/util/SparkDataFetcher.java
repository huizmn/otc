package com.uhg.sna.ingestion.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.hive.HiveContext;

public class SparkDataFetcher {

	/**
	 * @return
	 * @throws Exception
	 */
	public static void runQueryAndGetResult(SparkSession sqlCtx, int noOfQueries, Logger logger, String dtfmt,
			String delimiter) throws Exception {
		int retVal = 0;
		List<String> listOfQueries = new ArrayList<String>();
		
		ClassDescriptor desc = new ClassDescriptor() ;
		logger.info("desc.getClassName()" +desc.getClassName());
		
			
			desc = HiveQueryManager.getInstance().getDescriptor("org.uhc.sherlock.sna.implmentation");
			int i = 1;
			for (; i <= noOfQueries; i++) {
				listOfQueries.add(desc.getSQL("query" + i));

			}
			
			i = 1;
			for (String query : listOfQueries) {

				try {
					query = query.replace(":1", dtfmt).replace(":2", delimiter);
					logger.debug("================================================");
					logger.debug("Query from xml: " + query);
					logger.debug("================================================");
					sqlCtx.sql(query);
				} catch (Exception e) {
					logger.error(
							"Failed to execute query no :" + (i) + "\n" + e.getMessage() + "return value=" + retVal+ "\nquery"+query);
					///throw e;
				}
				i++;
			}

		
	}

}
