package com.uhg.sna.ingestion.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.metastore.api.NoSuchObjectException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import com.uhc.sherlock.snaJobConnector.dbops.SNAJobProcessState;
import com.uhg.sna.ingestion.util.HiveQueryManager;
import com.uhg.sna.ingestion.util.SNAIngestConfiguration;
import com.uhg.sna.ingestion.util.SNAIngestKeys;
import com.uhg.sna.ingestion.util.SparkDataFetcher;
import com.uhg.sna.ingestion.util.Util;

public class LinkageFileGenerator {
	static Logger logger = Logger.getLogger("file");

	public static void main(String[] args)
			throws IOException, NoSuchObjectException, ClassNotFoundException, SQLException {

		SNAIngestConfiguration snaIngestConfiguration = new SNAIngestConfiguration(args[0]);

		PropertyConfigurator.configure(snaIngestConfiguration.get(SNAIngestKeys.LOGFILE));

		String jobId = SNAJobProcessState.snaIngStarted();

		com.uhc.sherlock.jobConnector.common.Utils.send(snaIngestConfiguration.get(SNAIngestKeys.MAIL_FRM_ADD),
				snaIngestConfiguration.get(SNAIngestKeys.MAIL_TO_ADD),
				snaIngestConfiguration.get(SNAIngestKeys.MAIL_SUBJ_LN),
				snaIngestConfiguration.get(SNAIngestKeys.MAIL_MSG_CNT) + " " + jobId);

		DateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
		Long startTime = System.currentTimeMillis();

		SparkSession sqlCtx = new org.apache.spark.sql.SparkSession.Builder().enableHiveSupport().getOrCreate();
		SparkContext sc = sqlCtx.sparkContext();

		try {
			logger.info("JOB_ID--->"+jobId);
			logger.info("Starting PROVIDER LINKAGE application");
			Properties props = new Properties();
			props.setProperty("config.attribute.use.persistence", "true");
			props.setProperty("config.attribute.persistence", "/descriptor");
			
			props.setProperty("Spark.Mapping.File",
					"maprfs:/datalake/uhc/ei/pi_ara/sherlock_prod/applications/SNAIngestion/config/SparkMapSql.xml");
			HiveQueryManager.getInstance().start(props);

			sqlCtx.sql("set mapreduce.input.fileinputformat.split.maxsize=536870912");
			sqlCtx.sql("set mapreduce.input.fileinputformat.split.minsize=268435456");
			sqlCtx.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat");
			try {
				sqlCtx.sql("drop table if exists sna_dm.837p_180_col");
			} catch (Exception e) {
				logger.error("Table sna_dm.837p_180_col does not exist");
			}
			
			Dataset<Row> df = sqlCtx.sql(
					"select sherlock_claim_id,bill_prov_tin billing_provider_tin,bill_prov_npi billing_provider_npi, sherlock_claim_id cosmos_clm_aud_nbr, first_serv_dt first_service_date, last_serv_dt last_service_date,  line_item_charge_amount, patient_dob, patient_l_nm patient_l_name, patient_f_nm patient_f_name, patient_ind_rel_cd patient_relation_to_subscriber, rend_prov_npi Renderring_Provider_NPI, subs_dob subscriber_dob,  subs_f_name subscriber_f_name, subs_id subscriber_id,  pl_srvc_cd place_of_service_code, proc_mod1 procedure_modifier1,  proc_mod2 procedure_modifier2, proc_mod3 procedure_modifier3, proc_mod4 procedure_modifier4, rend_prov_taxonomy_cd billing_provider_taxonomy_code, patient_death_date,  subs_ssn subscriber_ssn , batch_run_dt input_file_dt ,  rend_prov_npi srvc_mpin from sherlock.837p_180  where batch_run_dt > regexp_replace(date_sub(CURRENT_DATE,180),'-','') and pl_srvc_cd <> 21 and (CASE WHEN trim(proc_mod1) = '26' THEN 1 ELSE 0 END) + (CASE WHEN trim(proc_mod2) = '26' THEN 1 ELSE 0 END) + (CASE WHEN trim(proc_mod3) = '26' THEN 1 ELSE 0 END) + (CASE WHEN trim(proc_mod4) = '26' THEN 1 ELSE 0 END)=0");
			df = df.coalesce(48);
			
			df.createOrReplaceTempView("837p_180_col");
			sqlCtx.catalog().cacheTable("837p_180_col");

			logger.info("Table created 837p_180_col ");
			String dtfmt = dateformat.format(new Date());
			
			String delimiter = snaIngestConfiguration.get(SNAIngestKeys.FINAL_TABLE_DELIMITER);

			SparkDataFetcher.runQueryAndGetResult(sqlCtx, 53, logger, dtfmt, delimiter);
			// sqlCtx.catalog().uncacheTable("837p_180_col");
			logger.info("Extracting sna_dm.MRProviderList_Sotera files");

			Util.writeToResultFile("sna_dm", "MRProviderList_Sotera", sc.hadoopConfiguration(),
					new Path(snaIngestConfiguration.get(SNAIngestKeys.PROVIDER_DESTFILE)), delimiter);

			logger.info("Extraction done");
			logger.info("Extracting sna_dm.MRNetwork_Sotera files");
			Util.writeToResultFile("sna_dm", "MRNetwork_Sotera", sc.hadoopConfiguration(),
					new Path(snaIngestConfiguration.get(SNAIngestKeys.NETWORK_DESTFILE)), delimiter);

			logger.info("Extraction done");
			Util.writeToResultFile("sna_dm", "deidentified_prov_map" + dtfmt, sc.hadoopConfiguration(),
					new Path(snaIngestConfiguration.get(SNAIngestKeys.DEIDENT_PROV_MAP)), delimiter);

			logger.info("Extraction done");
			Long endTime = System.currentTimeMillis();
			Long elapsedTime = endTime - startTime;

			logger.info("Total time elapsed to completed the Provider Linkage Process-->" + elapsedTime / 1000 + "s");

			SNAJobProcessState.snaIngCompleted(jobId);

		} catch (Exception e) {
			logger.error("Aborting SNA Ingestion for Batch-->" + jobId + ":" + e.getMessage());
			SNAJobProcessState.snaIngAborted(jobId, e.getMessage());
			e.printStackTrace();
			sqlCtx.stop();
			Runtime.getRuntime().exit(-1);
		} finally {
			if (!sqlCtx.sparkContext().isStopped())
				sqlCtx.sparkContext().stop();

		}

	}
}
