package com.uhg.sna.ingestion.util;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.metastore.HiveMetaStoreClient;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import groovy.json.StringEscapeUtils;

public class Util {

	private static final String SPACE = " ";
	static Logger logger = Logger.getLogger("file");

	public static void writeToResultFile(String db, String tableName, Configuration conf, Path destFile,
			String delimChar) throws IOException, TException {
		FileSystem fs = FileSystem.get(conf);
		if (fs.exists(destFile))
			fs.delete(destFile, true);

		// HiveMetastore Client is used to retrieve table schema and the part
		// files in the table to merge them into 1
		HiveMetaStoreClient client = new HiveMetaStoreClient(new HiveConf());
		StringBuilder schema = new StringBuilder();
		String delim = StringEscapeUtils.unescapeJava(delimChar);
		String DELIM = "";
		for (FieldSchema fSchema : client.getFields(db, tableName)) {
			schema.append(DELIM);
			schema.append(fSchema.getName());
			DELIM = delim;
		}
		String srcDir = client.getTable(db, tableName).getSd().getLocation();
		FSDataOutputStream out = fs.create(destFile);
//		FsShellPermissions fperm = new FsShellPermissions();
//		fperm.
		fs.setPermission(destFile, FsPermission.valueOf("-rwxrwxr--"));
		
		if (schema.length() != 0) {
			out.write((schema.toString() + "\n").getBytes("UTF-8"));
		}
		try {
			for (FileStatus fileStatus : fs.listStatus(new Path(srcDir), new PathFilter() {
				public boolean accept(Path file) {
					return file.getName().startsWith("part");
				}
			})) {
				if (!fileStatus.isDirectory()) {
					FSDataInputStream in = fs.open(fileStatus.getPath());
					try {
						IOUtils.copyBytes(in, out, conf, false);
					} finally {
						in.close();
					}
				}
			}
		} finally {
			out.close();
		}
	}

	public static int runOSCommand(List<String> arguments, String logFile) throws Exception {
		StringBuilder sb = new StringBuilder();
		for (String s : arguments) {
			sb.append(s);
			sb.append("\t");
		}
		ProcessBuilder pb = new ProcessBuilder(arguments);
		// File log = new File(logFile);
		pb.redirectErrorStream(true);
		pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);// Redirect.appendTo(log));
		int rtrnValue = pb.start().waitFor();
		if (rtrnValue != 0)
			throw new Exception("Error running command" + StringUtils.join(arguments, SPACE));
		logger.info("Completed command" + sb.toString());
		return rtrnValue;

	}

}
