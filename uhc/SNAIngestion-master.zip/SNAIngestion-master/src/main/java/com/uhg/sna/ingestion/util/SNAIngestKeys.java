package com.uhg.sna.ingestion.util;
//

public enum SNAIngestKeys {
	LOGFILE("sna.ingest.log4jPath"), NETWORK_DESTFILE(
			"sna.ingest.networkDestinationFile"), PROVIDER_DESTFILE(
			"sna.ingest.providerDesintationFile"), FINAL_TABLE_DELIMITER(
			"sna.ingest.finalTableDelimiter"),
			DEIDENT_PROV_MAP("sna.ingest.deidentProvFile"),
			MAIL_FRM_ADD("sna.ingest.frmAdd"),
			MAIL_TO_ADD("sna.ingest.toAdd"),
			MAIL_SUBJ_LN("sna.ingest.subjLn"),
			MAIL_MSG_CNT("sna.ingest.msgCnt");
			

	private String value;

	SNAIngestKeys(String in_text) {
		value = in_text;
	}

	public String getValue() {
		return value;
	}

}
