package com.uhg.sna.ingestion.util;
import java.util.HashMap;

/**
 * ClassDescriptor stores the statements in the hivemap.xml 
 * and is accessble from the PersistenceManager instance using
 * the class name as the key.
 * 
 * */

public class ClassDescriptor {
	

    //~ Static fields/initializers ---------------------------------------------

    private static String SELECT = "select";
    private static String INSERT = "insert";
    private static String UPDATE = "update";
    private static String DELETE = "delete";

    //~ Instance fields --------------------------------------------------------

    private HashMap<String, String> statements = new HashMap<String, String>(); //maps to the query parameters
    private String className;
    private String dbManager;
   
    private String owner;

    //~ Constructors -----------------------------------------------------------

    /**
     * Creates a new ClassDescriptor object.
     */
    public ClassDescriptor() {
    }

    //~ Methods ----------------------------------------------------------------

    /**
     * Sets the className
     *
     * @param className The className to set
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     * Gets the className
     *
     * @return Returns a String
     */
    public String getClassName() {
        return className;
    }

    /**
     * Sets the dbManager
     *
     * @param dbManager The dbManager to set
     */
    public void setDbManager(String dbManager) {
        this.dbManager = dbManager;
    }

    /**
     * Gets the dbManager
     *
     * @return Returns a String
     */
    public String getDbManager() {
        return dbManager;
    }

    /**
     * Sets the deleteSQL
     *
     * @param deleteSQL The deleteSQL to set
     */
    public void setDeleteSQL(String deleteSQL) {
        statements.put(DELETE, deleteSQL);
    }

    /**
     * Gets the deleteSQL
     *
     * @return Returns a String
     */
    public String getDeleteSQL() {
        return (String) statements.get(DELETE);
    }

    
    /**
     * Sets the insertSQL
     *
     * @param insertSQL The insertSQL to set
     */
    public void setInsertSQL(String insertSQL) {
        statements.put(INSERT, insertSQL);
    }

    /**
     * Gets the insertSQL
     *
     * @return Returns a String
     */
    public String getInsertSQL() {
        return (String) statements.get(INSERT);
    }

    /**
     * Sets the owner
     *
     * @param owner The owner to set
     */
    public void setOwner(String owner) {
        if (owner == null) {
            owner = "HiveADMIN";
        }

        this.owner = owner;
    }

    /**
     * Gets the owner
     *
     * @return Returns a String
     */
    public String getOwner() {
        return owner;
    }


    /**
     * Sets the sql to the hash map keyed in with the
     * name
     *
     * @param name of the sql
     * @param sql statement
     */
    public void setSQL(String name, String sql) {
        if (name.equalsIgnoreCase(SELECT)) {
            setSelectSQL(sql);
        } else if (name.equalsIgnoreCase(INSERT)) {
            setInsertSQL(sql);
        } else if (name.equalsIgnoreCase(UPDATE)) {
            setUpdateSQL(sql);
        } else if (name.equalsIgnoreCase(DELETE)) {
            setDeleteSQL(sql);
        } else {
            statements.put(name.toUpperCase(), sql);
        }
    }

    /**
     * Returns the SQL corresponding to the key
     *
     * @param name of the SQL. Ex. insertSQL, selectCPMProviders
     *
     * @return SQL Statement
     */
    public String getSQL(String name) {
        return (String) statements.get(name.toUpperCase());
    }

    /**
     * Sets the selectSQL
     *
     * @param selectSQL The selectSQL to set
     */
    public void setSelectSQL(String selectSQL) {
        statements.put(SELECT, selectSQL);
    }

    /**
     * Gets the selectSQL
     *
     * @return Returns a String
     */
    public String getSelectSQL() {
        return (String) statements.get(SELECT);
    }

    /**
     * Sets the updateSQL
     *
     * @param updateSQL The updateSQL to set
     */
    public void setUpdateSQL(String updateSQL) {
        statements.put(UPDATE, updateSQL);
    }

    /**
     * Gets the updateSQL
     *
     * @return Returns a String
     */
    public String getUpdateSQL() {
        return (String) statements.get(UPDATE);
    }
}
