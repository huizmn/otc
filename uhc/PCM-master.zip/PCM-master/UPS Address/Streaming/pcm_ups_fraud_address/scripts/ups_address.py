import os
import pyspark
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.types import DoubleType
from pyspark import SparkContext 
import os,sys
from pyspark.sql import SparkSession
import ConfigParser
import pyspark
import datetime
from datetime import date
from pyspark.sql.functions import udf
from pyspark.sql.functions import levenshtein
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from dateutil.relativedelta import relativedelta
from datetime import date, timedelta
from pyspark.sql.functions import lower,upper,col,desc,when,datediff,sort_array,regexp_replace,col,regexp_extract
from time import gmtime, strftime
from pyspark.sql import SQLContext
from pyspark.sql.functions import lit
import requests

mail_url = "http://apvrp20338:3054/sendemail"
streaming_status_url = "http://apvrp31352:3051/UpdateApplicationStatus"
stop_json = {"ApplicationID":"161","Status":"Stop","UserID":"msing209" }
fromAddr = "No_reply@uhc.com"
toAddr = "manjot_singh@optum.com"
mail_subject = "Error in ups streaming"



def email_params(subject,body):
    params = {
        "from_addr":fromAddr,  
	"to_addr":toAddr, 
	"subject":subject, 
	"body": body
    }
    return params


def stop_streaming() :
	portfolio_r = requests.post(streaming_status_url,json=stop_json)
	spark.stop()



sc = SparkContext("local", "First App")
#spark = SQLContext(sc)

spark = SparkSession \
    .builder \
    .config("spark.port.maxRetries", 20) \
    .appName(sys.argv[1]).enableHiveSupport() \
    .getOrCreate()



import os,sys

print(sys.argv[1])
print(sys.argv[2])

print(sys.argv[3])
print(sys.argv[4])
print(sys.argv[5])
print(sys.argv[6])
print(sys.argv[7])
print(sys.argv[8])
print(sys.argv[9])
print(sys.argv[10])
print(sys.argv[11])

print(sys.argv[12])
print(sys.argv[13])
print(sys.argv[14])
print(sys.argv[15])
print(sys.argv[16])
print(sys.argv[17])
today_dt = date.today().strftime ("%Y%m%d")
config_path = sys.argv[12]

start = datetime.datetime.now().replace(microsecond=0)

##################################################  Read Configurations  ################################################################################################
print("config: ", config_path)
configParser = ConfigParser.RawConfigParser()
configFilePath = config_path
print("Base project config path: ", configFilePath)
configParser.read(configFilePath)
levenshtein_threshold = configParser.get('file', 'levenshtein_threshold')
reg_patterns =  configParser.get('file', 'reg_patterns')
reg_patterns = reg_patterns.split(",")
tax_excl = configParser.get('file', 'tax_excl')


print("batch Id : ",sys.argv[25])
batchid =  str(sys.argv[25])

Batch_dt = batchid[0:8]
print("Batch date: ",Batch_dt)


try:
	#query = """select * from pi_prod.837p_clm_analytic_data where  trim(clm_freq_type_code) = 1 and batch_run_dt>'201908' and batch_run_dt < '201909' """
	query = """select * from pi_prod.837p_clm_analytic_data where  trim(clm_freq_type_code) = 1 and batchid ='"""+str(batchid)+"""'"""
	df = spark.sql(query)
	if(int(df.count()) < 1):
		print("###################### No Data for batchid ######################")
		print(batchid)
		print("##################################################################")
		exit()
	df.createOrReplaceTempView("837_Data")

	query = """ 
	select  srk_clm_id,batchid,
	(case when trim(cl_rend_prov_npi)!='' then cl_rend_prov_npi 
	when trim(cl_rend_prov_npi)='' and trim(clm_rend_prov_npi)='' then clm_bill_prov_npi 
	when trim(cl_rend_prov_npi)='' then clm_rend_prov_npi end) as prov_npi,
	(case when trim(cl_facility_addr)!='' then cl_facility_addr 
	when trim(cl_facility_addr)='' and trim(clm_facility_addr)='' then clm_bill_prov_addr 
	when trim(cl_facility_addr)='' then clm_facility_addr end) as rendering_addr,
	(case when trim(cl_facility_zip)!='' then cl_facility_zip 
	when trim(cl_facility_zip)='' and trim(clm_facility_zip)='' then clm_bill_prov_zip 
	when trim(cl_facility_zip)='' then clm_facility_zip end) as rendering_zip
	from 837_Data where batchid = '"""+str(batchid)+"""' and trim(cl_facility_addr) != ''"""


	print("query : ", query)
	Data_837 = spark.sql(query)
	#Data_837 = Data_837.cache()
	print("caching initial")
	Data_837.createOrReplaceTempView("Data_837")
	###############################################  Function utilities #############################################################################################################  

	def address_regex(text):	
		text = text.upper()
		for rep in reg_patterns:
			reg_split = rep.split("/")
			text = text.replace(reg_split[0].replace("\"",""), reg_split[1].replace("\"",""))
		return text

	regex_match = udf(address_regex)

	########################################  Removing special characters, double spaces,upper, Abbreviations  ########################################  

	Data_837 = Data_837.select('*', (upper(regexp_replace('rendering_addr', "[^a-zA-Z0-9\\s]", "")).alias('rendering_addr_cln')))
	Data_837 = Data_837.withColumn('rendering_addr_cln',regex_match(Data_837['rendering_addr_cln']))
	print("regex")

	########################################  Identifying complete string by excluding 1st & 2nd words ########################################  


	Data_837 = Data_837.select('*', F.split('rendering_addr_cln', '\\s+').alias('r_add'))
	#maxCodes = Data_837.agg(F.max(F.size('r_add'))).first()[0]
	maxCodes = 15

	print("##########################  max codes #######################")
	print(maxCodes)

	Data_837 =Data_837.select('*', *[F.col('r_add').getItem(i).alias('r_add'+str(i+1)) for i in range(maxCodes)])

	na_dict = {}
	for c in range(maxCodes):
		co = "r_add"+ str(c+1)
		na_dict[co] = ""
	Data_837 = Data_837.na.fill(na_dict)


	col_list = ["r_add"+ str(c+1) for c in range(2,maxCodes)]  # 3 to 14
	for c in col_list[:-1]:
		Data_837 = Data_837.withColumn(c, F.concat(F.col(c), F.lit(" ")))
	Data_837 = Data_837.withColumn('r_Address_part3',F.concat(*col_list))
	print("loops for max codes")

	######################################## Selecting the required columns only-till here, address column has been split into 3 parts r_add1, r_add2, r_address_part3 ######################################## 

	Data_837_new = Data_837.select(['prov_npi','srk_clm_id','batchid',
	 'rendering_addr',
	 'rendering_zip',
	 'rendering_addr_cln',
	 'r_add1',
	 'r_add2',
	 'r_Address_part3'])


	######################################## Remove numerical digits from string identified ################################################################### 

	Data_837_new = Data_837_new.select('*',regexp_replace('r_Address_part3', '[0-9]','').alias('r_Address_part3_cln'))

	Data_837_new = Data_837_new.withColumn('r_Address_part3_cln', regexp_replace('r_Address_part3_cln', '  ', ''))



	Data_837_new = Data_837_new.select('*',regexp_replace('r_Address_part3', '[^0-9]','').alias('r_Address_part3_num_cln'))
	Data_837_new = Data_837_new.withColumn('r_Address_part3_num_cln', regexp_replace('r_Address_part3_num_cln', '  ', ''))




	######################################## Remove white spaces from string identified ################################################################################  
	def remove_all_whitespace(col):
		return F.regexp_replace(col, "\\s+", "")

	Data_837_new = Data_837_new.select("*").withColumn('r_Address_part3_cln',remove_all_whitespace(Data_837_new.r_Address_part3_cln)).withColumn('r_Address_part3_num_cln',remove_all_whitespace(Data_837_new.r_Address_part3_num_cln))

	print("select generator")

	for c_name in Data_837_new.columns:
		Data_837_new = Data_837_new.withColumn(c_name, F.trim(col(c_name)))

	######################################## Identifying 5 digit ZIP code ################################################################################ 
	print("zip codes")
	Data_837_Final = Data_837_new.select("*").withColumn('rendering_zip_5',Data_837_new.rendering_zip.substr(1, 5))
	print("caching 837 final")

	######################################## Read UPS table ################################################################################ 

	UPS_Store_Locations_Final =  spark.sql("select * from pi_prod.pcm_ups_add where type ='UPS'")

	UPS_Store_Locations_Final.createOrReplaceTempView("UPS_Store_Locations_Final")

	########################### Joining both the databases on zip code, word1 & word2 (mapping) ###########################

	print("matching address")
	Match_dataframe = Data_837_Final.join(UPS_Store_Locations_Final,(Data_837_Final.rendering_zip_5 == UPS_Store_Locations_Final.ups_zip_5) & (Data_837_Final.r_add1 == UPS_Store_Locations_Final.ups_add1) & (Data_837_Final.r_add2 == UPS_Store_Locations_Final.ups_add2), how ='inner')

	Match_dataframe_c =Match_dataframe.select(col("*"), when(col("rendering_addr_cln").contains(col("UPS_Address_cln")),"1")
											  .when(col("UPS_Address_cln").contains(col("rendering_addr_cln")),"1")
											  .otherwise("0")
											  .alias("Contain_score"))

	################################################### Levenshtein Algorithm ################################################ 

	Match_dataframe_cl = Match_dataframe_c.withColumn("levenshtein_score",levenshtein(col("rendering_addr_cln"), col("UPS_Address_cln"))).withColumn("levenshtein_score_part3",levenshtein(col("r_Address_part3_cln"), col("ups_address_part3_cln")))

	########## Calculating length difference of two address of remaining string #########

	Match_dataframe_cl = Match_dataframe_cl.withColumn('Len_diff',F.abs(F.length(Match_dataframe_cl.r_Address_part3_cln) - F.length(Match_dataframe_cl.ups_address_part3_cln)))

	################## Calculating score based on Levenshtein score and len_diff ##################

	Match_dataframe_cl = Match_dataframe_cl.withColumn('score',F.abs(Match_dataframe_cl.levenshtein_score_part3 - Match_dataframe_cl.Len_diff))

	################## Calculating numeric levenstein ##################

	Match_dataframe_cl = Match_dataframe_cl.withColumn("levenshtein_score_num",levenshtein(col("r_Address_part3_num_cln"), col("UPS_Address_part3_num_cln")))


	################## Eliminating score value > 4 & prov_npi with null value ##################

	Match_dataframe_cln = Match_dataframe_cl.where(col("prov_npi") != '')


	Match_dataframe_cln = Match_dataframe_cln.where(col("score") < int(levenshtein_threshold) )



	Match_dataframe_cln = Match_dataframe_cln.withColumn("r_Address_part3_STE", F.split(F.col("r_Address_part3"), "STE")).withColumn("UPS_Address_part3_STE", F.split(F.col("UPS_Address_part3"), "STE"))
	Match_dataframe_cln =Match_dataframe_cln.select("*", F.trim(Match_dataframe_cln["r_Address_part3_STE"][1]).alias('r_Address_part3_STE_nw'),F.trim(Match_dataframe_cln["UPS_Address_part3_STE"][1]).alias('UPS_Address_part3_STE_nw'))

	Match_dataframe_cln = Match_dataframe_cln.select("*", when( ((col("levenshtein_score_num") ==0) & (F.length(Match_dataframe_cln.r_Address_part3_num_cln) >= 3 ) )  ,"1").otherwise("0").alias("suite_match_num"))
	Match_dataframe_cln = Match_dataframe_cln.select("*", when( ( (F.length(Match_dataframe_cln.r_Address_part3_STE_nw) > 0 ) & (F.length(Match_dataframe_cln.UPS_Address_part3_STE_nw) > 0 ) &  (col("r_Address_part3_STE_nw") != col("UPS_Address_part3_STE_nw")))  ,"1").otherwise("0").alias("suite_match_reg"))

	Match_dataframe_cln.createOrReplaceTempView("Final_data_5")

	Final = spark.sql("""select *, (case when suite_match_reg = 1 then 0 else suite_match_num end) as suite_match from Final_data_5""")



	Final.createOrReplaceTempView("Final_data_3")


	final = spark.sql("select substr(srk_clm_id, 0, 26) as clm_id,(case when suite_match =1 then 'Exact Match' when contain_score = 1 then 'Strong Match' else 'Weak Match' end ) as suite_match,address from Final_data_3")
	print("clm_id")
	#print(final.select("clm_id").collect()[0])
	print("***************** Dropping dups ******************")
	#final = final.dropDuplicates()
	final.createOrReplaceTempView("final_table")

	print("-------------Inserting into HBASE table------------")
	spark.sql("insert into table pi_prod.pcm_ups_fraud select * from final_table")
	print("#######################  Total time taken  #######################")
	end = datetime.datetime.now().replace(microsecond=0)
	print(end-start)
	print("###################  NUMBER OF LINES PROCESSED  #################")
	#print(df.count())
	#if(final.count() > 0):
	#r = requests.post(mail_url, json=email_params("UPS Fraud streaming found data","UPS Fraud streaming found data"))
	#stop_streaming()

	
except Exception, e:
    error = sys.exc_info()[0]
    print(sys.exc_info()[0], str(e))
    r = requests.post(mail_url, json=email_params("UPS Fraud streaming stopped","UPS Fraud streaming stopped. Process till batchid: "+batchid))
    stop_streaming()
exit()

