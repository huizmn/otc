
############################################# Application starts #####################################################
################################################### Import dependecies ##########################################################
import os,sys
from pyspark.sql import SparkSession
import ConfigParser
import pyspark
import datetime
from datetime import date
from pyspark.sql.functions import udf, broadcast
from pyspark.sql.functions import levenshtein
from pyspark.sql.functions import lit
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from dateutil.relativedelta import relativedelta
from datetime import date, timedelta
from pyspark.sql.functions import lower,upper,col,desc,when,datediff,sort_array,regexp_replace,col,regexp_extract
from time import gmtime, strftime
from datetime import datetime
import pandas as pd

config_path = "/mapr/datalake/uhc/ei/pi_ara/sherlock/staging/apps/pcm/config/config_lead_release.py"

############################################# Sherlock platform configurations #####################################################

###arguments passed from java code
mid = ['-1']
module_id=""
module_name="empty"
status = ['Start','End','Error']
#paths
parent_path = sys.argv[1]
mapr_parent_path = sys.argv[2]

config_path = sys.argv[3]
tracking_url = sys.argv[4]+'UpdateModuleTrackingInfo'
guid = sys.argv[5]
pid = sys.argv[6]
aid = sys.argv[7]
sid = sys.argv[8]
uid = sys.argv[9]
py_libs = sys.argv[10]
memoryOverhead = sys.argv[11]
appname = sys.argv[12]
env = sys.argv[14]
portfolio_config_url = sys.argv[13] + 'GetPortfolioConfig'
source_config_url = sys.argv[13] + 'GetSourceConfig'
app_config_url = sys.argv[13] + 'GetApplicationConfig'


spark = SparkSession \
    .builder \
    .config("spark.port.maxRetries", 20) \
    .appName(appname).enableHiveSupport() \
    .getOrCreate()

spark.conf.set("spark.yarn.executor.memoryOverhead",memoryOverhead)



sys.path.insert(0, py_libs)
import requests


#import portfolio config
portfolio_r = requests.post(portfolio_config_url,json={"PortfolioID":pid })
source_r = requests.post(source_config_url,json={"SourceID":aid })
app_r = requests.post(app_config_url,json={"ApplicationID":aid })
config_data = portfolio_r.json()
config_data_1 = source_r.json()
config_data_2 = app_r.json()
#application_name = filter(lambda x : x['Key'] == 'Name', config_data_2)[0]['Value'].encode("utf-8")
application_name = appname 
is_mock_run = filter(lambda x : x['Key'] == 'Is_Mock_Run', config_data_2)[0]['Value'].encode("utf-8")
parent_path = filter(lambda x : x['Key'] == env+'_Parent_Path', config_data)[0]['Value'].encode("utf-8")
mapr_parent_path = filter(lambda x : x['Key'] == env+'_HDFS_Parent_Path', config_data)[0]['Value'].encode("utf-8")
database_name = filter(lambda x : x['Key'] == env+'_Hive_Database', config_data)[0]['Value'].encode("utf-8")
input_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/input/"
path_parquet = mapr_parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/"
output_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/output/"

if is_mock_run == "False":
 database_name = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")
 path_parquet = mapr_parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/"
 output_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/output/"

print("portfolio-- ",portfolio_r)
print("source -- ",source_r)
print("config data-- ",config_data_1)
print("app name-- ",application_name)
print("parent path -- ",mapr_parent_path)
print("mock run-- ",is_mock_run)
print("Db name -- ",database_name)
print("path paruet-- ",path_parquet)
print("input path-- ",input_path)
print("output path-- ",output_path)

##################################################  Read Configurations  ################################################################################################
print("config: ", config_path)
configParser = ConfigParser.RawConfigParser()
configFilePath = config_path
print("Base project config path: ", configFilePath)
configParser.read(configFilePath)
batch_days = configParser.get('file', 'batch_days')
ups_file = configParser.get('file', 'ups_file')
validation_file = configParser.get('file', 'validation_file')
output_path = configParser.get('file', 'output_path')
levenshtein_threshold = configParser.get('file', 'levenshtein_threshold')
required_cols = configParser.get('file', 'required_cols')
required_cols_array = required_cols.split(",")
no_of_leads = configParser.get('file', 'no_of_leads')
base_path = configParser.get('file', 'base_path')
mail_url = configParser.get('file', 'mail_url')
fromAddr = configParser.get('file', 'fromAddr')
toAddr = configParser.get('file', 'toAddr')
no_of_leads = int(configParser.get('file', 'no_of_leads'))
claim_columns = configParser.get('file', 'claim_columns')
claim_columns_array = claim_columns.split(",")
today_dt = date.today().strftime ("%Y%m%d")
#shared_leads =  spark.sql("select * from pi_Stg.pcm_shared_leads")





################################################	FUNCTIONS	############################################################################

def remove_all_whitespace(col):
    return F.regexp_replace(col, "\\s+", "")

#### ------------------------- #######

def split_address(df, column_name):
	#df.printSchema()
	print("showing df in split ad")
	#df.show()
	df = df.select('*', F.split(column_name, '\\s+').alias('r_add'))
	#maxCodes = df.agg(F.max(F.size('r_add'))).first()[0]
	maxCodes = 15
	print("max code:", maxCodes)
	df =df.select('*', *[F.col('r_add').getItem(i).alias('r_add'+str(i+1)) for i in range(maxCodes)])
	na_dict = {}
	for c in range(maxCodes):
		co = "r_add"+ str(c+1)
		na_dict[co] = ""
	df = df.na.fill(na_dict)
	col_list = ["r_add"+ str(c+1) for c in range(2,maxCodes)]  
	for c in col_list[:-1]:
		df = df.withColumn(c, F.concat(F.col(c), F.lit(" ")))
	df = df.withColumn('r_Address_part3',F.concat(*col_list))
	df = df.select('*',regexp_replace('r_Address_part3', '[0-9]','').alias('r_Address_part3_cln'))
	df = df.select('*',regexp_replace('r_Address_part3',  '[^0-9]','').alias('r_Address_part3_num_cln'))
	df = df.withColumn('r_Address_part3_cln', regexp_replace('r_Address_part3_cln', '  ', ''))
	df = df.select("*").withColumn('r_Address_part3_cln',remove_all_whitespace(df.r_Address_part3_cln))
	#df = df.drop('r_Address_part3_cln')
	try:
		for c_name in df.columns:
			df = df.withColumn(c_name, F.trim(col(c_name)))
	except Exception, e:
		print("error for :",c_name)
	return df
#### ------------------------- #######

def email_params_attach(subject,body,path):
    params = {
        "from_addr":fromAddr,  
	"to_addr":toAddr, 
	"subject":subject, 
	"body": body, 
	"attach_path": path
    }
    return params

def email_params(subject,body):
    params = {
        "from_addr":fromAddr,  
	"to_addr":toAddr, 
	"subject":subject, 
	"body": body
    }
    return params


########################################################################################################################################

####################	GET SHARED LEADS DATA	#########################

#shared = spark.read.parquet("/datalake/uhc/ei/pi_ara/sherlock/development/msing/ups_shared_parquet")
shared  = spark.read.parquet(output_path+"lead_repository3")
shared = shared.withColumnRenamed("prov_npi","npi").withColumnRenamed("rendering_addr","rend_addr").withColumnRenamed("rendering_zip_5","zip").withColumnRenamed("ups_fraud","ups")

shared.createOrReplaceTempView("shared")

####################	GET LEAD REPOSITORY	#########################

lead_repository = spark.read.parquet(output_path+"lead_repository")

####################	GET NEW LEADS	#########################

new_leads = lead_repository.join(shared, (lead_repository.prov_npi == shared.npi), how='leftAnti')
lead_count = new_leads.count()


today_dt = date.today().strftime ("%Y%m%d")
required_date = ((date.today() - timedelta(90)).strftime ("%Y%m%d"))
#today_dt = '20191001'
#required_date = '20190801'


####################	GET HBASE DATA	#########################

hbase_df = spark.sql("""select key,batch_run_dt as batch_date,ups_fraud,ups_address from pi_prod.claimdto_new
				where  key > '"""+required_date+"""' and key < '"""+today_dt+"""' and ups_fraud is not null""")

#hbase_df.write.mode("Overwrite").option("header","true").parquet(output_path+"hbase")
hbase_df = spark.read.parquet(output_path+"hbase")
hbase_df = hbase_df.filter('batch_date is not null')
hbase_df=hbase_df.withColumnRenamed("batch_date","batch_date_hbase")

####################	GET CORRESPONDING ANALYTICS DATA	#########################


analytic_query = """select substr(srk_clm_id, 0, 26) as clm_id,fln_nbr,batch_run_dt,clm_bill_prov_npi,clm_bill_prov_tin,clm_patient_f_nm,clm_patient_m_nm,clm_patient_l_nm,
cl_proc_cd,invn_ctl_nbr,
cl_fst_serv_dt,cl_lst_serv_dt,
cl_line_item_chrg_amt,
clm_bill_prov_tax_cd,
clm_bill_prov_f_nm,clm_bill_prov_m_nm,clm_bill_prov_org_l_nm,
clm_bill_prov_addr,clm_bill_prov_state,clm_bill_prov_city,clm_bill_prov_zip,
clm_patient_id,
concat_ws("|",(case when trim(clm_hc_diag_code1) != '' then clm_hc_diag_code1 end), 
(case when trim(clm_hc_diag_code2) != '' then clm_hc_diag_code2 end),
(case when trim(clm_hc_diag_code3) != '' then clm_hc_diag_code3 end),
(case when trim(clm_hc_diag_code4) != '' then clm_hc_diag_code4 end),
(case when trim(clm_hc_diag_code5) != '' then clm_hc_diag_code5 end),
(case when trim(clm_hc_diag_code6) != '' then clm_hc_diag_code6 end),
(case when trim(clm_hc_diag_code7) != '' then clm_hc_diag_code7 end),
(case when trim(clm_hc_diag_code8) != '' then clm_hc_diag_code8 end),
(case when trim(clm_hc_diag_code9) != '' then clm_hc_diag_code9 end),
(case when trim(clm_hc_diag_code10) != '' then clm_hc_diag_code10 end),
(case when trim(clm_hc_diag_code11) != '' then clm_hc_diag_code11 end),
(case when trim(clm_hc_diag_code12) != '' then clm_hc_diag_code12 end)) as Diag_cd,
concat_ws(" ",(case when trim(clm_patient_f_nm) != '' then clm_patient_f_nm end), 
(case when trim(clm_patient_m_nm) != '' then clm_patient_m_nm end),
(case when trim(clm_patient_l_nm) != '' then clm_patient_l_nm end)) as Patient_nm,
concat_ws("|",(case when trim(cl_proc_mod1) != '' then cl_proc_mod1 end), 
(case when trim(cl_proc_mod2) != '' then cl_proc_mod2 end),
(case when trim(cl_proc_mod3) != '' then cl_proc_mod3 end),
(case when trim(cl_proc_mod4) != '' then cl_proc_mod4 end)) as Modifier,
(case when trim(cl_rend_prov_npi)!='' then cl_rend_prov_npi 
when trim(cl_rend_prov_npi)='' and trim(clm_rend_prov_npi)='' then clm_bill_prov_npi 
when trim(cl_rend_prov_npi)='' then clm_rend_prov_npi end) as prov_npi,
(case when trim(cl_rend_prov_taxonomy_cd)!='' then cl_rend_prov_taxonomy_cd 
when trim(clm_rend_prov_taxonomy_cd)!='' then clm_rend_prov_taxonomy_cd
when trim(cl_rend_prov_npi)='' and trim(clm_rend_prov_npi)='' then clm_bill_prov_tax_cd end) as Rend_taxonomy_cd,
(case when trim(cl_place_of_srcv)!='' then cl_place_of_srcv else clm_place_of_srcv end) as place_of_service,
(case when trim(cl_facility_addr)!='' then cl_facility_addr else clm_facility_addr end) as rendering_addr,
(case when trim(cl_facility_city)!='' then cl_facility_city else clm_facility_city end) as Rend_city,
(case when trim(cl_facility_state)!='' then cl_facility_state else clm_facility_state end) as Rend_state,
(case when trim(cl_facility_zip)!='' then cl_facility_zip else clm_facility_zip end) as Rend_zip,
(case when trim(cl_facility_nm)!='' then cl_facility_nm else clm_facility_nm end) as facility_name 
from pi_prod.837p_clm_analytic_data 
where  batch_run_dt > '"""+required_date+"""' and batch_run_dt < '"""+today_dt+"""' and  trim(cl_facility_addr) != ''"""

analytics_data = spark.sql(analytic_query)
#analytics_data.write.mode("Overwrite").option("header","true").parquet(output_path+"analytics_data")
analytics_data = spark.read.parquet(output_path+"analytics_data")
analytics_data.createOrReplaceTempView("analytics_data")


####################	JOIN HBASE AND ANALYTICS DATA	#########################

all_leads = analytics_data.select("prov_npi","rendering_addr","Rend_zip","Rend_zip","Rend_state","Rend_city","Rend_taxonomy_cd","clm_id","invn_ctl_nbr","batch_run_dt","facility_name","place_of_service")
all_leads = all_leads.dropDuplicates()
all_leads = all_leads.withColumnRenamed("batch_run_dt","batch_date")
all_leads = all_leads.join(hbase_df, all_leads.clm_id == hbase_df.key,how='inner')
all_leads = all_leads.withColumn('rendering_zip_5',all_leads.Rend_zip.substr(1, 5))



####################	DEDUP SHARED NPI	#########################

npi_deduped = all_leads.join(shared, all_leads.prov_npi == shared.npi, how="leftanti")
npi_deduped.createOrReplaceTempView("npi_deduped")


####################	SPLIT ADDRESSES / NEED TO SPLIT FOR STREAMING AS WELL	#########################

shared_leads = split_address(shared,"rend_addr")
all_leads = split_address(all_leads,"rendering_addr")

####################	CHANGING COLUMN NAME FOR REFRENCE	#########################################

shared_leads = shared_leads.withColumn("r_Address_part3_cln_shared",shared_leads['r_Address_part3_cln'])
shared_leads = shared_leads.withColumn("r_Address_part3_num_cln_shared",shared_leads['r_Address_part3_num_cln'])
shared_leads = shared_leads.withColumn("r_Address_part3_shared",shared_leads['r_Address_part3'])


all_leads = all_leads.withColumn("r_Address_part3_cln_all",all_leads['r_address_part3_cln'])
all_leads = all_leads.withColumn("r_Address_part3_num_cln_all",all_leads['r_Address_part3_num_cln'])
all_leads = all_leads.withColumn("r_Address_part3_all",all_leads['r_address_part3'])


####################	MATCHING ON REND ADDRESS	#################################################


##-----------JOIN OVER ZIP, R1,R2

match = all_leads.join(shared_leads, (all_leads.rendering_zip_5 == shared_leads.zip)&(all_leads.r_add1==shared_leads.r_add1)&(all_leads.r_add2==shared_leads.r_add2), how='inner')

##-----------NON-NUMERIC LEVENSTEIN

match = match.withColumn("levenshtein_score",levenshtein(col("r_Address_part3_cln_shared"), col("r_Address_part3_cln_all")))
match = match.withColumn("levenshtein_part3",levenshtein(col("r_Address_part3_cln_all"), col("r_Address_part3_cln_shared")))
match = match.withColumn('Len_diff',F.abs(F.length(col('r_Address_part3_cln_shared')) - F.length(col('r_Address_part3_cln_all'))))
match = match.withColumn('score',F.abs(match.levenshtein_part3 - match.Len_diff))

##----------- NUMERIC LEVENSTEIN
match = match.withColumn("levenshtein_score_num",levenshtein(col("r_Address_part3_num_cln_all"), col("r_Address_part3_num_cln_shared")))

##----------- THRESHOLD
match= match.where(col("score") < int(levenshtein_threshold)  )

match = match.dropDuplicates()

####################	SUITE MATCH ON SHARED AND LEADS	[FULL LOGIC NOT REQUIRED, JUST LEVEN_NUM]	#################################################

match = match.withColumn("r_Address_part3_STE_shared", F.split(F.col("r_Address_part3_shared"), "STE")).withColumn("r_Address_part3_STE_all", F.split(F.col("r_Address_part3_all"), "STE"))
match =match.select("*", F.trim(match["r_Address_part3_STE_shared"][1]).alias('r_Address_part3_STE_shared_nw'),F.trim(match["r_Address_part3_STE_all"][1]).alias('r_Address_part3_STE_all_nw'))

match = match.select("*", when( ((col("levenshtein_score_num") ==0) & (F.length(match.r_Address_part3_num_cln_all) >= 3 ) )  ,"1").otherwise("0").alias("suite_match_num_match"))
match = match.select("*", when( ( (F.length(match.r_Address_part3_STE_all_nw) > 0 ) & (F.length(match.r_Address_part3_STE_shared_nw) > 0 ) &  (col("r_Address_part3_STE_all_nw") != col("r_Address_part3_STE_shared_nw")))  ,"1").otherwise("0").alias("suite_match_reg_match"))
match.createOrReplaceTempView("match_temp")

match = spark.sql("select *, (case when suite_match_reg_match = 1 then 0 else suite_match_num_match end) as suite_match_common from match_temp")

match_final =  match.filter('score < 4 and levenshtein_score_num=0')
match.createOrReplaceTempView("matched")

### After creation of match, We can join match with all leads, on rendering_addr of match to rendering_addr of all_leads and flag true postives to get final dataset

####################	JOINING BACK WITH NPI DEDUPED	################################################

result = spark.sql("select a.*, b.result,b.rend_addr from npi_deduped a left join matched b on a.rendering_addr = b.rendering_addr").dropDuplicates()
result.createOrReplaceTempView("result")
print("result:",result.count())

####################	SELECT LEADS	################################################################

#final_leads = spark.sql("select * from result where suite_match =1 or result = true order by suite_match desc limit 10")
#final_leads = spark.sql("select * from result where ups_fraud ='Exact_match' or result = true  limit 10")
final_leads = spark.sql("""select a.*, (case when trim(Rend_taxonomy_cd) = '' or Rend_taxonomy_cd is  null  then b.primary_taxonomy else Rend_taxonomy_cd end) as taxonomy from result a
				 left join pi_prod.nppes b 
					on a.prov_npi = b.npi""")

####################	TAXONOMY EXCLUSIONS	#####################
ups_tax_excl=spark.sql("select * from pi_prod.pcm_ups_exclusions")
universal_tax_excl = spark.sql("select * from pi_prod.pcm_plrt_exclusions")
final_leads = final_leads.join(ups_tax_excl, final_leads.taxonomy == ups_tax_excl.taxonomy, how='leftanti')
final_leads = final_leads.join(universal_tax_excl, final_leads.taxonomy == universal_tax_excl.taxonomy, how='leftanti')

#final_leads.show()
final_leads.createOrReplaceTempView("final_leads")

####################	FINAL LEADS DATA	#####################

leads_data = spark.sql("""select prov_npi, rendering_addr,Rend_city,Rend_state,rendering_zip_5,facility_name,result,ups_fraud,ups_address,
collect_set(invn_ctl_nbr) as assoc_icn,
collect_set(place_of_service) as assoc_pos,
collect_set(taxonomy) as claim_taxonomy,
collect_set(batch_date) as batch_array
from final_leads group by prov_npi, rendering_addr,Rend_city,Rend_state,rendering_zip_5,result,facility_name,ups_fraud,ups_address""")


#leads_data.write.mode("append").option("header","true").parquet(output_path+"lead_repository2")
#lead_repository = spark.read.parquet(output_path+"lead_repository3")
#new_leads = lead_repository.join(shared, (lead_repository.prov_npi == shared.npi), how='leftAnti')
new_leads = leads_data.join(shared, (leads_data.prov_npi == shared.npi), how='leftAnti')
lead_count = new_leads.count()


print("new leads:")
#new_leads.show()
new_leads.createOrReplaceTempView("new_leads")

new_leads = spark.sql(""" select *, (case 
	when result = true and ups_fraud = 'Exact Match' then 1
	when result = true and ups_fraud = 'Strong Match' then 2
	when result = true and ups_fraud = 'Weak Match' then 3
	when (result is null or result = 'nan')  and ups_fraud = 'Exact Match' then 4
	when (result is null or result = 'nan') and ups_fraud = 'Strong Match' then 5
	when (result is null or result = 'nan') and ups_fraud = 'Weak Match' then 6
	when result = false and ups_fraud = 'Weak Match' then 7
	when result = false and ups_fraud = 'Strong Match' then 8
	when result = false and ups_fraud = 'Exact Match' then 9
    end) as priority from new_leads order by  priority """)


new_leads.createOrReplaceTempView("new_leads_sorted")
#new_leads = spark.sql("select * from new_leads_sorted order by priority  limit "+str(no_of_leads))
new_leads = spark.sql("select * from new_leads_sorted order by priority ")
#new_leads.show()
new_leads.createOrReplaceTempView("distinct_ups")
query = """SELECT a.* FROM distinct_ups a INNER JOIN (SELECT c.prov_npi,c.ups_address, ROW_NUMBER() OVER(PARTITION BY c.ups_address ORDER BY c.priority ) as row_num  FROM distinct_ups c) AS b
  ON a.prov_npi = b.prov_npi
  AND a.ups_address = b.ups_address
where b.row_num = 1  order by a.priority  limit """+str(no_of_leads)
new_leads = spark.sql(query)
new_leads = new_leads.drop("lead_gen_date")
new_leads = new_leads.withColumn("lead_gen_date",lit(today_dt))
new_leads.write.mode("append").option("header","true").parquet(output_path+"lead_repository3")
new_leads = spark.read.parquet(output_path+"lead_repository3")
new_leads = new_leads.where(new_leads['lead_gen_date'] ==today_dt)
temp = new_leads.withColumnRenamed("result","Identified_fraud_Address").withColumn("assoc_icn",lit(new_leads["assoc_icn"])).withColumn("assoc_pos",lit(new_leads["assoc_pos"]))
temp = temp.withColumn("claim_taxonomy",lit(temp["claim_taxonomy"])).drop("batch_array").toPandas()
temp.to_csv("/mapr"+output_path+"today_leads/csv/"+"leads.csv", header=True, index=False)
new_leads.createOrReplaceTempView("new_leads_final")

#dict = {'last_run_date' : [last_run_date] }
#df = pd.DataFrame(dict)
#df.to_csv("/mapr"+output_path+"run_history/run_history.csv", mode='a', index=False, header=False)

dates = spark.sql("select batch_array[0] from new_leads_final").distinct().collect()

####################	GET CLAIMS DATA	 ###############################################################


query_org = """select * from analytics_data 
			where batch_run_dt is not null and batch_run_dt = 'batch_date_placeholder' """

claims_data = spark.sql(query_org.replace("batch_date_placeholder",str(dates[0][0])))

for i in dates:
	if (i[0] != "Batch_date"):
		query = query_org.replace("batch_date_placeholder",str(i[0]))
		temp = spark.sql(query)
		claims_data = claims_data.union(temp)

claims_data = claims_data.dropDuplicates()
claims_data = claims_data.withColumnRenamed("prov_npi","Rend_npi").withColumnRenamed("rendering_addr","Rend_addr") 

####################	EXCLUSIONS ARE PENDING	#############################################
####################	QUESTION ON PROV_NPI WITH TWO DIFFERENT UPS	#####################

new_leads = new_leads.withColumnRenamed("Rend_state","Rend_state_new").withColumnRenamed("Rend_city","Rend_city_new")

final_claims_data = claims_data.join(broadcast(new_leads), (claims_data.Rend_npi == new_leads.prov_npi)&(claims_data.Rend_addr == new_leads.rendering_addr), how = 'inner')
final_claims_data.createOrReplaceTempView("claims_data")
final_claims_data = final_claims_data.select("fln_nbr", "batch_run_dt","clm_bill_prov_npi","clm_bill_prov_tin","clm_patient_f_nm","clm_patient_m_nm","clm_patient_l_nm","cl_proc_cd","invn_ctl_nbr","cl_fst_serv_dt","cl_lst_serv_dt","cl_line_item_chrg_amt","clm_bill_prov_tax_cd","clm_bill_prov_f_nm","clm_bill_prov_m_nm","clm_bill_prov_org_l_nm","clm_bill_prov_addr","clm_bill_prov_state","clm_bill_prov_city","clm_bill_prov_zip","clm_patient_id","Diag_cd","Patient_nm","Modifier","Rend_npi","Rend_taxonomy_cd","place_of_service","Rend_addr","Rend_city","Rend_state","Rend_zip")
final_claims_data.toPandas().to_csv("/mapr"+output_path+"today_leads/csv/"+"claims.csv", header=True, index=False)
#final_claims_data.write.mode("Overwrite").option("header","true").parquet(output_path+"claims_data")


writer = pd.ExcelWriter("/mapr"+output_path+"today_leads/today_leads.xlsx")
df = pd.read_csv("/mapr"+output_path+"today_leads/csv/"+"leads.csv")
df.to_excel(writer,sheet_name="Leads")
df = pd.read_csv("/mapr"+output_path+"today_leads/csv/"+"claims.csv")
df.to_excel(writer,sheet_name="Claims_data")
writer.save()
r = requests.post(mail_url, json=email_params_attach("Please find UPS leads for : "+today_dt,"Please find attachment","/mapr"+output_path+"today_leads/today_leads.xlsx"))


####################	INCASE UPS IS AVAILABLE ###############################################

#leads_repo = spark.sql("select a.*, (case when b.result = false then 'false' when b.result = true then 'true' end ) as feedback_flag from npi_deduped a left join shared b on a.address = b.ups")
#leads_repo= leads_repo.filter("feedback_flag = true or flag is null")

exit()














