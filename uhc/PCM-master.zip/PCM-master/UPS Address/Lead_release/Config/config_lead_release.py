# From user
[file]

#table name to be used
batch_days = 10
ups_file = UPS_Store_Locations.csv
validation_file = Validation_data_20200205.txt
#output_path = /datalake/uhc/ei/pi_ara/sherlock/datasource/other_app_data/prod/pcm/output/
output_path = /datalake/uhc/ei/pi_ara/sherlock/datasource/hive/pi_prod/PCM/PLRT/
levenshtein_threshold = 4
required_cols = prov_npi,Batch_date,Lead_gen_dt,rendering_addr,rendering_city,rendering_state,rendering_zip_5,facility_name,Address,npi_asso_Feedback,assoc_icn,assoc_pos,suite_matched,contain_score,type
base_path = /datalake/uhc/ei/pi_ara/sherlock/datasource/hive/pi_prod/PCM/
no_of_leads = 10
claim_columns = batch_run_dt,fln_nbr,cl_fst_serv_dt,cl_lst_serv_dt,Rend_npi,Rend_taxonomy_cd,Rend_addr,Rend_city,Rend_state,Rend_zip,clm_bill_prov_npi,clm_bill_prov_tax_cd,clm_bill_prov_f_nm,clm_bill_prov_m_nm,clm_bill_prov_org_l_nm,clm_bill_prov_addr,clm_bill_prov_state,clm_bill_prov_city,clm_bill_prov_zip,clm_bill_prov_tin,clm_patient_f_nm,clm_patient_m_nm,clm_patient_l_nm,clm_patient_id,cl_proc_cd,Diag_cd,Modifier,cl_line_item_chrg_amt
mail_url = http://apvrp20338:3054/sendemail
fromAddr = No_reply@uhc.com
toAddr = manjot_singh@optum.com
reg_patterns="RURAL DELIVERY/RD","EXPRESSWAY/EXPY","RURAL ROUTE/RR","POST OFFICE/PO","BOULEVARD/BLVD","TURNPIKE/TPKE","EXTENSION/EXT","BUILDING/BLDG","APARTMENT/APT","SPRINGS/SPGS","SOUTHWEST/SW","SOUTHEAST/SE","NORTHWEST/NW","NORTHEAST/NE","JUNCTION/JCT","GATEWAY/GTWY","CENTERS/CTR","PARKWAY/PKY","TERRACE/TER","MOUNTAIN/MT","HIGHWAY/HWY","HEIGHTS/HTS","FREEWAY/FWY","CIRCLES/CIR","SQUARES/SQ","SPRING/SPG","HEIGHT/HTS","CIRCLE/CIR","AVENUE/AVE","CENTER/CTR","SUITE/STE","STREET/ST","SQUARE/SQ","PLAZA/PLZ","ISLAND/IS","SAINT/ST","PLACE/PL","MOUNT/MT","DRIVE/DR","COURT/CT","SOUTH/S","ROAD/RD","NORTH/N","LANE/LN","FORT/FT","VIEW/VW","WEST/W","EAST/E"
tax_excl = ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X','332BP3500X')