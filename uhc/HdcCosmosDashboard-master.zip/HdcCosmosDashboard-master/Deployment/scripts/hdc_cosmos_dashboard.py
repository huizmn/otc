
##################################################  Application Starts  ################################################################

import os
import sys
import ConfigParser
from pyspark.sql import SparkSession

###arguments passed from java code
mid = ['-1']
module_id=""
module_name="empty"
status = ['Start','End','Error']
#paths
parent_path = sys.argv[1]
mapr_parent_path = sys.argv[2]
config_path = sys.argv[3]
tracking_url = sys.argv[4]+'UpdateModuleTrackingInfo'
guid = sys.argv[5]
pid = sys.argv[6]
aid = sys.argv[7]
sid = sys.argv[8]
uid = sys.argv[9]
py_libs = sys.argv[10]
memoryOverhead = sys.argv[11]
appname = sys.argv[12]
env = sys.argv[14]
portfolio_config_url = sys.argv[13] + 'GetPortfolioConfig'
source_config_url = sys.argv[13] + 'GetSourceConfig'
app_config_url = sys.argv[13] + 'GetApplicationConfig'

##################################################  Initiate spark session  ################################################################


spark = SparkSession \
    .builder \
    .appName(appname).enableHiveSupport() \
    .getOrCreate()

spark.conf.set("hive.exec.dynamic.partition","true")
spark.conf.set("hive.exec.dynamic.partition.mode","nonstrict")
spark.conf.set("spark.sql.broadcastTimeout",3600)
spark.conf.set("spark.yarn.executor.memoryOverhead",memoryOverhead)
print("test")
print(py_libs)


##################################################  Import dependencies  #################################################################

sys.path.insert(0, py_libs)
import requests
import pandas as pd
import numpy as np
import datetime
import time
import glob
import time
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
from pyspark.sql import Row

##################################################  Setting up sherlock platform variables  ###########################################################

start = int(round(time.time()))
print(start)

#import portfolio config
portfolio_r = requests.post(portfolio_config_url,json={"PortfolioID":pid })
source_r = requests.post(source_config_url,json={"SourceID":aid })
app_r = requests.post(app_config_url,json={"ApplicationID":aid })
config_data = portfolio_r.json()
config_data_1 = source_r.json()
config_data_2 = app_r.json()
#application_name = filter(lambda x : x['Key'] == 'Name', config_data_2)[0]['Value'].encode("utf-8")
application_name=appname 
is_mock_run = filter(lambda x : x['Key'] == 'Is_Mock_Run', config_data_2)[0]['Value'].encode("utf-8")
parent_path = filter(lambda x : x['Key'] == env+'_Parent_Path', config_data)[0]['Value'].encode("utf-8")
mapr_parent_path = filter(lambda x : x['Key'] == env+'_HDFS_Parent_Path', config_data)[0]['Value'].encode("utf-8")
database_name = filter(lambda x : x['Key'] == env+'_Hive_Database', config_data)[0]['Value'].encode("utf-8")
input_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/input/"
path_parquet = mapr_parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/"
output_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/output/"
hive_database_location = filter(lambda x : x['Key'] == env+'_Hive_Database_Location', config_data)[0]['Value'].encode("utf-8")

if is_mock_run == "False":
 database_name_tmp = filter(lambda x : x['Key'] == env+'_Hive_Temp_Database', config_data)[0]['Value'].encode("utf-8")
 path_parquet = mapr_parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/"
 output_path = parent_path+filter(lambda x : x['Key'] == env+'_app_data_Temp_Path', config_data)[0]['Value'].encode("utf-8")+"/"+application_name+"/output/"
 database_name = filter(lambda x : x['Key'] == env+'_Hive_Database', config_data)[0]['Value'].encode("utf-8")

print("portfolio-- ",portfolio_r)
print("source -- ",source_r)
print("config data-- ",config_data_1)
print("app name-- ",application_name)
print("parent path -- ",mapr_parent_path)
print("mock run-- ",is_mock_run)
print("Db name -- ",database_name)
print("path paruet-- ",path_parquet)
print("input path-- ",input_path)
print("output path-- ",output_path)


##################################################  Reading config parameters  ###############################################################


configParser = ConfigParser.RawConfigParser()
configFilePath = config_path
configParser.read(configFilePath)

#mail_url = configParser.get('file', 'mail_url')
vendor_list1 = configParser.get('file', 'vendor_list1')
vendor_list2 = configParser.get('file', 'vendor_list2')
vendor_list3 = configParser.get('file', 'vendor_list3')
vendor_list4 = configParser.get('file', 'vendor_list4')
vendor_list5 = configParser.get('file', 'vendor_list5')
RPA_list1 = configParser.get('file', 'RPA_list1')
RPA_list2 = configParser.get('file', 'RPA_list2')
RPA_list3 = configParser.get('file', 'RPA_list3')
RPA_list4 = configParser.get('file', 'RPA_list4')
RPA_list5 = configParser.get('file', 'RPA_list5')
vendor_name1 = configParser.get('file', 'vendor_name1')
vendor_name2 = configParser.get('file', 'vendor_name2')
vendor_name3 = configParser.get('file', 'vendor_name3')
vendor_name4 = configParser.get('file', 'vendor_name4')
vendor_name5 = configParser.get('file', 'vendor_name5')

RPA_name1 = configParser.get('file', 'RPA_name1')
RPA_name2 = configParser.get('file', 'RPA_name2')
RPA_name3 = configParser.get('file', 'RPA_name3')
RPA_name4 = configParser.get('file', 'RPA_name4')
RPA_name5 = configParser.get('file', 'RPA_name5')
reporting_df = database_name+'.'+configParser.get('file', 'reporting_df')
scoring_df = database_name+'.'+configParser.get('file', 'scoring_df')
status_yr = configParser.get('file', 'status_yr')
mismatch_thresh = configParser.get('file', 'mismatch_thresh')
saving_factor = configParser.get('file', 'saving_factor')
old_model_path = parent_path+hive_database_location+configParser.get('file', 'old_model_path')
lookup_days = configParser.get('file', 'lookup_days')
mail_url= configParser.get('file', 'mail_url')
fromAddr = configParser.get('file', 'fromAddr')
toAddr = configParser.get('file', 'toAddr')
toAddr_completed = configParser.get('file', 'toAddr_completed')
sc = spark.sparkContext 





##################################################  Definations for small utility functions  ###############################################################


def parameters(a,b,c):
    params = {
    "GUID" : guid,
    "PortfolioID" : pid,
    "ApplicationID" : aid,
    "SourceID" : sid,
    "ModuleID" : a,
    "UserID" : uid,
    "Status" : b,
    "ErrorCode" : c
    }
    return params

def email_params_attach(subject,body):
    params = {
        "from_addr":fromAddr,  
	"to_addr":toAddr_completed, 
	"subject":subject, 
	"body": body
    }
    return params

def email_params(subject,body):
    params = {
        "from_addr":fromAddr,  
	"to_addr":toAddr, 
	"subject":subject, 
	"body": body
    }
    return params

def process_df(a):
	return str(a).replace("[",'').replace("]",'')




try:

###############################################################################################################################################################################

	start = datetime.now() - timedelta(days=0)
        start_date = start.strftime('%Y-%m-%d')

	hd_cosmos_history_load_latest_unique = spark.sql("""
	select * from 
	(
	select *, row_number() over (partition by hd_id, claim_number, division order by hd_status_date desc) as row 
	from (
	select * 
	from """+reporting_df+""" 
	where upper(claim_type)='HOSP' and upper(business_owner)='M&R' and upper(financial_owner)='M&R' and lower(hd_status)='closed'
	order by hd_id, claim_number, division, hd_status_date desc) as A)
	as B where row = 1
	""")
	hd_cosmos_history_load_latest_unique.createOrReplaceTempView("hd_cosmos_history_load_latest_unique")


	###########################  Status year calculation ######################

	status_yr_int = spark.sql("select year(max(hd_status_date))-1 as datapull_yr from "+reporting_df).collect()[0][0]
	status_yr = str(status_yr_int)

	
	###########################  Status year calculation ends ######################


	hdc_cosmos_audit_history_merge = spark.sql("""
	select 
	a.*, 
	b.scoreid, b.hd_rank as ARA_Rank, b.score, 
	to_date(substr(scoredate,1,10)) as Score_date_ara, 
	to_date(substr(adddate,1,10)) as Add_date_ara,
	ARA_Model_Version
	from hd_cosmos_history_load_latest_unique a
	left join (select *, model as ARA_Model_Version,scoredate as adddate from """+scoring_df+""") b
	on a.hd_id=b.key.hd_id
	and 
	cast(trim(a.claim_number) as int)=cast(trim(b.key.claim_number) as int)
	and
	upper(trim(a.division))=upper(trim(b.key.division))
	where year(hd_status_date)>="""+status_yr)

	hdc_cosmos_audit_history_merge.createOrReplaceTempView("hdc_cosmos_audit_history_merge")

####################################### config - 5 vendors +  5 RPA +  Rank mismatch flag +  savings % number (0.05) #################################################################

	vendor_list1_1 = process_df(vendor_list1)
	vendor_list1_2 = process_df(vendor_list2)
	vendor_list1_3 = process_df(vendor_list3)
	vendor_list1_4 = process_df(vendor_list4)
	vendor_list1_5 = process_df(vendor_list5)

	rpa_list1_1 = process_df(RPA_list1)
	rpa_list1_2 = process_df(RPA_list2)
	rpa_list1_3 = process_df(RPA_list3)
	rpa_list1_4 = process_df(RPA_list4)
	rpa_list1_5 = process_df(RPA_list5)
	
	RPA_list_all = process_df(RPA_list1+","+RPA_list2+","+RPA_list3+","+RPA_list4+","+RPA_list5)
	Vendor_list_all = process_df(vendor_list5+","+vendor_list4+","+vendor_list3+","+vendor_list2+","+vendor_list1)


	hdc_cosmos_audit_history_merge_v1 = spark.sql("""
	select *,(case when lower(HD_Auditor_Assigned) in 
	("""+RPA_list_all+""")
	then 'RPA'  when ((lower(HD_Auditor_Assigned) in ("""+Vendor_list_all+""")) and year(hd_status_date)*100+month(hd_status_date)<202005 ) then  'Vendor'  
	when  Vendor_Name="Non-Vendor" and RPA_Name="Non-RPA" then 'Model' end) as Audit_Source from 
	(select *,
	(case 
	when ((lower(HD_Auditor_Assigned) in ("""+vendor_list1_1+""")) and year(hd_status_date)*100+month(hd_status_date)<202005 ) then '"""+vendor_name1+"""' 
	when lower(HD_Auditor_Assigned) in ("""+vendor_list1_2+""") then '"""+vendor_name2+"""'
	when lower(HD_Auditor_Assigned) in ("""+vendor_list1_3+""") then '"""+vendor_name3+"""' 
	when lower(HD_Auditor_Assigned) in ("""+vendor_list1_4+""") then '"""+vendor_name4+"""' 
	when lower(HD_Auditor_Assigned) in ("""+vendor_list1_5+""") then '"""+vendor_name5+"""'  
	else 'Non-Vendor' end) as Vendor_Name,
	(case 
	when lower(HD_Auditor_Assigned) in ("""+rpa_list1_1+""") then '"""+RPA_name1+"""' 
	when lower(HD_Auditor_Assigned) in ("""+rpa_list1_2+""") then '"""+RPA_name2+"""'
	when lower(HD_Auditor_Assigned) in ("""+rpa_list1_3+""") then '"""+RPA_name3+"""' 
	when lower(HD_Auditor_Assigned) in ("""+rpa_list1_4+""") then '"""+RPA_name4+"""' 
	when lower(HD_Auditor_Assigned) in ("""+rpa_list1_5+""") then '"""+RPA_name5+"""'
	else 'Non-RPA' end) as RPA_Name,
	(case when lower(HD_Type_Of_Review) not like '%bypass%' then 1 else 0 end) as Reviewed_Flag,
	(case when lower(HD_Type_Of_Review) like '%bypass%' then 1 else 0 end) as Bypass_Flag,
	(case when error=1 and Savings>0.0 then 1 else 0 end) as Error_Overpaid,
	case when hd_rank between 1 and 500 then '1-500' when hd_rank between 501 and 1000 then '501-1000'
	when hd_rank between 1001 and 2500 then '1001-2500' when hd_rank between 2501 and 4000 then '2501-4000'
	when hd_rank between 4001 and 7000 then '4001-7000' when hd_rank between 7001 and 10000 then '7001-10000'
	when hd_rank between 10001 and 12500 then '10001-12500' when hd_rank between 12501 and 15000 then '12501-15000'
	when hd_rank between 15001 and 20000 then '15001-20000' when hd_rank > 20000 then  'i-20000+' else 'Null' end as Rank_Bucket,
	(case when (hd_rank>ara_rank+"""+mismatch_thresh+""") then 1 else 0 end) as Rank_mismatch_flag
	from 
	hdc_cosmos_audit_history_merge) K  """)
	print("after hdc_cosmos_audit_history_merge_v1")
	hdc_cosmos_audit_history_merge_v1.createOrReplaceTempView("hdc_cosmos_audit_history_merge_v1")

	#Incremental table
        #print("t3")
	legacy_model_sav_per_rev = spark.sql('''
	select *,case when rev_cnt>0 then savings/rev_cnt else 0 end as sav_per_rv_old from 
	(
	select Add_date_ara,sum(Reviewed_Flag) as rev_cnt,sum(savings) as savings
	from 
	hdc_cosmos_audit_history_merge_v1
	where lower(ARA_Model_version)='old' and upper(trim(Audit_Source))="MODEL" group by 
	Add_date_ara
	) k where rev_cnt>0 and to_date(Add_date_ara)>'2020-01-31'
	''')
        #print("t1")
	legacy_model_sav_per_rev.createOrReplaceTempView("legacy_model_sav_per_rev")

        #print("t2")
	new_model_sav_per_rev = spark.sql('''
	select M.* from 
	legacy_model_sav_per_rev old inner join 
	(
	select *,case when rev_cnt>0 then savings/rev_cnt else 0 end as sav_per_rv_new from 
	(
	select Add_date_ara,sum(Reviewed_Flag) as rev_cnt,sum(savings) as savings
	from 
	hdc_cosmos_audit_history_merge_v1
	where lower(ARA_Model_version)='new' and upper(trim(Audit_Source))="MODEL"  group by 
	Add_date_ara
	) k where rev_cnt>0
	) M 
	on 
	old.Add_date_ara=M.Add_date_ara
	''')

	new_model_sav_per_rev.createOrReplaceTempView("new_model_sav_per_rev")


	new_model_sav_per_rev_static = spark.sql('''
	select sum(savings)/sum(rev_cnt) sav_pre_rev_static from 
	( select *,row_number() over ( order by Add_date_ara desc) as  row from   
	new_model_sav_per_rev
	) K where row<'''+lookup_days
		)

	new_model_sav_per_rev_static.createOrReplaceTempView("new_model_sav_per_rev_static")


	legacy_model_sav_per_rev_static = spark.sql('''
	select L.*,new_model.sav_pre_rev_static as new_model_sav_pre_rev_static,(new_model.sav_pre_rev_static-L.sav_pre_rev_static)/(L.sav_pre_rev_static) as perct_change,
	current_date() as run_dt from 
	(
	select max(Add_date_ara) as legacy_end_dt,sum(savings)/sum(rev_cnt) sav_pre_rev_static from 
	( select *,row_number() over ( order by Add_date_ara desc) as  row from   
	legacy_model_sav_per_rev
	) K where row<'''+lookup_days+'''
	) L 
	cross join new_model_sav_per_rev_static new_model
	''')

	legacy_model_sav_per_rev_static.createOrReplaceTempView("legacy_model_sav_per_rev_static")
	
	#################### New threshold logic #########################

	add_dt_max = spark.sql("select max(Add_date_ara) as add_dt_max from legacy_model_sav_per_rev").collect()[0][0]
	thresh_dt = spark.sql("select date_sub(current_date, 3) as thresh_dt").collect()[0][0]
        print("thresh_dt"),thresh_dt
        print("add_dt_max"),add_dt_max

	if (thresh_dt < add_dt_max):
		print("write to the hive incremental table")
		legacy_model_sav_per_rev_static.toPandas().to_csv(old_model_path+"Old_model_"+str(start_date)+".csv", header = True, index=False)

	



	#### Incremental savings estimation code 
        legacy_model_sav_per_rev_static = spark.sql("select * from "+database_name+"."+"hdc_cosmos_old_model")
        legacy_model_sav_per_rev_static.createOrReplaceTempView("legacy_model_sav_per_rev_static")

	hdc_cosmos_audit_history_merge_v1_final = spark.sql('''
	select O.* from 
	(
	select N.* , 
	case 
	when old_model_active=1 then Incremental_savings_claim_v1
	when old_model_active=0 then Incremental_savings_claim_v2 end as Incremental_savings_claim,
	row_number() over (partition by claim_number,division order by legacy_end_dt desc) as  row_no
	from 
	(
	select M.*,
	c.legacy_end_dt,
	case 
	when (
	(
	(lower(M.ARA_Model_version)='new' and Reviewed_Flag=1 and upper(trim(Audit_Source))="MODEL") 
	or 
	(lower(M.ARA_Model_version)='new' and Reviewed_Flag=0 and M.savings>0 and upper(trim(Audit_Source))="MODEL")
	) 
	and (c.legacy_end_dt is not null )
	) 
	then (M.Savings*c.perct_change/(1+c.perct_change)) 
	else 0 end as Incremental_savings_claim_v2 from 
	(
	select a.*,
	case when (((lower(a.ARA_Model_version)='new' and Reviewed_Flag=1 and upper(trim(Audit_Source))="MODEL")
	or (lower(a.ARA_Model_version)='new' and Reviewed_Flag=0 and a.savings>0 and upper(trim(Audit_Source))="MODEL")
	) 
	and b.Add_date_ara is not null) then 
	(a.Savings -b.sav_per_rv_old) 
	else 0 end as 
	Incremental_savings_claim_v1 ,
	case when b.Add_date_ara is not null then 1 else 0 end as old_model_active
	from hdc_cosmos_audit_history_merge_v1 a 
	left join legacy_model_sav_per_rev b on 
	a.Add_date_ara = b.Add_date_ara
	) M 
	left join 
	( select distinct legacy_end_dt, perct_change from 
	( select *, 
	row_number() over ( partition by legacy_end_dt order by run_dt desc) as legacy_rank_dt 
	from legacy_model_sav_per_rev_static where run_dt is not null) ss where legacy_rank_dt=1 ) c on 
	M.Add_date_ara >  c.legacy_end_dt
	) N
	) O  where O.row_no=1
	''')

	hdc_cosmos_audit_history_merge_v1_final.createOrReplaceTempView("hdc_cosmos_audit_history_merge_v1_final")
 

	print("drop final table")
	spark.sql("drop table if exists "+database_name+"."+"hdc_cosmos_audit_history_merge_v1 ")
	print("create final table")
	spark.sql("create table "+database_name+"."+"hdc_cosmos_audit_history_merge_v1 as select * from hdc_cosmos_audit_history_merge_v1_final")
	print("process completed")
	r = requests.post(mail_url, json=email_params_attach("HDC Cosmos dashboard process completed","HDC Cosmos dashboard process completed"))


except Exception, e:
    error = sys.exc_info()[0]
    print(sys.exc_info()[0], str(e))

    r = requests.post(mail_url, json=email_params("HDC Cosmos dashboard process error","HDC Cosmos dashboard process ran into error. Please check logs"))
    r = requests.post(tracking_url, json=parameters(module_id,status[2],str(error)))
    #print(r.text)

end = int(round(time.time()))
print(end)

####################################################  Process ends  ###################################################################################

exit()

	


