# stargate-self-service-sandbox
Create and Manage Stargate teams and proxy resources against ```gateway-dev-core.optum.com``` and ```gateway-dev-dmz.optum.com``` for testing purposes only. Non customer facing gateways. Resources may be removed at any time, without warning.

#### Most Recent Wipe: 1/28/2020

# Docs migrated here
https://stargate-docs.optum.com/docs/self-service.html
