## Please place all stargate self-service request resource files in this directory!
