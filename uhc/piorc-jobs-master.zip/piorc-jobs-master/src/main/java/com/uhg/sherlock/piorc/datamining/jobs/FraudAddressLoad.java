package com.uhg.sherlock.piorc.datamining.jobs;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.uhc.sherlock.jobConnector.dbops.JobProcessState;


public class FraudAddressLoad {
	
	static Logger logger=Logger.getLogger(FraudAddressLoad.class);
	
	public FraudAddressLoad() throws IOException {
		Properties props = new Properties();
		InputStream is = getClass().getResourceAsStream("log4j2.properties");
		try {
		    props.load(is);
		}
		finally {
		    try {
		        is.close();
		    }
		    catch (Exception e) {
		        e.printStackTrace();
		        if (logger!=null) {
		        	logger.error(e.getMessage());
		        }
		    }
		}
		PropertyConfigurator.configure(props);
	}
	
	public void loadFraudAddressData(String jobId, String path) throws SQLException , IOException, 
					InterruptedException{
			String tempTablesql="set mapred.job.queue.name=araadh_q1.arapi_sq1;load data inpath '" + path + "' into table sherlock.temp_table"  ;	
			logger.info("sql=" + tempTablesql);
			
    	  	ProcessBuilder hiveProcessBuilder = new ProcessBuilder("hive", "-e",tempTablesql);
	        Process hiveProcess = hiveProcessBuilder.start();

	        OutputRedirector outRedirect = new OutputRedirector(
	                hiveProcess.getInputStream(), "HIVE_OUTPUT", logger, jobId);
	        OutputRedirector outToConsole = new OutputRedirector(
	                hiveProcess.getErrorStream(), "HIVE_LOG", logger, jobId);

	        outRedirect.start();
	        outToConsole.start();  

	        hiveProcess.waitFor();
	        
	        //truncateHbaseFraudAddressTable(logger);
	        
	        String truncateFile="/mapr/datalake/uhc/ei/pi_ara/sherlock_prod/applications/ARCHIVEJOBS/PI_SANCTIONS/truncate_fraudaddress";
	        ProcessBuilder hbaseProcessBuilder = new ProcessBuilder("hbase","shell", truncateFile , "exit");
	        Process hbaseProcess = hbaseProcessBuilder.start();

	        OutputRedirector outRedirecthbase = new OutputRedirector(
	        		hbaseProcess.getInputStream(), "HBASE_OUTPUT", logger, jobId);
	        OutputRedirector outToConsolehbase = new OutputRedirector(
	        		hbaseProcess.getErrorStream(), "HBASE_LOG", logger, jobId);

	        outRedirecthbase.start();
	        outToConsolehbase.start();  

	        hbaseProcess.waitFor();
	        
			String sql="set mapred.job.queue.name=araadh_q1.arapi_sq1;insert into table sherlock.pi_fraudaddress "
					+ "select cast(unix_timestamp() * rand() as bigint), address from sherlock.temp_table";
			
			logger.info("sql=" + sql);
    	  	ProcessBuilder hiveProcessBuilder1 = new ProcessBuilder("hive", "-e",sql);
	        Process hiveProcess1 = hiveProcessBuilder1.start();

	        OutputRedirector outRedirect1 = new OutputRedirector(
	                hiveProcess1.getInputStream(), "HIVE_OUTPUT", logger, jobId);
	        OutputRedirector outToConsole1 = new OutputRedirector(
	                hiveProcess1.getErrorStream(), "HIVE_LOG", logger, jobId);

	        outRedirect1.start();
	        outToConsole1.start();  
		      
	        hiveProcess1.waitFor();
	        
	        String truncateSql="set mapred.job.queue.name=araadh_q1.arapi_sq1;truncate table sherlock.temp_table";
			
	        logger.info("sql=" + truncateSql);
    	  	ProcessBuilder hiveProcessBuilder2 = new ProcessBuilder("hive", "-e",truncateSql);
	        Process hiveProcess2 = hiveProcessBuilder2.start();

	        OutputRedirector outRedirect2 = new OutputRedirector(
	                hiveProcess2.getInputStream(), "HIVE_OUTPUT", logger, jobId);
	        OutputRedirector outToConsole2 = new OutputRedirector(
	                hiveProcess2.getErrorStream(), "HIVE_LOG", logger, jobId);

	        outRedirect2.start();
	        outToConsole2.start();  
	        
	        hiveProcess2.waitFor();
	}
	
//	private void truncateHbaseFraudAddressTable(Logger logger) {
//		String TABLE_NAME="/datalake/uhc/ei/pi_ara/sherlock_prod/maprdb/pi_fraudaddress"; 
//		Configuration conf = HBaseConfiguration.create();
//		 // ...
//		 // Setting properly the configuration information
//		 // ...
//		 try (HBaseAdmin admin = new HBaseAdmin(conf)) {
//		     if (admin.isTableEnabled(TABLE_NAME)) {
//		         admin.disableTable(TABLE_NAME);
//		     }
//		     admin.truncateTable(TableName.valueOf(TABLE_NAME), false);
//		     // Enabling the table after having truncated
//		     admin.enableTable(TABLE_NAME);
//		 }catch (ZooKeeperConnectionException e) {
//		     e.printStackTrace();
//		     logger.error(e.getMessage());
//		 } catch (IOException e) {
//		     e.printStackTrace();
//		     logger.error(e.getMessage());
//		 }
//		
//	}

	public static void main(String... args) throws SQLException, IOException , InterruptedException{
		if(args[0] == null) {
			throw new IOException("Pass the location of the csv file as an argument.");
		}
		FraudAddressLoad fraudAddress=new FraudAddressLoad();
		String jobId="";
		try {
			jobId=JobProcessState.fraudAddressLoadStarted();
			fraudAddress.loadFraudAddressData(jobId, args[0]);;
			JobProcessState.fraudAddressLoadCompleted(jobId);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			JobProcessState.fraudAddressLoadAborted(jobId, e.getMessage());
		}
		
	}
}


//Dataset<Row> rows=spark.sql(sql);
//spark.sqlContext().sql(sql);
//List<Row> rowList=rows.collectAsList();

//if(rowList!=null) 
//{
//	logger.info(rowList.size());
//	System.out.println(rowList.size());
//}
//Process p=null;
//Runtime r = Runtime.getRuntime();
//SparkSession spark = SparkSession.builder().enableHiveSupport().config(new SparkConf()).getOrCreate();