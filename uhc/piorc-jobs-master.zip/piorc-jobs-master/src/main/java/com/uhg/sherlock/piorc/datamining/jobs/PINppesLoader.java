package com.uhg.sherlock.piorc.datamining.jobs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog;

import com.uhc.sherlock.jobConnector.dbops.CreateConnection;
import com.uhc.sherlock.jobConnector.dbops.JobProcessState;
import com.uhg.sherlock.piorc.datamining.common.EmailUtil;

public class PINppesLoader {

  public static String stuckBatchId;

  public static void main(String[] args) throws SQLException,Exception {

    Properties conf = new Properties();
    String jobId = "";

    try {
      if (args.length == 0) {
        System.out.println("Configuration file is a must!");
        System.exit(-1);
      }

      if (!new File(args[0]).exists()) {
        System.out.println(
            "Invalid configuration file! Please provide a valid file path");
        System.exit(1);
      }
      System.out.println(
          "--------------------PI NPP Archival Process Started!--------------------");
      
      FileSystem fs = null;
      conf.load(new FileInputStream(args[0]));
      fs = FileSystem.get(new Configuration());
     
      EmailUtil.simpleMail(conf.getProperty("npp.email.url"),
              conf.getProperty("npp.email.fromAddr"),
              conf.getProperty("npp.email.toAddr"),
              conf.getProperty("npp.email.subjprefix", "NON PROD::")
                  + "PI NPPES Archival Started",
              "\nJob running for month : " 
                  + "\n\n with default execution-mode: "
                  + conf.getProperty("npp.default.mode", "true"));
     
      jobId = JobProcessState.offlineStarted(2014);
      System.out.println("received JobId : " + jobId);

      String fileName = null;
      try {
          
          if (fs.exists(new Path(conf.getProperty("npp.work.dir")))) {
            for (FileStatus fStat : fs
                .listStatus(new Path(conf.getProperty("npp.work.dir")))) {
              if (fStat.getPath().getName().endsWith(".csv")) {
            	  fileName = fStat.getPath().getName();
                
              } 
            }
          } 
        } catch (Exception e) {
          e.printStackTrace();
          System.exit(1);
        }

      String fullPath = conf.getProperty("npp.work.dir")+"/"+fileName;
      System.out.println("Input File"+fullPath);
      // Main logic starts here
      try {

    	  if (!canRunArchival(conf)) {
              EmailUtil.simpleMail(conf.getProperty("npp.email.url"),
                  conf.getProperty("npp.email.fromAddr"),
                  conf.getProperty("npp.email.toAddr"),
                  conf.getProperty("npp.email.subjprefix", "NON_PROD::")
                      + "NPP Archival failed to run",
                  "PI NPPES Archival could not be run since the batch " + stuckBatchId
                      + " processing in Ingestion is taking more than "
                      + conf.getProperty("npp.total.waittime") + " minutes");
              unpausePIORC();
              System.out.println(
                  "--------------------NPP Archival Process Ended!--------------------");
              return;
            }
        String info =
                loadNPPData(fullPath, conf);
        EmailUtil.simpleMail(conf.getProperty("npp.email.url"),
            conf.getProperty("npp.email.fromAddr"),
            conf.getProperty("npp.email.toAddr"),
            conf.getProperty("npp.email.subjprefix", "NON_PROD::")
                + "PI NPPES Archival Completed",
            info + "Regards\nsherlock");
        JobProcessState.offlineCompleted(2014, jobId);

      } catch (IOException e) {
        System.out.println("PI NPPES Archival job failed while running the BL!");
        e.printStackTrace();
        throw e;
      }

    } catch (Exception e) {
      e.printStackTrace();
      JobProcessState.jobProcessAborted(jobId, 2014, e.getMessage());
      System.out.println("Exception while running PI NPPES ARCHIVAL job!");
    } finally {
    	unpausePIORC();
    }

    System.out.println("done!");

  }
  
  public static boolean canRunArchival(Properties conf) throws Exception {
	    Connection con = null;
	    try {
	      con = CreateConnection.getConnection();
	      PreparedStatement prepareStatement1 = con.prepareStatement(
	          "update Application set Paused=? where ApplicationId=?");
	      prepareStatement1.setInt(1, 1);
	      prepareStatement1.setInt(2, 13);
	      prepareStatement1.executeUpdate();

	      int counter = 0;
	      while (counter <= Integer
	          .parseInt(conf.getProperty("npp.total.waittime"))) {
	        PreparedStatement batchIdQuery = con.prepareStatement(
	            "select batchId from batchProcessState where ApplicationId=? group by batchId having max(StatusId)=?");
	        batchIdQuery.setInt(1,13);
	        batchIdQuery.setInt(2,1);
	        ResultSet runningBatch = batchIdQuery.executeQuery();
	        if (runningBatch.next()) {
	          System.out.println("batch currently under processing -->"
	              + runningBatch.getString("batchId"));
	          stuckBatchId = runningBatch.getString("batchId");
	          System.out.println("will wait for "
	              + conf.getProperty("npp.wait.freq") + " seconds and retry");
	          Thread.sleep(
	              Integer.parseInt(conf.getProperty("npp.wait.freq")) * 1000);
	          counter++;
	          continue;
	        } else {
	          return true;
	        }
	      }
	      // checking if any batch is under process in Piorc
	    } catch (Exception e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	      throw e;
	    } finally {
	      try {
	        con.close();
	      } catch (SQLException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	        throw e;
	      }
	    }
	    return false;
	  }

  public static void unpausePIORC() throws Exception {
	    Connection con = null;
	    try {
	      con = CreateConnection.getConnection();
	      PreparedStatement prepareStatement1 = con.prepareStatement(
	          "update Application set Paused=? where ApplicationId=?");
	      prepareStatement1.setInt(1, 0);
	      prepareStatement1.setInt(2, 13);
	      prepareStatement1.executeUpdate();
	    } catch (Exception e) {
	      e.printStackTrace();
	      throw e;
	    }
	  }
	public static String loadNPPData(String inputFile, Properties conf) throws IOException {
		String tableCatalog = "{\n"
				+ "\"table\":{\"namespace\":\"default\", \"name\":\"/datalake/uhc/ei/pi_ara/sherlock_prod/maprdb/pi_nppes\"},\n"
				+ "\"rowkey\":\"npi\",\n" + "\"columns\":{\n"
				+ "\"npi\":{\"cf\":\"rowkey\", \"col\":\"npi\", \"type\":\"string\"},\n"
				+ "\"pi_nppes\":{\"cf\":\"pi_nppes\", \"col\":\"nppes\", \"type\":\"string\"}\n" + "}\n" + "}\n";
		//inputFile = inputFile + "/npidata_20050523-20171210.csv";
		StringBuilder finalString = new StringBuilder();
		SparkSession spark = SparkSession.builder().config(new SparkConf()).appName("PI_NPP_Archival").getOrCreate();
		System.out.println("-----Read the input CSV File----");
		Dataset<Row> inputDF = spark.read().csv(inputFile).na().fill("");
		Dataset<Row> nppesDF =  inputDF.filter(inputDF.col("_c0").notEqual("NPI"));
		
			try {
				nppesDF.createGlobalTempView("nppesDF");
			} catch (AnalysisException e) {
				System.out.println("Analysis Exception");
				e.printStackTrace();
			}
		
		String[] columns = inputDF.columns();
		System.out.println("length" + columns.length);
		String query = "select _c0 as npi,CONCAT_WS(',',";
		int count = 0;
		for (String string : columns) {
			count++;
			if (count != columns.length) {
				query = query + string + ",";
			} else {
				query = query + string;
			}
		}
		query = query + ")as pi_nppes from global_temp.nppesDF";
		System.out.println("query" + query);
		Dataset<Row> concatenatedNPP =  spark.sql(query);
		
		// Dataset<Row> concatenatedNPP =
		// inputDF.filter(inputDF.col("_c0").notEqual("NPI")).select(col("_c0").alias("npi"),col("pi_nppes"));
		System.out.println("-----Concatenated NPP Sample-----" + concatenatedNPP.takeAsList(1));
		System.out.println("Truncating the existing NPPES maprdb table");
	    Configuration config = HBaseConfiguration.create();
	    org.apache.hadoop.hbase.client.Connection connection =
	        ConnectionFactory.createConnection(config);

	    Admin admin = connection.getAdmin();
	    admin.truncateTable(TableName.valueOf("/datalake/uhc/ei/pi_ara/sherlock_prod/maprdb/pi_nppes"),
	        true);
	    System.out
	        .println("TRUNCATED pi_nppes Maprdb");
	    admin.close();
	    
		concatenatedNPP.write().option(HBaseTableCatalog.tableCatalog(), tableCatalog)
				.format("org.apache.hadoop.hbase.spark").save();

		System.out.println("-----loading data into PI nppes maprdb table completed-----");
		return finalString.toString();
	}

}
