package com.uhg.sherlock.piorc.datamining.common;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;

public class EmailUtil {
  
  @SuppressWarnings("unchecked")
  public static void simpleMail(String wsUrl,String fromAddr,String toAddr, String subject, String body)
      throws IOException {

    Map<String, String> mailMap = new HashMap<String, String>();

    mailMap.put("fromAddr", fromAddr);
    mailMap.put("toAddr", toAddr);
    mailMap.put("subject", subject);
    mailMap.put("body", body);

    URL url = new URL(wsUrl);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    conn.setRequestMethod("POST");
    conn.setRequestProperty("Accept", "application/json");
    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
    conn.setDoOutput(true);

    JSONObject json = new JSONObject();
    json.putAll(mailMap);

    OutputStream os = conn.getOutputStream();
    os.write(json.toJSONString().getBytes("UTF-8"));
    os.flush();

    if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
      System.out.println("Email Http Request failed with response message : "
          + conn.getResponseMessage());
    }
  }

}

