package com.uhg.sherlock.piorc.datamining.jobs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.uhc.sherlock.jobConnector.dbops.JobProcessState;

public class OutputRedirector extends Thread {

    InputStream is;
    String type;
    Logger logger;
    String jobId=null;
    public OutputRedirector(InputStream is, String type, Logger logger, String jobId){
        this.is = is;
        this.type = type;
        this.logger=logger;
        this.jobId=jobId;
    }
    @Override
    public void run() {
        try {
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line = null;
            while ((line = br.readLine()) != null) {
                logger.info(type + "> " + line);
                if (line.contains("Job Submission failed with exception")) {
                	throw new IOException("Job Submission failed with exception");
                }
                
            }
        } catch (IOException ioE) {
        	try {
				JobProcessState.fraudAddressLoadAborted(jobId, "Job Submission failed with exception. Please check logs for more details");
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	logger.error(ioE.getMessage());
        	ioE.printStackTrace();
        }
    }
}
