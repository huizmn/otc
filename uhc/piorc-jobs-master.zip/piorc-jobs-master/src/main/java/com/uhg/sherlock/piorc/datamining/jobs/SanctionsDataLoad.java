package com.uhg.sherlock.piorc.datamining.jobs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.uhc.sherlock.jobConnector.dbops.JobProcessState;


public class SanctionsDataLoad {
	
	static Logger logger=Logger.getLogger(SanctionsDataLoad.class);
	
	public SanctionsDataLoad() throws IOException {
		Properties props = new Properties();
		InputStream is = getClass().getResourceAsStream("log4j.properties");
		try {
		    props.load(is);
		}
		finally {
		    try {
		        is.close();
		    }
		    catch (Exception e) {
		        e.printStackTrace();
		        if (logger!=null) {
		        	logger.error(e.getMessage());
		        }
		    }
		}
		PropertyConfigurator.configure(props);
	}
	
	public void loadSanctionsData(String jobId) throws SQLException {
		String sql="set mapred.job.queue.name=araadh_q1.arapi_sq1;insert into sherlock.pi_sanctions "
				+ "select CONCAT(sanc_tin,'~',sanc_npi,'~',cast(unix_timestamp() * rand() as bigint))," + 
				"CONCAT_WS ('|', sanc_id, sanc_lnme," + 
				"sanc_fnme," + 
				"sanc_mid_i_nm," + 
				"sanc_busnme," + 
				"sanc_dob," + 
				"sanc_phone," + 
				"sanc_street," + 
				"sanc_city," + 
				"sanc_zip," + 
				"sanc_state," + 
				"sanc_cntry," + 
				"sanc_tin," + 
				"sanc_ssn," + 
				"sanc_npi," + 
				"sanc_upin," + 
				"sanc_mpin," + 
				"sanc_dteenter," + 
				"sanc_provtype," + 
				"sanc_spec," + 
				"sanc_sancdte," + 
				"sanc_sancst," + 
				"sanc_licnbr," + 
				"sanc_brdtype," + 
				"sanc_src_cde," + 
				"sanc_termed," + 
				"sanc_contrct," + 
				"sanc_type," + 
				"sanc_reas," + 
				"sanc_terms," + 
				"sanc_cond," + 
				"sanc_fines," + 
				"sanc_addinfo," + 
				"sanc_fab," + 
				"sanc_degree," + 
				"sanc_general," + 
				"sanc_updte," + 
				"sanc_userid," + 
				"sanc_flag," + 
				"sanc_reindte," + 
				"sanc_alrt_snt_dte," + 
				"sanc_rcvd_dte," + 
				"sanc_unamb_ind," + 
				"platform," + 
				"site_code," + 
				"platform_id," + 
				"provider_360_id," + 
				"pim_provider_id )" + 
				"from sanctions.sanctions where sanc_id not in (select sanc_id from sherlock.pi_sanctions_stage);";
						
			logger.info("sql=" + sql);
			
			 try {
		    	  	ProcessBuilder hiveProcessBuilder = new ProcessBuilder("hive", "-e",sql);
			        Process hiveProcess = hiveProcessBuilder.start();

			        OutputRedirector outRedirect = new OutputRedirector(
			                hiveProcess.getInputStream(), "HIVE_OUTPUT", logger, jobId);
			        OutputRedirector outToConsole = new OutputRedirector(
			                hiveProcess.getErrorStream(), "HIVE_LOG", logger, jobId);

			        outRedirect.start();
			        outToConsole.start();  
			}catch (Exception e) {
				JobProcessState.sanctionsLoadAborted(jobId, e.getMessage());
				logger.error(e.getMessage());
				e.printStackTrace();
			}

			String tempTableSql="set mapred.job.queue.name=araadh_q1.arapi_sq1;insert into sherlock.pi_sanctions_stage "
					+ "select CONCAT(sanc_tin,'~',sanc_npi,'~',cast(unix_timestamp() * rand() as bigint)),"
					+ "* from  sanctions.sanctions where sanc_id not in (select sanc_id from sherlock.pi_sanctions_stage)";
			
			logger.info("sql=" + tempTableSql);
		      try {
		    	  	ProcessBuilder hiveProcessBuilder = new ProcessBuilder("hive", "-e",tempTableSql);
			        Process hiveProcess = hiveProcessBuilder.start();
	
			        OutputRedirector outRedirect = new OutputRedirector(
			                hiveProcess.getInputStream(), "HIVE_OUTPUT", logger, jobId);
			        OutputRedirector outToConsole = new OutputRedirector(
			                hiveProcess.getErrorStream(), "HIVE_LOG", logger, jobId);
	
			        outRedirect.start();
			        outToConsole.start();  
			}catch (Exception e) {
				JobProcessState.sanctionsLoadAborted(jobId, e.getMessage());
				logger.error(e.getMessage());
				e.printStackTrace();
			}

	}
	
	public static void main(String... args) throws SQLException, IOException {
		SanctionsDataLoad sanctions=new SanctionsDataLoad();
		String jobId="";
		try {
			jobId=JobProcessState.sanctionsLoadStarted();
			sanctions.loadSanctionsData(jobId);
			JobProcessState.sanctionsLoadCompleted(jobId);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			JobProcessState.sanctionsLoadAborted(jobId, e.getMessage());
		}
		
	}
}

//Dataset<Row> rows=spark.sql(sql);
//spark.sqlContext().sql(sql);
//List<Row> rowList=rows.collectAsList();

//if(rowList!=null) 
//{
//	logger.info(rowList.size());
//	System.out.println(rowList.size());
//}
//Process p=null;
//Runtime r = Runtime.getRuntime();
//SparkSession spark = SparkSession.builder().enableHiveSupport().config(new SparkConf()).getOrCreate();